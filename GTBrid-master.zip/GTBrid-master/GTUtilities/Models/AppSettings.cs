﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities.Models
{
    public class ConnectionStrings
    {
        public string UtilityConnection { get; set; }
        public string LogFile { get; set; }
    }
}
