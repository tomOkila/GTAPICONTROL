﻿using DBL;
using DBL.Models;
using GTUtilities.GTBrid;
using GTUtilities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities.Controllers
{
    [Route("fees/")]
    [ApiController]
    public class SchoolFeesController : ControllerBase
    {
        private Bl bl;
        private string logFile;

        public SchoolFeesController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.UtilityConnection, "");
            logFile = appSettings.Value.LogFile;
        }

       
        [HttpPost("lookup")]
        public async Task<ApiResponseModel> StudentLookUp([FromBody] MpesaPayment model)
        {
            ApiResponseModel bal = new ApiResponseModel();
            try
            {
               
                var accountData = await bl.GetStudentName(model);
                if (!String.IsNullOrEmpty(accountData.Name))
                {
                    bal = new ApiResponseModel
                    {
                        Status = 0,
                        Data = accountData.Name
                    };
                }
                else
                {
                    bal = new ApiResponseModel
                    {
                        Status = 1,
                        Message = "Invalid Account Number"
                    };
                }
            }
            catch (Exception ex)
            {
                GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ":" + ex.ToString());
                bal = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due To Technical Issue!"
                };
            }
            return bal;
        }

        [HttpPost("pay")]
        public async Task<ApiResponseModel> SchoolFeesPayment([FromBody] MpesaPayment model)
        {
            ApiResponseModel bal = new ApiResponseModel();
            try
            {
                bal = await bl.PayFees(model);
            }
            catch (Exception ex)
            {
                GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ":" + ex.ToString());
                bal = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due To Technical Issue!"
                };
            }
            return bal;
        }
    }
}
