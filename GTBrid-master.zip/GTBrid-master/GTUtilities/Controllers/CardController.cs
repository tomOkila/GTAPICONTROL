﻿using DBL;
using DBL.Models;
using GTUtilities.GTBrid;
using GTUtilities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities.Controllers
{
    [Route("/v2/")]
    [ApiController]

    public class CardController : ControllerBase
    {
        private Bl bl;
        private string logFile;
        public CardController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.UtilityConnection, appSettings.Value.LogFile);
            logFile = appSettings.Value.LogFile;
        }

        [HttpPost("card")]
        public async Task<ApiResponseModel> QueryRRN([FromBody] ApiRequestModel model)
        {
            ApiResponseModel tax = new ApiResponseModel();
            try
            {
                tax = await bl.ProcessCardPayment(model);
            }
            catch (Exception ex)
            {
                Util.CreateApiErrorResponse(logFile, "Utilitites.UtilityPay", ex);
                tax = new ApiResponseModel
                {
                    Status = 2,
                    Message = ex.ToString()//"Failed Due To Technical Issue!"
                };
            }
            return tax;
        }

    }
}
