﻿using DBL;
using DBL.Models;
using GTUtilities.GTBrid;
using GTUtilities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace GTUtilities.Controllers
{
    [Route("api/")]
    [ApiController]
    public class MpesaController : ControllerBase
    {
        private Bl bl;
        private string logFile;

        public MpesaController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.UtilityConnection,"");
            logFile = appSettings.Value.LogFile;
        }

        [HttpPost("stk")]
        public async Task<ApiResponseModel> MpesaRequest([FromBody] STKReq model)
        {
            ApiResponseModel bal = new ApiResponseModel();
            try
            {
                GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ": Request " + JsonSerializer.Serialize(model));
               // bal = await bl.STKPush(model);
            }
            catch (Exception ex)
            {
                GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ":" + ex.ToString());
                bal = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due To Technical Issue!"
                };
            }
            return bal;
        }

        [HttpPost("callback")]
        public async Task MpesaRequest([FromBody] MpesaCallBack model)
        {
            GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ": Callback" + JsonSerializer.Serialize(model));
            var stkRes = await bl.StkCallbackAsync(model);
            GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ": Callback Response" + JsonSerializer.Serialize(stkRes));

        }


        [HttpPost("mpesa-callback")]
        [Consumes("text/xml")]
        public async Task<IActionResult> MpesaB2C(XElement xml)
        {
            string result = "";
            GenericModel resp = new GenericModel();
            try
            {
                string Xml = xml.ToString();
                MpesaLogFile.MpesaB2C(logFile, DateTime.Now.ToString()+":" +xml);
                resp= await bl.MpesaCallBack(Xml);
            }
            catch (Exception ex)
            {
                result = ex.Message;
                string Xml = xml.ToString();
                resp=await bl.MpesaCallBack(Xml);

            }
            if(resp.RespStat != 0)
            {
                Logfile.MpesaErrors("B2C Error:" + resp.Data1 + " " + resp.RespStat.ToString() + " " + resp.RespMsg);
            }
            return new ContentResult { Content = "", ContentType = "text/xml", StatusCode = 200 };

        }


        [HttpPost("mpesa-b2b-callback")]
        [Consumes("text/xml")]
        public async Task<IActionResult> MpesaB2B(XElement xml)
        {
            GenericModel resp = new GenericModel();

            string result = "<? xml version =\"1.0\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><ns2:ResponseMsg xmlns:ns2=\"http://api-v1.gen.mm.vodafone.com/mminterface/result\"><![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><response xmlns=\"http://api-v1.gen.mm.vodafone.com/mminterface/response\"><ResponseCode>00000000</ResponseCode><ResponseDesc>success</ResponseDesc><ConversationID></ConversationID><OriginatorConversationID></OriginatorConversationID><ServiceStatus></ServiceStatus></response>]]></ns2:ResponseMsg></soap:Body></soap:Envelope>";
            try
            {
                string Xml = xml.ToString();
                MpesaLogFile.MpesaB2B(logFile, DateTime.Now.ToString()+":"+ xml);
                resp = await bl.MpesaB2BCallBack(Xml);
            }
            catch (Exception ex)
            {
                result = ex.Message;
                string Xml = xml.ToString();
                resp = await  bl.MpesaB2BCallBack(Xml);
            }
            if (resp.RespStat != 0)
            {
                Logfile.MpesaErrors("B2B Error:" + resp.Data1 + " " + resp.RespStat.ToString() + " " + resp.RespMsg);
            }
            return new ContentResult { Content = result, ContentType = "text/xml", StatusCode = 200 };

        }
    }
}
