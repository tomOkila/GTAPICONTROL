﻿using DBL;
using DBL.Models;
using GTUtilities.GTBrid;
using GTUtilities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities.Controllers
{
    [Route("api/v2/")]
    [ApiController]
    public class UtilitiesController : ControllerBase
    {
        private Bl bl;
        private string logFile;
        public UtilitiesController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.UtilityConnection, appSettings.Value.LogFile);
            logFile = appSettings.Value.LogFile;
        }

        [HttpPost("utilities")]
        public async Task<ApiResponseModel> UtilityPay([FromBody] ApiRequestModel model)
        {
            var response = new ApiResponseModel();
            try
            {
                Log.Error(logFile, "Utilitites.UtilityPay:" , JsonConvert.SerializeObject(model));
                response = await bl.ProcessUtilityPayment(model);
            }
            catch (Exception ex)
            {
                Util.CreateApiErrorResponse(logFile, "Utilitites.UtilityPay", ex);
                response = new ApiResponseModel
                {
                    Status = 1,
                    Message = "Payment Posting Failed!"
                };
            }
            return response;
        }


        [HttpPost("utilities/callback")]
        public async Task<UtilitiesCallback> UtilityCallback([FromBody] Utilities model)
        {
            var response = new UtilitiesCallback();
            try
            {
                Log.Error(logFile, "Utilitites.Callback:", JsonConvert.SerializeObject(model));
                response = await bl.ProcessUtilityCallback(model);
            }
            catch (Exception ex)
            {
                response = new UtilitiesCallback
                {
                    Status = 1,
                    Message = "Payment Posting Failed!"
                };
            }
            return response;
        }
    }
}
