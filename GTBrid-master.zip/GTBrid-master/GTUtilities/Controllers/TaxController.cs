﻿using DBL;
using DBL.Models;
using GTUtilities.GTBrid;
using GTUtilities.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities.Controllers
{
    [Route("api/")]
    [ApiController]
    public class TaxController : Controller
    {
        private Bl bl;
        private string logFile;

        public TaxController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.UtilityConnection, "");
            logFile = appSettings.Value.LogFile;
        }

        [HttpPost("query")]
        public async Task<RequestResponseModel> QueryRRN([FromBody] DeclarationQueryData model)
        {
            RequestResponseModel tax = new RequestResponseModel();
            try
            {
                tax = await bl.QueryTax(model);
            }
            catch (Exception ex)
            {
                Util.CreateApiErrorResponse(logFile, "TAX.query", ex);
                tax = new RequestResponseModel
                {
                    Status = 2,
                    Message = ex.ToString()//"Failed Due To Technical Issue!"
                };
            }
            return tax;
        }
    }
}
