﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTUtilities
{
    using Microsoft.AspNetCore.Hosting;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;

    namespace GTBrid
    {
        public class GTPayLogfile
        {

            public static void GTPAYErrors(string content)
            {
                string folder = @"E:\GTPAY\STK" + DateTime.Now.ToString("yyMMdd") + "";
                // If directory does not exist, create it
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
                string fileName = "Errors.txt";
                string fullPath = folder + "\\" + fileName;

                // This text is added only once to the file.
                if (!File.Exists(fullPath))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
            }

        }

        public class MpesaLogFile
        {
            public static async void MpesaB2C(string logfile, string content)
            {
                string folder = logfile+DateTime.Now.ToString("dd-MM-yyyy");
                // If directory does not exist, create it
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
                string fileName = "MpesaB2C.txt";
                string fullPath = folder + "\\" + fileName;

                // This text is added only once to the file.
                if (!File.Exists(fullPath))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
            }

            public static void MpesaB2B(string logfile, string content)
            {
                string folder = logfile + DateTime.Now.ToString("dd-MM-yyyy") + "";
                // If directory does not exist, create it
                if (!Directory.Exists(folder))
                {
                    Directory.CreateDirectory(folder);
                }
                string fileName = "MpesaB2B.txt";
                string fullPath = folder + "\\" + fileName;

                // This text is added only once to the file.
                if (!File.Exists(fullPath))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fullPath))
                    {
                        sw.WriteLine(content);
                    }
                }
            }
        }
       
        public class Util
        {

            public static void CreateApiErrorResponse(string logFile, string functioName, Exception ex, bool isError = true)
            {
                Task.Run(async () =>
                {
                    try
                    {
                        //--- Delete log if it more than 500Kb
                        if (File.Exists(logFile))
                        {
                            FileInfo fi = new FileInfo(logFile);
                            if ((fi.Length / 1000) > 100)
                                fi.Delete();
                        }
                        //--- Create stream writter
                        StreamWriter stream = new StreamWriter(logFile, true);
                        await stream.WriteLineAsync(string.Format("{0}|{1:dd-MMM-yyyy HH:mm:ss}|{2}|{3}",
                            isError ? "ERROR" : "INFOR",
                            DateTime.Now,
                            functioName,
                            isError ? ex.ToString() : ex.Message));
                        stream.Close();
                    }
                    catch (Exception) { }
                });
            }

            public static string GetCallLogFile(IWebHostEnvironment env)
            {
                try
                {
                    string logDir = Path.Combine(env.ContentRootPath, "logs");

                    //---- Create Directory if it does not exist              
                    if (!Directory.Exists(logDir))
                    {
                        Directory.CreateDirectory(logDir);
                    }
                    return Path.Combine(logDir, "CallLog.log");
                }
                catch (Exception)
                {
                    return "";
                }
            }

            public static string GetLogFile(IWebHostEnvironment env)
            {
                try
                {
                    string logDir = Path.Combine(env.ContentRootPath, "logs");

                    //---- Create Directory if it does not exist              
                    if (!Directory.Exists(logDir))
                    {
                        Directory.CreateDirectory(logDir);
                    }
                    return Path.Combine(logDir, "ErrorLog.log");
                }
                catch (Exception)
                {
                    return "";
                }
            }

           
        }

        public static class Log
        {
            public static void Infor(string logFile, string functioName, string message)
            {
                WriteLog(logFile, functioName, new Exception(message), false);
            }

            public static void Error(string logFile, string functioName, Exception ex)
            {
                WriteLog(logFile, functioName, ex);
            }

            public static void Error(string logFile, string functioName, string message)
            {
                WriteLog(logFile, functioName, new Exception(message));
            }

            private static void WriteLog(string logFile, string functioName, Exception ex, bool isError = true)
            {
                Task.Run(async () =>
                {
                    try
                    {
                        //--- Delete log if it more than 500Kb
                        if (File.Exists(logFile))
                        {
                            FileInfo fi = new FileInfo(logFile);
                            if ((fi.Length / 1000) > 100)
                                fi.Delete();
                        }
                        //--- Create stream writter
                        StreamWriter stream = new StreamWriter(logFile, true);
                        await stream.WriteLineAsync(string.Format("{0}|{1:dd-MMM-yyyy HH:mm:ss}|{2}|{3}",
                            isError ? "ERROR" : "INFOR",
                            DateTime.Now,
                            functioName,
                            isError ? ex.ToString() : ex.Message));
                        stream.Close();
                    }
                    catch (Exception) { }
                });
            }
        }
    }

}
