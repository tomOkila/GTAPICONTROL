﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DBL
{
    public class RestApiClient : IDisposable
    {
        private string url;
        private RequestType requestType;
        private bool _disposed;
        private Dictionary<string, string> _headers = new Dictionary<string, string>();

        public RestApiClient(string url, RequestType requestType)
        {
            this.url = url;
            this.requestType = requestType;
        }

        public RestApiClient(string url, RequestType requestType, Dictionary<string, string> headers)
        {
            this.url = url;
            this.requestType = requestType;
            _headers = headers;
        }

        public async Task<HttpResult> SendRequestAsync(string requestData)
        {
            try
            {
                var handler = new HttpClientHandler { AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate };
                handler.ClientCertificateOptions = ClientCertificateOption.Manual;
                handler.ServerCertificateCustomValidationCallback =
                    (httpRequestMessage, cert, cetChain, policyErrors) =>
                    {
                        return true;
                    };
                using (var httpClient = new HttpClient(handler))
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    var contentType = new MediaTypeWithQualityHeaderValue("application/json");
                    httpClient.DefaultRequestHeaders.Accept.Clear();
                    httpClient.DefaultRequestHeaders.Accept.Add(contentType);
                    
                    HttpContent httpContent = null;
                    if (requestType == RequestType.Post)
                    {
                        httpContent = new StringContent(requestData, Encoding.UTF8, "application/json");
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(requestData))
                        {
                            var qParams =  requestData.JsonToQuery();
                            url += qParams;
                        }
                    }

                    var request = new HttpRequestMessage()
                    {
                        RequestUri = new Uri(url),
                        Method = requestType == RequestType.Post ? HttpMethod.Post : HttpMethod.Get,
                        Content = httpContent,
                    };

                    //---- Add headers
                    if (_headers != null)
                        foreach (var h in _headers)
                        {
                            request.Headers.Add(h.Key, h.Value);
                        }
                   
                    //--- Send the request
                    var response = await httpClient.SendAsync(request);
                    if (response.IsSuccessStatusCode)
                    {
                        var responseData = await response.Content.ReadAsStringAsync();
                        return new HttpResult { Success = true, Data = responseData };
                    }
                    else
                    {
                        return new HttpResult { Success = false, Exception = new Exception(response.ReasonPhrase) };
                    }
                }
            }
            catch (Exception ex)
            {
                return new HttpResult { Success = false, Exception = ex };
            }
        }

        
        public enum RequestType { Get = 0, Post = 1 }

        public class HttpResult
        {
            public bool Success { get; set; }
            public string Data { get; set; }
            public Exception Exception { get; set; }
        }

        public void Dispose()
        {
            dispose(true);
            GC.SuppressFinalize(this);
        }

        private void dispose(bool disposing)
        {
            if (!_disposed)
            {
                _disposed = true;
            }
        }

        ~RestApiClient()
        {
            dispose(false);
        }
    }
}
