﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Consts
{
    public class GAPS_REQUEST_ACTIONS
    {
        public const int GAPS_TRANSFERS = 50;
        public const int GAPS_LOOKUP = 51;
        public const int GAPS_ACCOUNT = 52;
        public const int PSLNK_LOOKUP = 53;
    }

    public class PSLNK_REQUEST_ACTIONS
    {
        public const int PSLNK_CUSLOOKUP = 50;
        public const int PSLNK_TRANSFERS = 51;
        public const int PSLNK_LOOKUP = 52;
        public const int PSLNK_ACCOUNT = 53;
    }

    public class GTPAY_REQUEST_ACTIONS
    {
        public const int GTPAY_TRANSFERS = 50;
        public const int GTPAY_SETTLEMENT = 51;
        public const int GTPAY_MERCHANTS = 52;
    }

    public class MPESA_REQUESR_ACTIONS
    {
        public const int MPESA_INSERT = 50;
        public const int MPESA_DELETE = 51;
        public const int MPESA_VIEW = 52;
    }
}
