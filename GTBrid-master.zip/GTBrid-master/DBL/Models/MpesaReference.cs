﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class MpesaReference
    {
        [JsonProperty("acc")]
        public string AccountNo { get; set; }
    }
}
