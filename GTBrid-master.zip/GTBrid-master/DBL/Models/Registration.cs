﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class Register
    {
        [JsonProperty("accNo")]
        public string AccNo { get; set; }
        [JsonProperty("def")]
        public int Default { get; set; }
        [JsonProperty("doc")]
        public string Document { get; set; }
        [JsonProperty("docNo")]
        public string DocumentNo { get; set; }
        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("name")]
        public string CustomerName { get; set; }
    }


    public class RegisterResponse
    {
        [JsonProperty("stat")]
        public int Status { get; set; }
        [JsonProperty("msg")]
        public string Message { get; set; }
        [JsonProperty("rrn")]
        public string RegisterDetails { get; set; }
    }

    public class UserBanksData
    {
        [JsonProperty("cus_name")]
        public string CustName { get; set; }
        [JsonProperty("stat")]
        public string Def { get; set; }
        [JsonProperty("bank")]
        public string BankName { get; set; }
        [JsonProperty("sort")]
        public string SortCode { get; set; }
    }
}
