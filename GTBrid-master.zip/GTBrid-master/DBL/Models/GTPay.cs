﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class Merchants
    {
        [JsonProperty("mcode")]
        public string MerchantCode { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("accno")]
        public string AccountNumber { get; set; }
    }


    public class Settlement
    {
        [JsonProperty("txnRef")]
        public string TransRef { get; set; }
        [JsonProperty("mcode")]
        public string MerchantCode { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
    }
}
