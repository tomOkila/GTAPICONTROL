﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{

    public class DeclarationQueryData
    {
        [JsonProperty("rrn")]
        public string SlipNumber { get; set; }

    }

    public class RequestResponseModel
    {
        public int Status { get; set; }
        public string Message { get; set; }
        public dynamic Content { get; set; }
    }

    public class KRAQueryResponse
    {
        [JsonProperty("stat")]
        public string Status { get; set; }
        [JsonProperty("msg")]
        public string Message { get; set; }
        [JsonProperty("taxCode")]
        public string TaxCode { get; set; }
        [JsonProperty("sysCode")]
        public string SystemCode { get; set; }
        [JsonProperty("slipNo")]
        public string ESlipNumber { get; set; }
        [JsonProperty("payCode")]
        public string SlipPaymentCode { get; set; }
        [JsonProperty("advDate")]
        public string PaymentAdviceDate { get; set; }
        [JsonProperty("pin")]
        public string PIN { get; set; }
        [JsonProperty("payName")]
        public string PayerName { get; set; }
        [JsonProperty("ttAmt")]
        public string TotalAmount { get; set; }
        [JsonProperty("docRef")]
        public string DocRefNumber { get; set; }
        [JsonProperty("curr")]
        public string Currency { get; set; }
        public string TaxHead { get; set; }
        public string Component { get; set; }
        public string Amt { get; set; }
        public string TaxPeriod { get; set; }
    }

    public class TaxPayData
    {
        [JsonProperty("rrn")]
        public string SlipNumber { get; set; }
        [JsonProperty("rrn")]
        public string BankTellerId { get; set; }
        [JsonProperty("rrn")]
        public string BankTellerName { get; set; }
        [JsonProperty("rrn")]
        public string RemitterId { get; set; }

    }
}
