﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class ApiTokenResult
    {
        public bool Successful { get; set; }
        public string Message { get; set; }
        public string AuthToken { get; set; }
        public string Expiry { get; set; }
        public string ErrorCode { get; set; }
    }

    public class ApiAuthResult
    {
        public bool Successful { get; set; }
        public string Message { get; set; }
        public string ErrorCode { get; set; }
        public int AppCode { get; set; }
        public int ServiceCode { get; set; }
        public int TokenCode { get; set; }
        public bool CallLog { get; set; }
    }
}
