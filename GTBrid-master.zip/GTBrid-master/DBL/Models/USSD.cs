﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class USSDRequest
    {
        public int MnoCode { get; set; }
        public string PhoneNo { get; set; }
        public string DataText { get; set; }
        public string SessionId { get; set; }
    }

    public class USSDResponse
    {
        public string DataText { get; set; }
        public int StatusCode { get; set; }
    }
}
