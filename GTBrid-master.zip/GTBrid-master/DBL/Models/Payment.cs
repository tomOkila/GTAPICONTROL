﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class PaymentRequest
    {
        [JsonProperty("txn_ref")]
        public string ReferenceNo { get; set; }
        [JsonProperty("curr")]
        public string Currency { get; set; }
        [JsonProperty("tt_amt")]
        public decimal TotalAmount { get; set; }
        [JsonProperty("acc_date")]
        public DateTime AccDate { get; set; }
        [JsonProperty("txnType")]
        public string TxnType { get; set; }
        [JsonProperty("channel")]
        public string Channel { get; set; }
        [JsonProperty("txns")]
        public List<Transactions> Transactions { get; set; }
    }

    public class Transactions
    {
        public string MsgId { get; set; }
        [JsonProperty("benefId")]
        public string BeneficiaryId { get; set; }//bank receiving funds
        [JsonProperty("curr")]
        public string CurrencyCode { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("dr_accname")]
        public string DrAccName { get; set; }
        [JsonProperty("dr_accphone")]
        public string DrAccPhone { get; set; }
        [JsonProperty("dr_accno")]
        public string DrAccNo { get; set; }
        [JsonProperty("cr_name")]
        public string CrName { get; set; }
        [JsonProperty("cr_accno")]
        public string CrAccNo { get; set; }
        [JsonProperty("cr_accphone")]
        public string CrAccPhone { get; set; }
        [JsonProperty("nar")]
        public string Narration { get; set; }
        [JsonProperty("pur")]
        public string Purpose { get; set; }
        [JsonProperty("trans_id")]
        public string TransactionID { get; set; }
    }

    public class PaymentAccpetance
    {
        public DateTime Date { get; set; }
        public string AccMsgId { get; set; }
        public string MsgType { get; set; }
        public string AccNo { get;  set; }
        public string AccName { get;  set; }
        public string SettlMd { get;  set; }
        public string SettlPrt { get;  set; }
        public string TxnType { get;  set; }
        public string LclInst { get;  set; }
        public string Channel { get;  set; }
        public string SenderId { get; set; }
        public string ReceiverId { get; set; }
        public string MsgId { get; set; }
        public string AccDate { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public string ManDates { get; set; }
        public string Narration { get; set; }
        public string DebCBSName { get; set; }
        public string DebCBSPhone { get; set; }
        public string DebAccNo { get; set; }
        public string DebAccAgt { get; set; }
        public string CrAccAgt { get; set; }
        public string CrAccNo { get; set; }
        public string OrgEndToEnd { get; set; }
        public string Purpose { get; internal set; }
        public string CrCBSName { get; internal set; }
        public string CrCBSPhone { get; internal set; }
    }

    public class PaymentInst
    {
        public string MsgId { get; set; }
        public string MsgType { get; set; }
        public string AccMsgId { get; set; }
        public string OrgEndToEnd { get; set; }
        public string SenderId { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public string ReceiverId { get; set; }
        public string TxnType { get; set; }
        public string LclInst { get; set; }
        public string Channel { get; set; }
        public string ManDates { get; set; }
        public string Narration { get; set; }
        public string DebAccAgt { get; set; }
        public string CrAccAgt { get; set; }
        public string CrAccNo { get; set; }
        public string AccDate { get;  set; }
        public string DebAccNo { get;  set; }
        public string InstgAgt { get;  set; }
        public string DebCBSPhone { get;  set; }
        public string DebCBSName { get;  set; }
        public string DrAccAgt { get;  set; }
        public string Purpose { get;  set; }
        public string CrAccPhone { get;  set; }
        public string CrAccName { get;  set; }
        public string SenderDate { get;  set; }
    }

    public class PaymentLookUp
    {
        public string CreateDate { get; set; }
        public DateTime AccDate { get; set; }
        public string UniqueRef { get; set; }
        public string MsgNm { get; set; }
        public string PaymentRef { get; set; }
        public string MainRef { get; set; }
        public string StsReq { get; set; }
        public string Currency { get; set; }
        public decimal Amount { get; set; }
        public string TranType { get; set; }
        public string Channel { get; set; }
        public string OrigReff { get; set; }
        public string Narration { get; set; }
        public string CustName { get; set; }
        public string BeneName { get; set; }
        public string CustAcc { get; set; }
        public string DestAcc { get; set; }
        public string Purpose { get; set; }
        public string IPS { get; set; }
        public string GTB { get; set; }
        public string BankCode { get; set; }
        public string Phone { get; set; }
        public int Type { get; set; }
    }
    public class PaymentRespose
    {
        [JsonProperty("stat")]
        public int Status { get; set; }
        [JsonProperty("msg")]
        public string Message { get; set; }
        [JsonProperty("data")]
        public dynamic Data { get; set; }
    }

    public class PayResponse
    {
        public string MsgId { get; set; }
        public string Response { get; set; }
        public string Msg { get; set; }
    }
}
