﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class BalanceReq
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("sort")]
        public string BankCode { get; set; }
    }

    public class BalanceRes
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("cusName")]
        public string CusName { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("accStat")]
        public string AccountStatus { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("book")]
        public decimal BookAmt { get; set; }
        [JsonProperty("resStat")]
        public int RestrictionStat { get; set; }
        [JsonProperty("loc")]
        public string Location { get; set; }
        [JsonProperty("limit")]
        public decimal Limit { get; set; }
    }

    public class StatementReq
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("datefrom")]
        public string DateFrom { get; set; }
        [JsonProperty("dateto")]
        public string DateTo { get; set; }
    }

    public class StatementResp
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("date")]
        public string Date { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("remark")]
        public string Narration { get; set; }
        [JsonProperty("txntype")]
        public string Txntype { get; set; }
    }

    public class PostTransaction
    {
        [JsonProperty("batch")]
        public int Batch { get; set; }
        [JsonProperty("type")]
        public int TxnType { get; set; }
        [JsonProperty("custCode")]
        public string CustomerNumber { get; set; }
        [JsonProperty("txns")]
        public List<PostTran> PostTran { get; set; }
    }

    public class PostTran
    {
        [JsonProperty("transID")]
        public int TransactionID { get; set; }
        [JsonProperty("txnType")]
        public int TxnType { get; set; }
        [JsonProperty("drAcc")]
        public string DebitAccount { get; set; }
        [JsonProperty("crAcc")]
        public string CreditAccount { get; set; }
        [JsonProperty("refNo")]
        public string SourceRef { get; set; }
        [JsonProperty("curr")]
        public int Currency { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("nar")]
        public string Narration { get; set; }
        [JsonProperty("txn_priority")]
        public int TxnPriority { get; set; }
        [JsonProperty("explCode")]
        public int ExplanationCode { get; set; }
        [JsonProperty("cusAcc")]
        public string CustAccount { get; set; }
    }

    public class PostRes
    {
        [JsonProperty("success")]
        public bool Success { get; set; }
        [JsonProperty("cbsRef")]
        public string CBSRef { get; set; }
        [JsonProperty("unique")]
        public string UniqueRef { get; set; }
    }

    public class SalaryAdReq
    {
        [JsonProperty("cusNo")]
        public string CustomerNumber { get; set; }
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
    }

    public class MetropolLookUp
    {
        [JsonProperty("report_type")]
        public int Report { get; set; }
        [JsonProperty("identity_number")]
        public string ID { get; set; }
        [JsonProperty("identity_type")]
        public string Identity { get; set; }
    }

    public class CBSPosting
    {
        public int BatchCode { get; set; }
        public int ExplCode { get; set; }
        public string CRAccount { get; set; }
        public string DRAccount { get; set; }
        public decimal Amount { get; set; }
        public string Narration { get; set; }
        public int TxnType { get; set; }
        public string TransID { get; set; }
        public string AppName { get; set; }
        public int TxnCode { get; set; }
    }


    public class CBSRes
    {
        [JsonProperty("stat")]
        public int Status { get; set; }
        [JsonProperty("batch")]
        public int BatchCode { get; set; }
        [JsonProperty("transID")]
        public string TransID { get; set; }
        [JsonProperty("resCode")]
        public string ResponseCode { get; set; }
        public int TxnCode { get; set; }
    }

    public class CuttOffTrans
    {
        [JsonProperty("type")]
        public int Type { get; set; }
        [JsonProperty("appCode")]
        public int AppCode { get; set; }
        [JsonProperty("batch")]
        public int BatchID { get; set; }
        [JsonProperty("transID")]
        public int TransID { get; set; }
    }
    public class UtilReq
    {
        public int TxnType { get; set; }
        public int BatchCode { get; set; }
        public int SourceRef { get; set; }
        public int CurrencyCode { get; set; }
        public int AppID { get; set; }
    }
}
