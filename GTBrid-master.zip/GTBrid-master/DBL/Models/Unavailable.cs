﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class Unavailable
    {
        [JsonProperty("fro")]
        public DateTime FromDate { get; set; }
        [JsonProperty("to")]
        public DateTime ToDate { get; set; }
        [JsonProperty("reason")]
        public string Reason { get; set; }
    }
}
