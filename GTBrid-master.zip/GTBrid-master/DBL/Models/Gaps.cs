﻿using DBL.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class SysUserModel
    {
        public int UserCode { get; set; }
        public string UserName { get; set; }
        public string FullNames { get; set; }
        public string PhoneNo { get; set; }
        public string Email { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime LastLogin { get; set; }
        public int UserStat { get; set; }
        public int UserRole { get; set; }
        public string UserStatusName { get; set; }
        public string UserRoleName { get; set; }
    }


    public class PaymentModel
    {
        public string PaymentRef { get; set; }
        public int ServiceCode { get; set; }
        public int AppCode { get; set; }
        public int ActionCode { get; set; }
        public int PayType { get; set; }
        public string Process { get; set; }
        public int Currency { get; set; }
        public decimal Balance { get; set; }
        public string CusAcc { get; set; }
        public string SourceID { get; set; }
    }



    public class UserModel
    {
        public int UserCode { get; set; }
        public string FullNames { get; set; }
        public int ChurchCode { get; set; }
        public UserLoginStatus UserStatus { get; set; }
        public int RespStat { get; set; }
        public string RespMsg { get; set; }
        public string Extra1 { get; set; }
        public string Extra2 { get; set; }
        public string Extra3 { get; set; }
    }

    public class UserLoginModel
    {
        [Required]
        [Display(Name = "Username", Prompt = "Enter your username")]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password", Prompt = "Enter your password")]
        public string Password { get; set; }

        [Required]
        [Display(Name = "Remember Me", Prompt = "Remember Me")]
        public bool RememberMe { get; set; }
    }

    public class ChangeUserPassModel
    {
        [Required]
        public int UserCode { get; set; }

        [Required]
        [Display(Name = "Old Password", Prompt = "Old Password")]
        [DataType(DataType.Password)]
        public string OldPassword { get; set; }

        [Required]
        [Display(Name = "New Password", Prompt = "New Password")]
        [DataType(DataType.Password)]
        [StringLength(20, MinimumLength = 6)]
        public string NewPassword { get; set; }

        [Required]
        [Display(Name = "Re-type Password", Prompt = "Re-type Password")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Passwords do no match!")]
        public string ConfirmPassword { get; set; }
    }

    public class PasswordPolicyModel
    {
        public string PolicyText { get; set; }
    }

    public class ResetPassModel
    {
        [Required]
        [Display(Name = "Username", Prompt = "Username")]
        public string Username { get; set; }
    }

    public class ReqResult
    {
        public bool Success { get; set; }

        public string Message { get; set; }

        public dynamic Data { get; set; }
    }

    public class TransactionModel
    {
        public int PaymentCode { get; set; }
        public DateTime PaymentDate { get; set; }
        public string ServiceName { get; set; }
        public string ClientName { get; set; }
        public string ActionName { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public string MerchantRef { get; set; }
        public string MerchantRes { get; set; }
        public string PFAcc { get; set; }
        public string PFRefNo { get; set; }
    }

    public class GAPTransfer
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("payType")]
        public int PayType { get; set; }
        [JsonProperty("process")]
        public string Process { get; set; }
        [JsonProperty("curr")]
        public int Currency { get; set; }
        [JsonProperty("txns")]
        public List<GAPTrans> Transactions { get; set; }
    }

    public class GAPTrans
    {
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("payDate")]
        public DateTime PaymentDate { get; set; }
        [JsonProperty("txnRef")]
        public string TranRef { get; set; }
        [JsonProperty("nar")]
        public string Narration { get; set; }
        [JsonProperty("cname")]
        public string CustomerName { get; set; }
        [JsonProperty("ccode")]
        public string CustomerCode { get; set; }
        [JsonProperty("cacc")]
        public string AccountNo { get; set; }
        [JsonProperty("cbank")]
        public string Bank { get; set; }
    }


    public class GAPLookUp
    {
        [JsonProperty("batchID")]
        public int BatchID { get; set; }
        [JsonProperty("transID")]
        public int TransID { get; set; }
    }

    public class GAPTransferRes
    {
        [JsonProperty("refNo")]
        public string Reference { get; set; }
    }

    public class PesalinkTransfer
    {
        [JsonProperty("accNo")]
        public string AccountNo { get; set; }
        [JsonProperty("payType")]
        public int PayType { get; set; }
        [JsonProperty("curr")]
        public int Currency { get; set; }
        [JsonProperty("txns")]
        public List<PesalinkTrans> Transactions { get; set; }
    }

    public class PesalinkTrans
    {
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("payDate")]
        public DateTime PaymentDate { get; set; }
        [JsonProperty("txnRef")]
        public string TranRef { get; set; }
        [JsonProperty("nar")]
        public string Narration { get; set; }
        [JsonProperty("cname")]
        public string CustomerName { get; set; }
        [JsonProperty("cacc")]
        public string AccountNo { get; set; }
        [JsonProperty("cbank")]
        public string Bank { get; set; }
    }


    public class PesalinkCusLookUp
    {
        [JsonProperty("cacc")]
        public string AccountNo { get; set; }
    }

    public class PesalinkCusLookUpData
    {
        [JsonProperty("cname")]
        public string CustomerName { get; set; }

        [JsonProperty("cbank")]
        public string BankName { get; set; }
    }
}
