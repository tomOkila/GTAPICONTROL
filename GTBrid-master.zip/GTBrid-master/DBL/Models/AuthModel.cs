﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DBL.Models
{
    public class AuthData
    {
        [JsonProperty("msgId")]
        public string MsgId { get; set; }
        [JsonProperty("date")]
        public string Date { get; set; }
        [JsonProperty("sender")]
        public string SenderId { get; set; }
        [JsonProperty("receiver")]
        public string ReceiverId { get; set; }
        [JsonProperty("verfyId")]
        public string VerifyId { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("accNo")]
        public string AccNo { get; set; }
        [JsonProperty("destId")]
        public string DestinationId { get; set; }
    }

    public class BulkData
    {
        [JsonProperty("data")]
        public List<AuthData> Data { get; set; }
    }

    public class AuthResponse
    {
        [JsonProperty("smsgId")]
        public string SenderMsgId { get; set; }
        [JsonProperty("msgId")]
        public string MsgId { get; set; }
        [JsonProperty("date")]
        public DateTime Date { get; set; }
        [JsonProperty("senderId")]
        public string SenderId { get; set; }
        [JsonProperty("receiverId")]
        public string ReceiverId { get; set; }
        [JsonProperty("verfyId")]
        public string VerifyId { get; set; }
        [JsonProperty("phone")]
        public string PnoneNo { get; set; }
        [JsonProperty("accName")]
        public string AccName { get; set; }
        [JsonProperty("accNo")]
        public string AccNo { get; set; }
        [JsonProperty("success")]
        public bool Success { get; set; }
        [JsonProperty("stat")]
        public int Status { get; set; }
    }

   
}
