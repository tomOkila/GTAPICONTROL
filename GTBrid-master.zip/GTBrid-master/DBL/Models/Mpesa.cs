﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class STKReq
    {
        [JsonProperty("tranRef")]
        public string ReferenceNo { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("merCode")]
        public string MerchantCode { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
    }

    public class GTCollectStk
    {
        [JsonProperty("transID")]
        public string ReferenceNo { get; set; }
        [JsonProperty("wareHouse")]
        public string WareHouse { get; set; }
        [JsonProperty("accNo")]
        public string AccountNumber{ get; set; }
        [JsonProperty("name")]
        public string AccountName { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("app")]
        public int AppCode { get; set; }
    }

    public class MpesaCallBack
    {
        [JsonProperty("Body")]
        public Body Data { get; set; }
    }

    public class Body
    {
        [JsonProperty("stkCallback")]
        public CallBack Data { get; set; }
    }

    public class CallBack
    {
        [JsonProperty("MerchantRequestID")]
        public string Merchant { get; set; }
        [JsonProperty("CheckoutRequestID")]
        public string Checkout { get; set; }
        [JsonProperty("ResultCode")]
        public int Code { get; set; }
        [JsonProperty("ResultDesc")]
        public string Desc { get; set; }
        [JsonProperty("CallbackMetadata")]
        public MetaData Meta { get; set; }
    }

    public class MetaData
    {
        [JsonProperty("Item")]
        public List<Item> Item { get; set; }
    }

    public class Item
    {
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Value")]
        public dynamic Value { get; set; }
    }

    public class MpesaLookUp
    {
        [JsonProperty("refNo")]
        public string ReferenceNo { get; set; }
        [JsonProperty("tranRef")]
        public string Transref { get; set; }
    }


    public class MpesaData
    {
        public string ResultCode { get; set; }
        public string RespMsg { get; set; }
        public string ConvId { get; set; }
        public string Receipt { get; set; }
        public DateTime Date { get; set; }
        public decimal Float { get; set; }
        public string Remarks { get; set; }
        public string BrokerId { get; set; }
    }



    public class MpesaPayment
    {
        [JsonProperty("payno")]
        public int PayBillNo { get; set; }
        [JsonProperty("acc")]
        public string AccountNo { get; set; }
        [JsonProperty("billNo")]
        public string BillNo { get; set; }
        [JsonProperty("amt")]
        public string Amt { get; set; }
        [JsonProperty("cusRef")]
        public string CustRefno { get; set; }
        [JsonProperty("bankRef")]
        public string BankRef { get; set; }
        [JsonProperty("payMode")]
        public string PayMode { get; set; }
        [JsonProperty("phone")]
        public string Phone { get; set; }
        [JsonProperty("credacc")]
        public string CreditAcct { get; set; }
        [JsonProperty("crecus")]
        public string CreditCustName { get; set; }
        [JsonProperty("stuname")]
        public string StudentName { get; set; }
        [JsonProperty("desc")]
        public string TransDesc { get; set; }
        [JsonProperty("payReason")]
        public string PayReason { get; set; }
        [JsonProperty("narr")]
        public string PayNarration { get;  set; }
        [JsonProperty("tranDate")]
        public string TransDate { get;  set; }
        [JsonProperty("debacc")]
        public string DebitAcct { get;  set; }
        [JsonProperty("debcus")]
        public string DebitCustName { get;  set; }
    }
}
