﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class StudentName
    {
        public string Name { get; set; }
    }



    public class PaymentResponse
    {
        public string ResponseCode { get; set; }
        public string ResponseMsg { get; set; }
    }
}
