﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class GAPSApiRequestModel
    {
        [JsonProperty("tsp")]
        public string Timestamp { get; set; }

        [JsonProperty("ver")]
        public int Version { get; set; }

        [JsonProperty("act")]
        public int Action { get; set; }

        [JsonProperty("content")]
        public dynamic Content { get; set; }

        [JsonProperty("hdata")]
        public ApiRequestHeaderData HeaderData { get; set; }

        [JsonProperty("rdata")]
        public ApiRequestInternalData ReservedData { get; set; }

        [JsonProperty("sid")]
        public string ServiceId { get; set; }
    }

    public class ApiRequestInternalData
    {
        [JsonProperty("acode")]
        public int AppCode { get; set; }

        [JsonProperty("scode")]
        public int ServiceCode { get; set; }

        [JsonProperty("tkn")]
        public int TokenCode { get; set; }
    }

    public class ApiRequestHeaderData
    {
        [JsonProperty("ref_no")]
        public string ReferenceNo { get; set; }

        [JsonProperty("user_id")]
        public string UserID { get; set; }

        [JsonProperty("src_id")]
        public string SourceID { get; set; }
    }

    public class AuthTokenModel
    {
        [JsonProperty("auth_token")]
        public string AuthToken { get; set; }

        [JsonProperty("expiry")]
        public string Expiry { get; set; }
    }

    public class GAPSApiResponseModel
    {
        [JsonProperty("stat")]
        public int RespStat { get; set; }

        [JsonProperty("msg")]
        public string Message { get; set; }

        [JsonProperty("data")]
        public dynamic Data { get; set; }
    }

    public class BaseApiResultModel
    {
        public int ResultStatus { get; set; }

        public string ResultMessage { get; set; }

        public Exception Exception { get; set; }
    }
}
