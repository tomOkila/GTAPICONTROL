﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    [Table("GTCollect")]
    public class GTCollect
    {
        [NotMapped]
        public static string TableName { get { return "GTCollect"; } }

        [Column("id")]
        public int GTCollectID { get; set; }

        [Column("StudentNo")]
        [Required()]
        [StringLength(50)]
        [Display(Name = "Student Number")]
        public string StudentNumber { get; set; }

        [Display(Name = "Student Name")]
        public string Name { get; set; }

        [Column("Phone")]
        [Required()]
        [StringLength(10)]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Phone")]
        public string Phone { get; set; }

        [Column("PayReason")]
        [Required()]
        [Display(Name = "Payment Reason")]
        public int PayReason { get; set; }

        [Display(Name = "Other Reason")]
        public string OtherReason { get; set; }

        [Column("Amount")]
        [Required()]
        [DataType(DataType.Currency)]
        [Display(Name = "Amount")]
        public decimal Amount { get; set; }

        [Column("email")]
        [Required()]
        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Column("PayMethod")]
        [Required()]
        [Display(Name = "Payment Method")]
        public int PayMethod { get; set; }
        public string Institution { get; set; }
    }

    public class DbConnData
    {
        public string ConnectionString { get; set; }
    }

    public class ListModel
    {
        public ListModel() { }

        public ListModel(string text, string value)
        {
            Text = text;
            Value = value;
        }

        //[JsonProperty("itxt")]
        public string Text { get; set; }

        //[JsonProperty("ival")]
        public string Value { get; set; }
    }

    public class Alert
    {
        public const string TempDataKey = "TempDataAlerts";
        public string AlertStyle { get; set; }
        public string Message { get; set; }
        public bool Dismissable { get; set; }
        public string IconClass { get; set; }
    }

    public static class AlertStyles
    {
        public const string Success = "success";
        public const string Information = "info";
        public const string Warning = "warning";
        public const string Danger = "danger";
    }
}
