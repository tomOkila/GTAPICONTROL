﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class CardQueryCard
    {
        [JsonProperty("cardNo")]
        public string CardNo { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }

    }

    public class InitResponse
    {
        public string NextChallenge { get; set; }
        public string Session { get; set; }
    }
}
