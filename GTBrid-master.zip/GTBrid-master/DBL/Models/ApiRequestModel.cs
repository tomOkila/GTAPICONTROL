﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Models
{
    public class ApiRequestModel
    {
        [JsonProperty("appId")]
        public int AppId { get;set;}
        [JsonProperty("act")]
        public int Action { get; set; }
        [JsonProperty("data")]
        public dynamic Data { get; set; }
    }

    public class UtilityData
    {
        [JsonProperty("tranRef")]
        public string TransactionRef { get; set; }
        [JsonProperty("service")]
        public string Service { get; set; }
        [JsonProperty("pno")]
        public string PhoneNo { get; set; }
        [JsonProperty("accno")]
        public string AccNo { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        public string PayRef { get; set; }

        [JsonProperty("query")]
        public int Presentment { get; set; }
        [JsonProperty("corp")]
        public int Corporate { get; set; }
    }

    public class ApiResponseModel
    {
        [JsonProperty("stat")]
        public int Status { get; set; }
        [JsonProperty("msg")]
        public string Message { get; set; }
        [JsonProperty("data")]
        public dynamic Data { get; set; }
    }

    

    public class PesalinkResModel
    {
        [JsonProperty("stat")]
        public int Status { get; set; }
        [JsonProperty("msg")]
        public string Message { get; set; }
        [JsonProperty("data")]
        public string Data { get; set; }
    }

    public class ApiResponseData
    {
        [JsonProperty("cusName")]
        public string CusName { get; set; }
        [JsonProperty("amt")]
        public decimal Amount { get; set; }
        [JsonProperty("dueDate")]
        public string DueDate { get; set; }
    }

    public class Utilities
    {
        [JsonProperty("amount")]
        public decimal Amount { get; set; }
        [JsonProperty("clientID")]
        public string Client { get; set; }
        [JsonProperty("MSISDN")]
        public string Phone { get; set; }
        [JsonProperty("billerResponse")]
        public string Response { get; set; }
        [JsonProperty("billerResponseCode")]
        public string ResponseCode { get; set; }
        [JsonProperty("dateProcessed")]
        public string Date { get; set; }
        [JsonProperty("transactionID")]
        public string TransactionID { get; set; }
        [JsonProperty("HASH")]
        public string HASH { get; set; }
        [JsonProperty("status")]
        public string Status { get; set; }
    }

    public class UtilitiesCallback
    {
        [JsonProperty("STATUS")]
        public int Status { get; set; }
        [JsonProperty("MESSAGE")]
        public string Message { get; set; }
    }
    public class CallBackData
    {
        [JsonProperty("packet")]
        public Packet Packet { get; set; }
    }


    public class Packet
    {
        [JsonProperty("statusCode")]
        public string RespStatus { get; set; }
        [JsonProperty("statusDescription")]
        public string RespMsg { get; set; }
        [JsonProperty("payerTransactionID")]
        public string TransID { get; set; }
        [JsonProperty("beepTransactionID")]
        public string TranRef { get; set; }
        [JsonProperty("receiptNumber")]
        public string ReceiptNo { get; set; }
    }

    public class CBKTransactionQuery
    {
        [JsonProperty("tranRef")]
        public string TransReference { get; set; }
    }
}
