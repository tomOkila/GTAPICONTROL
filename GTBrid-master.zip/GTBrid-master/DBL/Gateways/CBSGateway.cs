﻿using DBL.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Gateways
{
    public class CBSGateway
    {

        private string _connstring;
        public CBSGateway(string connstring)
        {
            _connstring = connstring;
        }

        public async Task<CBSRes> PostTxnAsync(CBSPosting txn)
        {
            CBSRes result = new CBSRes();
            try
            {
                using (OracleConnection oraconn = new OracleConnection(_connstring))
                {
                    using (OracleCommand oracomm = new OracleCommand("EONEPKG.GTBPBSC0_FULL", oraconn))
                    {
                        oracomm.CommandType = CommandType.StoredProcedure;
                        if (oraconn.State == ConnectionState.Closed)
                        {
                            oraconn.Open();
                        }

                        oracomm.Parameters.Add("INP_ACCT_FROM", OracleDbType.NVarchar2, 21).Value = txn.DRAccount;
                        oracomm.Parameters.Add("INP_ACCT_TO", OracleDbType.NVarchar2, 21).Value = txn.CRAccount;
                        oracomm.Parameters.Add("INP_TRA_AMT", OracleDbType.Double, 20).Value = txn.Amount;
                        oracomm.Parameters.Add("INP_EXPL_CODE", OracleDbType.Int32, 15).Value = txn.ExplCode;
                        oracomm.Parameters.Add("INP_REMARKS", OracleDbType.NVarchar2, 200).Value = txn.Narration;
                        oracomm.Parameters.Add("INP_RQST_CODE", OracleDbType.NVarchar2, 15).Value = "32";
                        oracomm.Parameters.Add("INP_MAN_APP1", OracleDbType.Int32, 15).Value = 0;
                        oracomm.Parameters.Add("inp_tell_id", OracleDbType.Int32, 15).Value = 9938;
                        oracomm.Parameters.Add("INP_PERIOD", OracleDbType.Int32, 15).Value = 0;
                        oracomm.Parameters.Add("INP_BNK_CODE", OracleDbType.Int32, 15).Value = 53;
                        oracomm.Parameters.Add("inp_doc_num", OracleDbType.Int32, 15).Value = txn.TransID;
                        oracomm.Parameters.Add("INP_DOC_ALP", OracleDbType.NVarchar2, 21).Value = txn.AppName;
                        oracomm.Parameters.Add("out_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                        oracomm.Parameters.Add("inp_tra_seq1", OracleDbType.Int32, 15).Direction = ParameterDirection.Output;
                        oracomm.Parameters.Add("INP_ORIGT_BRA_CODE", OracleDbType.Int32, 15).Value = 999;
                        oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleDbType.NVarchar2, 100).Direction = ParameterDirection.Output;
                        oracomm.ExecuteNonQuery();
                       
                        result = new CBSRes
                        {
                            Status = 0,
                            ResponseCode = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString()
                        };
                        oraconn.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                result = new CBSRes
                {
                    Status = 1
                };
            }
            return result;
        }
    }
}
