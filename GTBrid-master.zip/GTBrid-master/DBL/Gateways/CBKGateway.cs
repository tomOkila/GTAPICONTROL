﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Gateways
{
    public class CBKGateway
    {
        private string _baseUrl;
        private string _userName;
        private string _password;
        public CBKGateway(string url, string username, string password)
        {
            _baseUrl = url;
            _userName = username;
            _password = password;
        }

      

        public async Task<TransactionQuery> QueryTransactions(string tranRef, string endpoint = "transactions/info?transaction_referennce=")
        {
            var url = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + endpoint + tranRef;

            var response =await DoPost("", url);

            //--- Get data
            TransactionQuery respData = JsonConvert.DeserializeObject<TransactionQuery>(response);
            return respData;
        }


        private async Task<string> DoPost(string postData, string url)
        {
            try
            {
                //Uat Certs
                X509Certificate2 cert_chain = new X509Certificate2("E:\\PesalinkCerts\\clientBob.p12", "changeit", X509KeyStorageFlags.MachineKeySet);

                var httpRequest = (HttpWebRequest)WebRequest.Create(url);
                httpRequest.Method = "GET";
                httpRequest.ContentType = "application/json";
                httpRequest.KeepAlive = false;
                httpRequest.ProtocolVersion = HttpVersion.Version10;
                httpRequest.ClientCertificates.Add(cert_chain);
                httpRequest.ServicePoint.Expect100Continue = true;
                ServicePointManager.CheckCertificateRevocationList = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                byte[] reqBytes = new UTF8Encoding().GetBytes(postData);
                httpRequest.ContentLength = reqBytes.Length;
                //Logfile.DBLError("Url "+_url+" Request "+request);
                httpRequest.ServerCertificateValidationCallback = (sender, cert, chain, errors) =>
                {
                    return true;
                };
                using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
                {
                    await reqStream.WriteAsync(reqBytes, 0, reqBytes.Length);
                }

                //---- Get response
                string xmlResponse = null;
                HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();

                using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                {
                    xmlResponse = sr.ReadToEnd();

                    //========== Log response ==========
                    Logfile.DBLError("Status Code " + resp.StatusCode.ToString());
                    // LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsync:Response", xmlResponse);
                    //==================================

                    return xmlResponse;
                }
            }
            catch (WebException wex)
            {

                using (var stream = wex.Response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        string respContent = await reader.ReadToEndAsync();
                        if (!string.IsNullOrEmpty(respContent))
                        {
                            //========== Log response ==========
                            Logfile.DBLError("Status Code " + wex.Status.ToString() + "|" + respContent);
                            return respContent;
                            //==================================
                        }
                    }
                }

                throw wex;
            }
            catch (Exception ex)
            {
                Logfile.DBLError(ex.ToString());
                //LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsynct:ErrorRespose", ex);
                throw ex;
            }
        }

        #region Models
        public class TransactionQuery
        {
            [JsonProperty("transaction reference")]
            public string TransReference { get; set; }
            [JsonProperty("client cui")]
            public string SerialNo { get; set; }
            [JsonProperty("amount")]
            public decimal Amt { get; set; }
            [JsonProperty("currency")]
            public string Cur { get; set; }
            [JsonProperty("intended settlement date")]
            public string Date { get; set; }
        }
        #endregion
    }
}
