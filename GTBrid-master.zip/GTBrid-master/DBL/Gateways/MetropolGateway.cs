﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace DBL.Gateways
{
    class MetropolGateway
    {
        public string LogFile { get; set; }
        private string _baseUrl, _userName, _password;
        public MetropolGateway(string baseUrl, string userName, string password)
        {
            _baseUrl = baseUrl;
            _userName = userName;
            _password = password;
        }

        public async Task<MetropolHealth> HealthCheck(string jsonData)
        {

            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + "health";
            var headers = new Dictionary<string, string>();
            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Get, headers))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new MetropolHealth();

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<MetropolHealth>(result.Data);

                    return respData;

                }
                else
                {
                    //--- Error response
                    Logfile.UtilityError("HealthCheck :" + result.Exception.ToString());
                    return new MetropolHealth
                    {
                        Success = false,
                        ApiDesc = "Request failed due to an error!"
                    };
                }
            }
        }

        public async Task<MetropolHealth> CRBLookUp(string jsonData,string hash,string timestamp, string endpoint = "score/consumer")
        {
            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + endpoint;

            //--- Create headers
            var headers = new Dictionary<string, string>();
            headers.Add("X-METROPOL-REST-API-KEY", _userName);
            headers.Add("X-METROPOL-REST-API-HASH", hash);
            headers.Add("X-METROPOL-REST-API-TIMESTAMP", timestamp);
            HttpConnect httpClient = new HttpConnect(_baseUrl, HttpConnect.RequestType.Post,headers);
            Exception ex;
            var postResults = httpClient.SendRequest(jsonData, out ex);

            if (string.IsNullOrEmpty(postResults))
            {
                Logfile.UtilityError("CRBLookUp :" + ex.ToString());
                return new MetropolHealth
                {
                    Success = true,
                    ApiDesc = "Request failed due to an error!"
                };
            }
            else
            {
                var respData = new MetropolHealth();

                //--- Get data
                respData = JsonConvert.DeserializeObject<MetropolHealth>(postResults);

                return respData;
               
            }

            //using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Post, headers))
            //{
            //    //--- Make request
            //    var result = await restApi.SendRequestAsync(jsonData);

            //    //---- Process result
            //    if (result.Success)
            //    {
            //        var respData = new MetropolHealth();

            //        //--- Get data
            //        respData = JsonConvert.DeserializeObject<MetropolHealth>(result.Data);

            //        return respData;
            //    }
            //    else
            //    {
            //        //--- Error response
            //        Logfile.UtilityError("CRBLookUp :" + result.Exception.ToString());
            //        return new MetropolHealth
            //        {
            //            Success = false,
            //            ApiDesc = "Request failed due to an error!"
            //        };
            //    }
            //}
            ////}

        }



        public class MetropolHealth
        {
            [JsonProperty("api_code")]
            public string ApiCode { get; set; }
            [JsonProperty("api_code_description")]
            public string ApiDesc { get; set; }
            [JsonProperty("has_error")]
            public bool Success { get; set; }
            [JsonProperty("credit_score")]
            public string CreditScore { get; set; }
        }

        public class MetropolScore
        {
            [JsonProperty("report_type")]
            public int Report { get; set; }
            [JsonProperty("identity_number")]
            public string IDNo { get; set; }
            [JsonProperty("identity_type")]
            public string Type { get; set; }
            [JsonProperty("mobile_score")]
            public bool Score { get; set; }
        }
    }


}
