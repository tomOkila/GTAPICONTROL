﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace DBL.Gateways
{
    public class CardGateway
    {
        private string _url;
        private string _userName;
        private string _password;
        private string _logfile;

        public CardGateway(string url, string username, string password,string logfile)
        {
            _url = url;
            _userName = username;
            _password = password;
            _logfile = logfile;
        }

        #region Public Methods
        public async Task<InitResponse> InitSession(GenericModel model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "InitSession";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("fimi:InitSessionRq");

                    writer.WriteStartElement("fimi:Request");
                    writer.WriteAttributeString("Ver","16.14");
                    writer.WriteAttributeString("Product", "FIMI");
                    writer.WriteAttributeString("Clerk", model.Data2);

                    writer.WriteStartElement("fimil:CurrencyCodes");
                    writer.WriteStartElement("fimil:Row");
                    writer.WriteStartElement("fimil:Value");
                    writer.WriteString("0");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                   
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soap:Header></soap:Header>", "<soap:Header/>");


                    //var response = await DoPost(xmlString);
                    var response = File.ReadAllText("C:\\Users\\Administrator\\Desktop\\GTBrid.0\\Request.xml");

                    return ProcessInitRequest(response);
                }
            }
        }

        public async Task<InitResponse> Logon(GenericModel model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "Logon";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("fimi:LogonRq");

                    writer.WriteStartElement("fimi:Request");
                    writer.WriteAttributeString("Ver", "16.14");
                    writer.WriteAttributeString("Product", "FIMI");
                    writer.WriteAttributeString("Session", model.Data2);
                    writer.WriteAttributeString("Clerk", model.Data1);
                    writer.WriteAttributeString("Password", model.Data3);

                    writer.WriteStartElement("fimil:CAPToken");
                    writer.WriteString("0");
                    writer.WriteFullEndElement();


                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soap:Header></soap:Header>", "<soap:Header/>");


                    var response = await DoPost(xmlString);
                    return ProcessLogonRequest(response);
                }
            }
        }

        public async Task<InitResponse> SetCardStatus(GenericModel model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "SetCardStatus";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("fimi:SetCardStatusRq");

                    writer.WriteStartElement("fimi:Request");
                    writer.WriteAttributeString("Ver", "16.14");
                    writer.WriteAttributeString("Product", "FIMI");
                    writer.WriteAttributeString("Session", model.Data2);
                    writer.WriteAttributeString("Clerk", model.Data1);
                    writer.WriteAttributeString("Password", model.Data3);

                    //writer.WriteStartElement("fimil:MBR");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:PAN");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:Status");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:ChangeReason");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:NeedNotify");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:PersonID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:CardUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:ParentPAN");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:ParentMBR");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:ParentCardUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:Reissued");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soap:Header></soap:Header>", "<soap:Header/>");


                    var response = await DoPost(xmlString);
                    return ProcessInitRequest(response);
                }
            }
        }

        public async Task<InitResponse> AcctCredit(GenericModel model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "AcctCredit";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("fimi:AcctCreditRq");

                    writer.WriteStartElement("fimi:Request");
                    writer.WriteAttributeString("Ver", "16.14");
                    writer.WriteAttributeString("Product", "FIMI");
                    writer.WriteAttributeString("Session", model.Data2);
                    writer.WriteAttributeString("Clerk", model.Data1);
                    writer.WriteAttributeString("Password", model.Data3);

                    //writer.WriteStartElement("fimil:InstName");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:Account");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:AccountUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:PAN");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:MBR");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:CardUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:PersonID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:Amount");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:CorrespAcct");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:TranNumber");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:OrigAmount");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:OrigCurrency");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:IgnoreImpact");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:NeedNotify");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:PrevTranId");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:RefreshSeqNo");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:ChangeReason");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:UseBonusDebt");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:BonusProgramName");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:PrizeID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();


                    //writer.WriteStartElement("fimil:PrizeQuantity");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soap:Header></soap:Header>", "<soap:Header/>");


                    var response = await DoPost(xmlString);
                    return ProcessInitRequest(response);
                }
            }
        }

        public async Task<InitResponse> BalanceInquiry(GenericModel model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "BalanceInquiry";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("fimi:BalanceInquiryRq");

                    writer.WriteStartElement("fimi:Request");
                    writer.WriteAttributeString("Ver", "16.14");
                    writer.WriteAttributeString("Product", "FIMI");
                    writer.WriteAttributeString("Session", model.Data2);
                    writer.WriteAttributeString("Clerk", model.Data1);
                    writer.WriteAttributeString("Password", model.Data3);

                    //writer.WriteStartElement("fimil:InstName");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:Account");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:AccountUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("fimil:PAN");
                    writer.WriteString("");
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:MBR");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:CardUID");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:PersonId");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("fimil:Currency");
                    //writer.WriteString("");
                    //writer.WriteFullEndElement();


                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soap:Header></soap:Header>", "<soap:Header/>");


                    var response = await DoPost(xmlString);
                    return ProcessInitRequest(response);
                }
            }
        }

        private InitResponse ProcessInitRequest(string result)
        {
            var response = new InitResponse
            {
                Session = "",
                NextChallenge = ""
            };

            XDocument xml = XDocument.Parse(result);
            var myData = xml.Descendants().Where(x => x.Name.LocalName == "InitSessionRp").FirstOrDefault();
            if (myData != null)
            {
                response.NextChallenge = (string)myData.Descendants().Where(x => x.Name.LocalName == "Response").FirstOrDefault().Attribute("NextChallenge").Value;
               
                response.Session = (string)myData.Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault();
            }

            return response;

        }

        private InitResponse ProcessLogonRequest(string result)
        {
            var response = new InitResponse
            {
                Session = "",
                NextChallenge = ""
            };

            XDocument xml = XDocument.Parse(result);
            var myData = xml.Descendants().Where(x => x.Name.LocalName == "LogonRp").FirstOrDefault();
            if (myData != null)
            {
                response.NextChallenge = (string)myData.Element("Response").Attribute("TranId").Value;
            }

            return response;

        }

        #endregion

        #region Private Methods
        private void CreateRequestHeader(XmlTextWriter writer)
        {
            //---- Write root
            writer.WriteStartDocument();
            writer.WriteStartElement("soap:Envelope");
            writer.WriteAttributeString("xmlns", "soap", null, "http://www.w3.org/2003/05/soap-envelope");
            writer.WriteAttributeString("xmlns", "fimi", null, "http://schemas.compassplus.com/two/1.0/fimi.xsd");
            writer.WriteAttributeString("xmlns", "fimil", null, "http://schemas.compassplus.com/two/1.0/fimi_types.xsd");
            //---- Write header
            writer.WriteStartElement("soap:Header");
            writer.WriteFullEndElement();
            //---- Write body
            writer.WriteStartElement("soap:Body");
        }

        private string FormatXml(string xml)
        {
            try
            {
                var stringBuilder = new StringBuilder();

                var element = XDocument.Parse(xml);

                XmlWriterSettings writerSettings = new XmlWriterSettings();
                writerSettings.OmitXmlDeclaration = true;
                writerSettings.Indent = true;
                writerSettings.NewLineHandling = NewLineHandling.None;

                using (var xmlWriter = XmlWriter.Create(stringBuilder, writerSettings))
                    element.Save(xmlWriter);

                return stringBuilder.ToString();
            }
            catch (Exception ex)
            {
                //AppUtil.Log.Error(LogFile, "Format xml", new Exception(ex.Message + "||" + xml));
                return xml;
            }
        }

        private async Task<string> DoPost(string postData)
        {
            AppUtil.Log.Infor(_logfile, "CardGateway.DoPost", _url+" "+postData);

            var httpRequest = (HttpWebRequest)WebRequest.Create(_url);
            httpRequest.Method = "POST";
            httpRequest.ContentType = "application/xml";
            httpRequest.KeepAlive = false;
            httpRequest.ProtocolVersion = HttpVersion.Version10;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;



            byte[] reqBytes = new UTF8Encoding().GetBytes(postData);
            httpRequest.ContentLength = reqBytes.Length;

            using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
            {
                await reqStream.WriteAsync(reqBytes, 0, reqBytes.Length);
            }

            //---- Get response
            string xmlResponse = null;
            HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();
            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
            {
                xmlResponse = await sr.ReadToEndAsync();

                //========== Log response ==========
                AppUtil.Log.Error(_logfile, "CardGateway.DoPost:Respose", xmlResponse);
                //==================================

                return xmlResponse;
            }
        }

        #endregion
    }
}
