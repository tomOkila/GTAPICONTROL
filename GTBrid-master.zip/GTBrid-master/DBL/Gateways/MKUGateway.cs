﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace DBL.Gateways
{
    public class MKUGateway
    {
        private string _url;
        private string _userName;
        private string _password;
        public MKUGateway(string url, string username, string password)
        {
            _url = url;
            _userName = username;
            _password = password;
        }

        #region Public Methods

        public async Task<StudentName> GetStudentName(MpesaPayment model)
        {
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("soap:getStudentName");
                    writer.WriteAttributeString("soapenv", "encodingStyle", null, "http://schemas.xmlsoap.org/soap/encoding/");

                    writer.WriteStartElement("STUDENT_NUMBER");
                    writer.WriteString(model.AccountNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("username");
                    writer.WriteString(_userName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("password");
                    writer.WriteString(_password);
                    writer.WriteFullEndElement();


                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soapenv:Header></soapenv:Header>", "<soapenv:Header/>");


                    var response = await DoPost(xmlString);
                    return ProcessStudentName(response);
                }
            }
        }

        public async Task<PaymentResponse> PaySchoolFees(MpesaPayment model)
        {
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("soap:PaymentNotification");
                    writer.WriteAttributeString("soapenv", "encodingStyle", null, "http://schemas.xmlsoap.org/soap/encoding/");

                    writer.WriteStartElement("billNumber");
                    writer.WriteString(model.BillNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("billAmount");
                    writer.WriteString(model.Amt);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("customerRefNumber");
                    writer.WriteString(model.CustRefno);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("bankreference");
                    writer.WriteString(model.BankRef);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("paymentMode");
                    writer.WriteString(model.PayMode);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("transactionDate");
                    writer.WriteString(model.TransDate);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("phonenumber");
                    writer.WriteString(model.Phone);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("debitaccount");
                    writer.WriteString(model.DebitAcct);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("debitcustname");
                    writer.WriteString(model.DebitCustName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("creditaccount");
                    writer.WriteString(model.CreditAcct);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("creditcusname");
                    writer.WriteString(model.CreditCustName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("studentname");
                    writer.WriteString(model.StudentName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("transactiondescription");
                    writer.WriteString(model.TransDesc);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("paymentreason");
                    writer.WriteString(model.PayReason);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("paymentnaration");
                    writer.WriteString(model.PayNarration);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("username");
                    writer.WriteString(_userName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("password");
                    writer.WriteString(_password);
                    writer.WriteFullEndElement();


                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());

                    xmlString = xmlString.Replace("<soapenv:Header></soapenv:Header>", "<soapenv:Header/>");


                    var response = await DoPost(xmlString);
                    return PaymentResponse(response);
                }
            }
        }
        #endregion

        #region Private Methods
        private StudentName ProcessStudentName(string response)
        {
            StudentName model = new StudentName();
            XDocument Xml = XDocument.Parse(response);

            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "getStudentNameResponse").FirstOrDefault();

            if (myData != null)
            {

                model = new StudentName
                {
                    Name = (string)myData.Descendants().Where(x => x.Name.LocalName == "STUDENT_NAME").FirstOrDefault()
                };


            }
            else
            {

                model = new StudentName
                {
                    Name = ""
                };
            }
            return model;
        }


        private PaymentResponse PaymentResponse(string response)
        {
            PaymentResponse model = new PaymentResponse();
            XDocument Xml = XDocument.Parse(response);

            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "PaymentNotificationResponse").FirstOrDefault();

            if (myData != null)
            {

                model = new PaymentResponse
                {
                    ResponseCode = (string)myData.Descendants().Where(x => x.Name.LocalName == "responseCode").FirstOrDefault(),
                    ResponseMsg = (string)myData.Descendants().Where(x => x.Name.LocalName == "responseCode").FirstOrDefault()
                };


            }
            else
            {

                model = new PaymentResponse
                {
                    ResponseCode = "500"
                };
            }
            return model;
        }

        private void CreateRequestHeader(XmlTextWriter writer)
        {
            //---- Write root
            writer.WriteStartDocument();
            writer.WriteStartElement("soapenv:Envelope");
            writer.WriteAttributeString("xmlns", "xsi", null, "http://www.w3.org/2001/XMLSchema-instance");
            writer.WriteAttributeString("xmlns", "xsd", null, "http://www.w3.org/2001/XMLSchema");
            writer.WriteAttributeString("xmlns", "soapenv", null, "http://schemas.xmlsoap.org/soap/envelope/");
            writer.WriteAttributeString("xmlns", "soap", null, "http://soapinterop.org/");

            //---- Write header
            writer.WriteStartElement("soapenv:Header");
            writer.WriteFullEndElement();
            //---- Write body
            writer.WriteStartElement("soapenv:Body");
        }

        private string FormatXml(string xml)
        {
            try
            {
                var stringBuilder = new StringBuilder();

                var element = XDocument.Parse(xml);

                XmlWriterSettings writerSettings = new XmlWriterSettings();
                writerSettings.OmitXmlDeclaration = true;
                writerSettings.Indent = true;
                writerSettings.NewLineHandling = NewLineHandling.None;

                using (var xmlWriter = XmlWriter.Create(stringBuilder, writerSettings))
                    element.Save(xmlWriter);

                return stringBuilder.ToString();
            }
            catch (Exception ex)
            {
                //AppUtil.Log.Error(LogFile, "Format xml", new Exception(ex.Message + "||" + xml));
                return xml;
            }
        }

        private async Task<string> DoPost(string postData)
        {

            var httpRequest = (HttpWebRequest)WebRequest.Create(_url);
            httpRequest.Method = "POST";
            httpRequest.ContentType = "text/xml";
            //httpRequest.Headers.Add("SOAPAction", _url);
            httpRequest.KeepAlive = false;
            httpRequest.ProtocolVersion = HttpVersion.Version10;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //NetworkCredential credential = new NetworkCredential();
            //credential.UserName = _userName;
            //credential.Password = _password;
            //httpRequest.Credentials = credential;

            byte[] reqBytes = new UTF8Encoding().GetBytes(postData);
            httpRequest.ContentLength = reqBytes.Length;

            using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
            {
                await reqStream.WriteAsync(reqBytes, 0, reqBytes.Length);
            }

            //---- Get response
            string xmlResponse = null;
            HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();
            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
            {
                xmlResponse = await sr.ReadToEndAsync();

                //========== Log response ==========
                AppUtil.Log.Error("", "CardGateway.DoPost:Respose", xmlResponse);
                //==================================

                return xmlResponse;
            }
        }

        #endregion
    }
}
