﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace DBL.Gateways
{
    public class PesaLinkGateway
    {
        private string _url;
        private string _userName;
        private string _password;
        public PesaLinkGateway(string url,string username,string password)
        {
            _url = url;
            _userName = username;
            _password = password;
        }

        #region Public Methods
        public async Task<PaymentRespose> PayOutwards(PaymentRequest model, DataTable dt,GenericModel generic, string mainRef)
        {
           _url= _url + (_url.EndsWith("/") ? "" : "/")  + "async/v1/credit-transfer";

            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09");

                    writer.WriteStartElement("FIToFICstmrCdtTrf");

                    writer.WriteStartElement("GrpHdr");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(mainRef);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(generic.Data8);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("NbOfTxs");
                    writer.WriteString(dt.Rows.Count.ToString());
                    writer.WriteFullEndElement();

                    if (dt.Rows.Count > 1)
                    {
                        writer.WriteStartElement("TtlIntrBkSttlmAmt");
                        writer.WriteAttributeString("Ccy", model.Currency);
                        writer.WriteString(model.TotalAmount.ToString("0"));
                        writer.WriteFullEndElement();
                    }

                    writer.WriteStartElement("SttlmInf");
                    writer.WriteStartElement("SttlmMtd");
                    writer.WriteString("CLRG");
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("ClrSys");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString("IPS");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PmtTpInf");

                    writer.WriteStartElement("SvcLvl");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.TxnType);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("LclInstrm");
                    writer.WriteStartElement("Cd");
                    writer.WriteString("INST");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CtgyPurp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Channel);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstgAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(generic.Data4);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstdAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(generic.Data5);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    foreach (DataRow txns in dt.Rows)
                    {
                        writer.WriteStartElement("CdtTrfTxInf");
                        writer.WriteStartElement("PmtId");
                        writer.WriteStartElement("EndToEndId");
                        writer.WriteString(txns["TranRef"].ToString());
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("IntrBkSttlmAmt");
                        writer.WriteAttributeString("Ccy", txns["Currency"].ToString());
                        writer.WriteString(txns["Amount"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("AccptncDtTm");
                        writer.WriteString(generic.Data8);
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChrgBr");
                        writer.WriteString("SLEV");
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("Dbtr");
                        writer.WriteStartElement("Nm");
                        writer.WriteString(txns["DrAccountName"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("CtctDtls");
                        writer.WriteStartElement("PhneNb");
                        writer.WriteString(txns["Phone"].ToString());
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();

                        writer.WriteStartElement("DbtrAcct");
                        writer.WriteStartElement("Id");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(txns["DrAccount"].ToString());
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("Nm");
                        writer.WriteString(txns["DrAccountName"].ToString());
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("DbtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(generic.Data4);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("CdtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(txns["Beneficiary"].ToString());
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        
                        writer.WriteStartElement("Cdtr");
                        if (!string.IsNullOrEmpty(txns["CrAccountPhone"].ToString()))
                        {
                            writer.WriteStartElement("Nm");
                            writer.WriteString(txns["CrAccountName"].ToString());
                            writer.WriteFullEndElement();
                            writer.WriteStartElement("CtctDtls");
                            writer.WriteStartElement("PhneNb");
                            writer.WriteString(txns["CrAccountPhone"].ToString());
                            writer.WriteFullEndElement();
                            writer.WriteFullEndElement();
                        }
                        writer.WriteFullEndElement();
                        

                        if(!string.IsNullOrEmpty(txns["CrAccount"].ToString()))
                        {
                            writer.WriteStartElement("CdtrAcct");
                            writer.WriteStartElement("Id");
                            writer.WriteStartElement("Othr");
                            writer.WriteStartElement("Id");
                            writer.WriteString(txns["CrAccount"].ToString());
                            writer.WriteFullEndElement();
                            writer.WriteFullEndElement();
                            writer.WriteFullEndElement();
                            writer.WriteFullEndElement();
                        }
                        

                        //writer.WriteStartElement("UltmtCdtr");
                        //writer.WriteStartElement("Nm");
                        //writer.WriteString(txns["CrAccountName"].ToString());
                        // writer.WriteFullEndElement();
                        //writer.WriteStartElement("CtctDtls");
                        //writer.WriteStartElement("PhneNb");
                        //writer.WriteString(txns.CrPhone);
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();

                        writer.WriteStartElement("Purp");
                        writer.WriteStartElement("Prtry");
                        writer.WriteString("001");
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("RmtInf");

                        writer.WriteStartElement("Ustrd");
                        writer.WriteString(txns["Narration"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();
                    }
                   
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    xmlString=xmlString.Replace("<Cdtr></Cdtr>", "<Cdtr/>");
                    var response = await DoPost(xmlString);
                    return new PaymentRespose
                    {
                        Status = 0,
                        Message = "Transaction Posted Awaiting Response"
                    };
                }
            }
        }

        
        public async Task<string> Unavailable(Unavailable model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/system-event-notification";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:admi.004.001.02");

                    writer.WriteStartElement("SysEvtNtfctn");

                    writer.WriteStartElement("EvtInf");

                    writer.WriteStartElement("EvtCd");
                    writer.WriteString("UNVL");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("MsgId");
                    writer.WriteString("0053");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("EvtParam");
                    writer.WriteString(model.FromDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("EvtParam");
                    writer.WriteString(model.ToDate.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("EvtDesc");
                    writer.WriteString(model.Reason);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("EvtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyyMMddHHmmss"));
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPost(xmlString);
                    return "";
                }
            }
        }

        public async Task<string> ReturnVerification()
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/event-acknowledgement";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:admi.011.001.01");

                    writer.WriteStartElement("SysEvtAck");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(DateTime.Now.ToString("yyyyMMddHHmmss"));
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPost(xmlString);
                    return "";
                }
            }
        }

        public async Task<string> PayINwards(PaymentAccpetance model, GenericModel result)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/payment-status-report";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:pacs.002.001.11");

                    writer.WriteStartElement("FIToFIPmtStsRpt");

                    writer.WriteStartElement("GrpHdr");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstgAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString("0053");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstdAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString("9999");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlGrpInfAndSts");

                    writer.WriteStartElement("OrgnlMsgId");
                    writer.WriteString(model.AccMsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlMsgNmId");
                    writer.WriteString(model.MsgType);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlCreDtTm");
                    writer.WriteString(model.AccDate);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    

                    writer.WriteStartElement("TxInfAndSts");

                    writer.WriteStartElement("StsId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlEndToEndId");
                    writer.WriteString(model.OrgEndToEnd);
                    writer.WriteFullEndElement();

                    if (!string.IsNullOrEmpty(result.RespMsg))
                    {
                        writer.WriteStartElement("TxSts");
                        writer.WriteString("RJCT");
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("StsRsnInf");
                        writer.WriteStartElement("Orgtr");
                        writer.WriteStartElement("Id");
                        writer.WriteStartElement("OrgId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString("0053");
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("Rsn");
                        if (result.RespStat == 1)
                        {
                            writer.WriteStartElement("Cd");
                            writer.WriteString(result.RespMsg);
                            writer.WriteEndElement();
                        }
                        else
                        {
                            writer.WriteStartElement("Prtry");
                            writer.WriteString(result.RespMsg);
                            writer.WriteFullEndElement();
                        }
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }
                    else
                    {
                        writer.WriteStartElement("TxSts");
                        writer.WriteString("ACCP");
                        writer.WriteFullEndElement();
                    }

                    writer.WriteStartElement("AccptncDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlTxRef");

                    writer.WriteStartElement("IntrBkSttlmAmt");
                    writer.WriteAttributeString("Ccy", model.Currency);
                    writer.WriteString(model.Amount.ToString());
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("ReqdExctnDt");
                    writer.WriteStartElement("DtTm");
                    writer.WriteString(model.AccDate);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PmtTpInf");
                    writer.WriteStartElement("SvcLvl");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.TxnType);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("LclInstrm");
                    writer.WriteStartElement("Cd");
                    writer.WriteString(model.LclInst);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("CtgyPurp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Channel);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("RmtInf");
                    writer.WriteStartElement("Ustrd");
                    writer.WriteString(model.Narration);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();


                    writer.WriteStartElement("Dbtr");
                    writer.WriteStartElement("Pty");
                    writer.WriteStartElement("Nm");
                    writer.WriteString(HttpUtility.HtmlEncode(model.DebCBSName));
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DebAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("CtctDtls");
                    writer.WriteStartElement("PhneNb");
                    writer.WriteString(model.DebCBSPhone);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DebAccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Nm");
                    writer.WriteString(HttpUtility.HtmlEncode(model.DebCBSName));
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DebAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CdtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.CrAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    if (result.RespStat == 0)
                    {
                        writer.WriteStartElement("Cdtr");
                        writer.WriteStartElement("Pty");
                        writer.WriteStartElement("Nm");
                        writer.WriteString(HttpUtility.HtmlEncode(result.Data6));
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("Id");
                        writer.WriteStartElement("OrgId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(model.CrAccAgt);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("CtctDtls");

                        writer.WriteStartElement("PhneNb");
                        writer.WriteString("+254-" + result.Data7.Substring(result.Data7.Length- 9, 9));
                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }
                    else
                    {
                        writer.WriteStartElement("Cdtr");
                        writer.WriteStartElement("Pty");
                        writer.WriteStartElement("Nm");
                        writer.WriteString(HttpUtility.HtmlEncode("CREDITOR NAME UNAVAILABLE"));
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("Id");
                        writer.WriteStartElement("OrgId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(model.CrAccAgt);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("CtctDtls");

                        writer.WriteStartElement("PhneNb");
                        writer.WriteString("+254-709485000");
                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }

                    writer.WriteStartElement("CdtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.CrAccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();


                    if (result.RespStat == 0)
                    {
                        writer.WriteStartElement("UltmtCdtr");
                        writer.WriteStartElement("Pty");
                        writer.WriteStartElement("Nm");
                        writer.WriteString(HttpUtility.HtmlEncode(result.Data6));
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }
                    

                    writer.WriteStartElement("Purp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Purpose);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPost(xmlString);
                    return "";
                }
            }
        }

        public async Task<AuthResponse> ValidateCustomer(AuthData model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "sync/v1/verification-request";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:acmt.023.001.02");

                    writer.WriteStartElement("IdVrfctnReq");

                    writer.WriteStartElement("Assgnmt");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(model.VerifyId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("FrstAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString("0053");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Assgnr");
                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString("0053");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Assgne");
                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString("9999");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Vrfctn");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.VerifyId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PtyAndAcctId");
                    writer.WriteStartElement("Acct");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.AccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DestinationId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPost(xmlString);
                    return ProcessAuthReponse(response);
                }
            }
        }

        public async Task<string> ReturnAuthResponse(GenericModel result, AuthData model)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/verification-report";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:acmt.024.001.02");

                    writer.WriteStartElement("IdVrfctnRpt");

                    writer.WriteStartElement("Assgnmt");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(Guid.NewGuid().ToString("N"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("FrstAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DestinationId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Assgnr");
                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.ReceiverId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Assgne");
                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.SenderId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlAssgnmt");
                    writer.WriteStartElement("MsgId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(model.Date);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("FrstAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DestinationId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Rpt");
                    writer.WriteStartElement("OrgnlId");
                    writer.WriteString(model.VerifyId);
                    writer.WriteFullEndElement();



                    if (result.RespStat != 0)
                    {
                        writer.WriteStartElement("Vrfctn");
                        writer.WriteString("false");
                        writer.WriteFullEndElement();
                        writer.WriteStartElement("Rsn");
                        if (result.RespStat == 1)
                        {
                            writer.WriteStartElement("Cd");
                            writer.WriteString(result.RespMsg);
                            writer.WriteEndElement();
                        }
                        else
                        {
                            writer.WriteStartElement("Prtry");
                            writer.WriteString(result.RespMsg);
                            writer.WriteFullEndElement();
                        }
                        writer.WriteFullEndElement();
                    }
                    else
                    {
                        writer.WriteStartElement("Vrfctn");
                        writer.WriteString("true");
                        writer.WriteFullEndElement();
                    }



                    writer.WriteStartElement("OrgnlPtyAndAcctId");

                    writer.WriteStartElement("Acct");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.AccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Agt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.ReceiverId);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    if(result.RespStat == 0)
                    {
                        writer.WriteStartElement("UpdtdPtyAndAcctId");

                        writer.WriteStartElement("Pty");
                        writer.WriteStartElement("Nm");
                        writer.WriteString((HttpUtility.HtmlEncode(result.Data4)));
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("Acct");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(result.Data5);
                        writer.WriteFullEndElement();
                        //writer.WriteStartElement("SchmeNm");
                        //writer.WriteStartElement("Prtry");
                        //writer.WriteString(msg);
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("Agt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(model.ReceiverId);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteFullEndElement();
                    }

                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPost(xmlString);
                    return xmlString;
                }
            }

        }

        public async Task<string> TransactionQuery( GenericModel generic, PaymentLookUp look)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/payment-status-request";

            string MsgId = Guid.NewGuid().ToString("N");
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:pacs.028.001.04");

                    writer.WriteStartElement("FIToFIPmtStsReq");

                    writer.WriteStartElement("GrpHdr");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstgAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(look.GTB);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstdAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(look.IPS);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlGrpInf");
                    writer.WriteStartElement("OrgnlMsgId");
                    writer.WriteString(look.MainRef);
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("OrgnlMsgNmId");
                    writer.WriteString(look.MsgNm);
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("OrgnlCreDtTm");
                    writer.WriteString(look.CreateDate);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("TxInf");

                    writer.WriteStartElement("StsReqId");
                    writer.WriteString(look.MainRef);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlEndToEndId");
                    writer.WriteString(look.UniqueRef);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("AccptncDtTm");
                    writer.WriteString(look.CreateDate);
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("OrgnlTxRef");
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlTxRef");

                    writer.WriteStartElement("IntrBkSttlmAmt");
                    writer.WriteAttributeString("Ccy", look.Currency);
                    writer.WriteString(look.Amount.ToString("0"));
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("ReqdExctnDt");
                    //writer.WriteStartElement("DtTm");
                    //writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("SttlmInf");
                    //writer.WriteStartElement("SttlmMtd");
                    //writer.WriteString("CLRG");
                    //writer.WriteFullEndElement();
                    //writer.WriteStartElement("ClrSys");
                    //writer.WriteStartElement("Prtry");
                    //writer.WriteString("IPS");
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("PmtTpInf");

                    //writer.WriteStartElement("SvcLvl");
                    //writer.WriteStartElement("Prtry");
                    //writer.WriteString(look.TranType);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("LclInstrm");
                    //writer.WriteStartElement("Cd");
                    //writer.WriteString("INST");
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("CtgyPurp");
                    //writer.WriteStartElement("Prtry");
                    //writer.WriteString(look.Channel);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("MndtRltdInf");

                    //writer.WriteStartElement("CdtTrfMndt");
                    //writer.WriteStartElement("MndtId");
                    //writer.WriteString(look.OrigReff);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("RmtInf");

                    //writer.WriteStartElement("Ustrd");
                    //writer.WriteString(look.Narration);
                    //writer.WriteFullEndElement();

                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("Dbtr");
                    writer.WriteStartElement("Pty");
                    writer.WriteStartElement("Nm");
                    writer.WriteString(look.CustName);
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(look.CustAcc);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("CtctDtls");
                    writer.WriteStartElement("PhneNb");
                    writer.WriteString(look.Phone);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(look.CustAcc);
                    writer.WriteFullEndElement();
                    //writer.WriteStartElement("SchmeNm");
                    //writer.WriteStartElement("Prtry");
                    //writer.WriteString("PHNE");
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    if (look.Type != 1) 
                    {
                        writer.WriteStartElement("DbtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(look.GTB);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("CdtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(look.BankCode);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                    }
                    else
                    {
                        writer.WriteStartElement("DbtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(look.BankCode);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("CdtrAgt");
                        writer.WriteStartElement("FinInstnId");
                        writer.WriteStartElement("Othr");
                        writer.WriteStartElement("Id");
                        writer.WriteString(look.GTB);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }
                    

                    //writer.WriteStartElement("Cdtr");
                    //writer.WriteStartElement("Pty");
                    //writer.WriteStartElement("Nm");
                    //writer.WriteString(look.BeneName);
                    //writer.WriteFullEndElement();
                    //writer.WriteStartElement("Id");
                    //writer.WriteStartElement("OrgId");
                    //writer.WriteStartElement("Othr");
                    //writer.WriteStartElement("Id");
                    //writer.WriteString(look.BankCode);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    ////writer.WriteStartElement("CtctDtls");
                    ////writer.WriteStartElement("PhneNb");
                    ////writer.WriteString("");
                    ////writer.WriteFullEndElement();
                    ////writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("CdtrAcct");
                    //writer.WriteStartElement("Id");
                    //writer.WriteStartElement("Othr");
                    //writer.WriteStartElement("Id");
                    //writer.WriteString(look.DestAcc);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteStartElement("Nm");
                    //writer.WriteString(look.BeneName);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("UltmtCdtr");
                    //writer.WriteStartElement("Nm");
                    //writer.WriteString(look.BeneName);
                    //writer.WriteFullEndElement();
                    //writer.WriteStartElement("CtctDtls");
                    //writer.WriteStartElement("PhneNb");
                    //writer.WriteString(txns.CrPhone);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    //writer.WriteStartElement("Purp");
                    //writer.WriteStartElement("Prtry");
                    //writer.WriteString(look.Purpose);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    xmlString = xmlString.Replace("<Cdtr></Cdtr>", "<Cdtr/>");
                    //xmlString = xmlString.Replace("<OrgnlTxRef></OrgnlTxRef>", "<OrgnlTxRef>");
                    //xmlString = xmlString.Replace("<OrgnlTxRef><OrgnlTxRef>", "<OrgnlTxRef></OrgnlTxRef>");

                    var response = await DoPost(xmlString);
                    return response;
                }
            }
        }

        public async Task<string> PayForRjct(PaymentInst model, GenericModel result)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/payment-initiation-status-report";

            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:pain.002.001.11");

                    writer.WriteStartElement("CstmrPmtStsRpt");

                    writer.WriteStartElement("GrpHdr");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InitgPty");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(result.Data4);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("FwdgAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(result.Data4);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlGrpInfAndSts");

                    writer.WriteStartElement("OrgnlMsgId");
                    writer.WriteString(model.AccMsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlMsgNmId");
                    writer.WriteString(model.MsgType);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlCreDtTm");
                    writer.WriteString(model.SenderDate);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();


                    writer.WriteStartElement("OrgnlPmtInfAndSts");

                    writer.WriteStartElement("OrgnlPmtInfId");
                    writer.WriteString(model.AccMsgId);
                    writer.WriteFullEndElement();


                    writer.WriteStartElement("PmtInfSts");
                    writer.WriteString("RJCT");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("StsRsnInf");
                    writer.WriteStartElement("Orgtr");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(result.Data5);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Rsn");
                    writer.WriteStartElement("Cd");
                    writer.WriteString(result.RespMsg);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("TxInfAndSts");

                    writer.WriteStartElement("StsId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlEndToEndId");
                    writer.WriteString(model.OrgEndToEnd);
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("AccptncDtTm");
                    //writer.WriteString(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("OrgnlTxRef");

                    writer.WriteStartElement("IntrBkSttlmAmt");
                    writer.WriteAttributeString("Ccy", model.Currency);
                    writer.WriteString(model.Amount.ToString());
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("ReqdExctnDt");
                    writer.WriteStartElement("DtTm");
                    writer.WriteString(model.AccDate);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("SttlmInf");
                    writer.WriteStartElement("SttlmMtd");
                    writer.WriteString("CLRG");
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("ClrSys");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString("IPS");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PmtTpInf");
                    writer.WriteStartElement("SvcLvl");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.TxnType);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("LclInstrm");
                    writer.WriteStartElement("Cd");
                    writer.WriteString(model.LclInst);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("CtgyPurp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Channel);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("RmtInf");
                    if (!string.IsNullOrEmpty(model.Narration))
                    {
                        writer.WriteStartElement("Ustrd");
                        writer.WriteString(model.Narration);
                        writer.WriteFullEndElement();
                    }
                    //writer.WriteStartElement("Strd");
                    //writer.WriteStartElement("CdtrRefInf");
                    //writer.WriteStartElement("Ref");
                    //writer.WriteString(model.Purpose);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    writer.WriteFullEndElement();


                    writer.WriteStartElement("Dbtr");
                    writer.WriteStartElement("Pty");
                    writer.WriteStartElement("Nm");
                    writer.WriteString(model.DebCBSName);
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DrAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("CtctDtls");
                    writer.WriteStartElement("PhneNb");
                    writer.WriteString(model.DebCBSPhone);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DebAccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    //writer.WriteStartElement("Nm");
                    //writer.WriteString(model.DebCBSName);
                    //writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DrAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CdtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.CrAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Cdtr");
                    if (!string.IsNullOrEmpty(model.CrAccPhone))
                    {
                        writer.WriteStartElement("Pty");

                        writer.WriteStartElement("Nm");
                        writer.WriteString(model.CrAccName);
                        writer.WriteFullEndElement();
                        //writer.WriteStartElement("Id");
                        //writer.WriteStartElement("OrgId");
                        //writer.WriteStartElement("Othr");
                        //writer.WriteStartElement("Id");
                        //writer.WriteString(model.CrAccAgt);
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        writer.WriteStartElement("CtctDtls");
                        writer.WriteStartElement("PhneNb");
                        writer.WriteString(model.CrAccPhone);
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                        writer.WriteFullEndElement();
                    }
                    
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CdtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.CrAccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    //writer.WriteStartElement("UltmtCdtr");
                    //writer.WriteStartElement("Pty");
                    //writer.WriteStartElement("Nm");
                    //writer.WriteString(result.Data6);
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();
                    //writer.WriteFullEndElement();

                    writer.WriteStartElement("Purp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Purpose);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();


                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    xmlString = xmlString.Replace("<Cdtr></Cdtr>", "<Cdtr/>");
                    var response = await DoPost(xmlString);
                    return "";
                }
            }
        }

        public async Task<string> PayForAcc(PaymentInst model, GenericModel resu)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "async/v1/credit-transfer";

            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {


                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("Document");
                    writer.WriteAttributeString("xmlns", null, null, "urn:iso:std:iso:20022:tech:xsd:pacs.008.001.09");

                    writer.WriteStartElement("FIToFICstmrCdtTrf");

                    writer.WriteStartElement("GrpHdr");

                    writer.WriteStartElement("MsgId");
                    writer.WriteString(model.MsgId);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CreDtTm");
                    writer.WriteString(model.AccDate);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("NbOfTxs");
                    writer.WriteString("1");
                    writer.WriteFullEndElement();

                   

                    writer.WriteStartElement("SttlmInf");
                    writer.WriteStartElement("SttlmMtd");
                    writer.WriteString("CLRG");
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("ClrSys");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString("IPS");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PmtTpInf");

                    writer.WriteStartElement("SvcLvl");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.TxnType);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("LclInstrm");
                    writer.WriteStartElement("Cd");
                    writer.WriteString("INST");
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CtgyPurp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Channel);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstgAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(resu.Data4);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InstdAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(resu.Data5);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CdtTrfTxInf");
                    writer.WriteStartElement("PmtId");
                    writer.WriteStartElement("EndToEndId");
                    writer.WriteString(model.OrgEndToEnd);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("IntrBkSttlmAmt");
                    writer.WriteAttributeString("Ccy", model.Currency);
                    writer.WriteString(model.Amount.ToString());
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("AccptncDtTm");
                    writer.WriteString(model.AccDate);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("ChrgBr");
                    writer.WriteString("SLEV");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("InitgPty");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("OrgId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.InstgAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("Dbtr");
                    writer.WriteStartElement("Nm");
                    writer.WriteString(model.DebCBSName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CtctDtls");
                    writer.WriteStartElement("PhneNb");
                    writer.WriteString(model.DebCBSPhone);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAcct");
                    writer.WriteStartElement("Id");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.DebAccNo);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteStartElement("Nm");
                    writer.WriteString(model.DebCBSName);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("DbtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(resu.Data4);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CdtrAgt");
                    writer.WriteStartElement("FinInstnId");
                    writer.WriteStartElement("Othr");
                    writer.WriteStartElement("Id");
                    writer.WriteString(model.CrAccAgt);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                                            
                    writer.WriteStartElement("Cdtr");
                    writer.WriteFullEndElement();
                        


                    if (!string.IsNullOrEmpty(model.CrAccNo))
                    {
                         writer.WriteStartElement("CdtrAcct");
                         writer.WriteStartElement("Id");
                         writer.WriteStartElement("Othr");
                         writer.WriteStartElement("Id");
                         writer.WriteString(model.CrAccNo);
                         writer.WriteFullEndElement();
                         writer.WriteFullEndElement();
                         writer.WriteFullEndElement();
                         writer.WriteFullEndElement();
                    }


                        //writer.WriteStartElement("UltmtCdtr");
                        //writer.WriteStartElement("Nm");
                        //writer.WriteString(txns["CrAccountName"].ToString());
                        // writer.WriteFullEndElement();
                        //writer.WriteStartElement("CtctDtls");
                        //writer.WriteStartElement("PhneNb");
                        //writer.WriteString(txns.CrPhone);
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();
                        //writer.WriteFullEndElement();

                    writer.WriteStartElement("Purp");
                    writer.WriteStartElement("Prtry");
                    writer.WriteString(model.Purpose);
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("RmtInf");

                    writer.WriteStartElement("Ustrd");
                    writer.WriteString(model.Narration);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                   
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    xmlString = xmlString.Replace("<Cdtr></Cdtr>", "<Cdtr/>");
                    var response = await DoPost(xmlString);
                    return "";
                }
            }
        }

        public async Task<RegisterResponse> RegisterCustomer(Register model, GenericModel result)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "kba/webservices/v2/LookupDbWS?wsdl";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {

                    //---- Create header
                    writer.WriteStartElement("soapenv:Envelope");
                    writer.WriteAttributeString("xmlns", "soapenv", null, "http://schemas.xmlsoap.org/soap/envelope/");
                    writer.WriteAttributeString("xmlns", "ws", null, "http://ws.lookupdb.mgw.cwt.ru/");


                    writer.WriteStartElement("soapenv:Header");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("soapenv:Body");

                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("ws:registerCustomer");

                    writer.WriteStartElement("req");

                    writer.WriteStartElement("account");
                    writer.WriteString(model.AccNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("defaultRecord");
                    writer.WriteString(model.Default.ToString());
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("document");
                    writer.WriteString(model.Document);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("documentNumber");
                    writer.WriteString(model.DocumentNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("email");
                    writer.WriteString(model.Email);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("exp");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("lang");
                    writer.WriteString(result.Data4);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("login");
                    writer.WriteString(result.Data2);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("msisdn");
                    writer.WriteString(model.PhoneNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("name");
                    writer.WriteString(model.CustomerName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("pan");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("password");
                    writer.WriteString(result.Data3);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("sortCode");
                    writer.WriteString(result.Data5);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPostAsync(xmlString);
                    return PesalinkRegister(response);
                }
            }
        }

        public async Task<List<UserBanksData>> CustomerLookUp(Register model, GenericModel result)
        {
            _url = _url + (_url.EndsWith("/") ? "" : "/") + "kba/webservices/v2/LookupDbWS?wsdl";
            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {

                    //---- Create header
                    writer.WriteStartElement("soapenv:Envelope");
                    writer.WriteAttributeString("xmlns", "soapenv", null, "http://schemas.xmlsoap.org/soap/envelope/");
                    writer.WriteAttributeString("xmlns", "ws", null, "http://ws.lookupdb.mgw.cwt.ru/");


                    writer.WriteStartElement("soapenv:Header");
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("soapenv:Body");

                    //--- 1 Start > checkAccount
                    writer.WriteStartElement("ws:getCustomerBankList");

                    writer.WriteStartElement("req");


                    writer.WriteStartElement("login");
                    writer.WriteString(result.Data6);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("msisdn");
                    writer.WriteString(model.PhoneNo);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("password");
                    writer.WriteString(result.Data7);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();

                    string xmlString = FormatXml(str.ToString());
                    var response = await DoPostAsync(xmlString);
                    return PesalinkBanks(response);
                }
            }
        }






        #endregion


        #region Private Methods

        private List<UserBanksData> PesalinkBanks(string response)
        {
            List<UserBanksData> model = new List<UserBanksData>();
            XDocument Xml = XDocument.Parse(response);

            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "bankList").FirstOrDefault();

            if (myData != null)
            {
                model = (from data in myData.Descendants("bank")
                             select new UserBanksData
                             {
                                 CustName = data.Element("lookupBankName").Value,
                                 Def = data.Element("def").Value,
                                 BankName = data.Element("bankName").Value,
                                 SortCode = data.Element("sortCode").Value.Substring(3,4)
                             }).ToList();
            }
            else
            {

                model = new List<UserBanksData>();
            }
            return model;
        }

        private RegisterResponse PesalinkRegister(string response)
        {
            RegisterResponse model = new RegisterResponse();
            XDocument Xml = XDocument.Parse(response);

            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "registerCustomerResponse").FirstOrDefault();

            if (myData != null)
            {
                
                model.RegisterDetails=(string)myData.Descendants().Where(x => x.Name.LocalName == "return").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "rrn").FirstOrDefault();
            }
            else
            {

                model = new RegisterResponse
                {
                    Status = 1,
                    Message = "No Data Returned"
                };
            }
            return model;
        }

        private AuthResponse ProcessAuthReponse(string response)
        {
            AuthResponse model = new AuthResponse();
            XDocument Xml = XDocument.Parse(response);
            
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "IdVrfctnRpt").FirstOrDefault();

            if (myData != null)
            {
                bool success = (bool)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault();
                Logfile.DBLError(success.ToString());
                if (success == true)
                {
                    model = new AuthResponse
                    {
                        MsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "OrgnlAssgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                        SenderMsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                        SenderId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgnr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        ReceiverId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgne").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        VerifyId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        AccName = HttpUtility.HtmlDecode((string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "UpdtdPtyAndAcctId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Pty").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault()),
                        AccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "UpdtdPtyAndAcctId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Acct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        Success = (bool)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault()
                    };
                }
                else
                {
                    model = new AuthResponse
                    {
                        MsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "OrgnlAssgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                        SenderMsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                        SenderId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgnr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        ReceiverId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgne").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        VerifyId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                        Success = (bool)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault()
                    };
                }
                

            }
            else
            {
               
                model = new AuthResponse
                {
                    Success = false,
                    AccName="No Data Returned"
                };
            }
            return model;
        }


        private PaymentRespose ProcessPayOut(string response)
        {
            PaymentRespose model = new PaymentRespose();
            XDocument Xml = XDocument.Parse(response);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "FIToFIPmtStsRpt").FirstOrDefault();
            if (myData != null)
            {
                string status = (string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "TxSts").FirstOrDefault();

                switch (status)
                {
                    case "RJCT":
                        return model = new PaymentRespose
                        {
                            Status = 1,
                            Message = (string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault() + "|" + (string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault()
                        };
                    case "ACCP":
                        return model = new PaymentRespose
                        {
                            Status = 0,
                            Message = "",//(string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault() + "|" + (string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault()
                            Data = new AuthResponse
                            {
                                MsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "OrgnlAssgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                                SenderMsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                                SenderId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgnr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                                ReceiverId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgne").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                                VerifyId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                                AccName = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "UpdtdPtyAndAcctId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Pty").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault(),
                                AccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "UpdtdPtyAndAcctId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Acct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                                Success = (bool)myData.Descendants().Where(x => x.Name.LocalName == "Rpt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault()
                            }
                        };
                    default:
                        return model = new PaymentRespose
                        {
                            Status = 1,
                            Message = "Response not Valid"//(string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault() + "|" + (string)myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault()
                        };
                }

            }
            return model;
        }


        private string FormatXml(string xml)
        {
            try
            {
                
                var stringBuilder = new StringBuilder();

                var element = XDocument.Parse(xml);
              
                XmlWriterSettings writerSettings = new XmlWriterSettings();
                writerSettings.OmitXmlDeclaration = true;
                writerSettings.Indent = true;
                writerSettings.NewLineHandling = NewLineHandling.None;

                using (var xmlWriter = XmlWriter.Create(stringBuilder, writerSettings))
                    element.Save(xmlWriter);

                string result = stringBuilder.ToString();
                result = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + result;
                return result;

            }
            catch (Exception ex)
            {

                return xml;
            }
        }

        private async Task<string> DoPostAsync(string postData)
        {
            //Logfile.DBLError("Request: " + postData);
            try
            {
                //Test Certs
                X509Certificate2 cert_chain1 = new X509Certificate2("E:\\PesalinkCerts\\IPSL.pfx", "123456", X509KeyStorageFlags.MachineKeySet);

                var httpRequest = (HttpWebRequest)WebRequest.Create(_url);
                httpRequest.Method = "POST";
                httpRequest.ContentType = "text/xml";
                httpRequest.KeepAlive = true;
                httpRequest.ProtocolVersion = HttpVersion.Version10;
                byte[] bytes = Encoding.UTF8.GetBytes(postData);
                httpRequest.ContentLength = bytes.Length;
                httpRequest.ServicePoint.Expect100Continue = false;
                httpRequest.ClientCertificates.Add(cert_chain1);
                httpRequest.ServerCertificateValidationCallback = (sender, cert, chain, errors) =>
                {
                    return true;
                };
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls13 | SecurityProtocolType.Tls12;
                //Logfile.DBLError("Url " + _url + " Request " + postData);
               
                using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
                {
                    await reqStream.WriteAsync(bytes, 0, bytes.Length);
                }

                //---- Get response
                string xmlResponse = null;
                HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();

                using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                {
                    xmlResponse = sr.ReadToEnd();

                    //========== Log response ==========
                    //Logfile.DBLError("Status Code " + resp.StatusCode.ToString());
                    // LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsync:Response", xmlResponse);
                    //==================================

                    return xmlResponse;
                }
            }
            catch (WebException wex)
            {

                using (var stream = wex.Response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        string respContent = await reader.ReadToEndAsync();
                        if (!string.IsNullOrEmpty(respContent))
                        {
                            //========== Log response ==========
                            Logfile.DBLError("Status Code " + wex.Status.ToString() + "|" + respContent);
                            return respContent;
                            //==================================
                        }
                    }
                }

                throw wex;
            }
            catch (Exception ex)
            {
                Logfile.DBLError(ex.ToString());
                //LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsynct:ErrorRespose", ex);
                throw ex;
            }
        }

        private async Task<string> DoPost(string postData)
        {
            //Logfile.DBLError("Request: " + postData);
            try
            {
                //Live Certs
                //X509Certificate2 cert_chain1 = new X509Certificate2("E:\\PesalinkCerts\\ca_chain.crt.pem");
                //X509Certificate2 cert_chain = new X509Certificate2("E:\\PesalinkCerts\\bank0053_transport.pfx", "123456",X509KeyStorageFlags.MachineKeySet);
                //string certstring = "E:\\PesalinkCerts\\bank0053_seal.pfx";

                //Test Certs
                X509Certificate2 cert_chain1 = new X509Certificate2("E:\\PesalinkCerts\\ca_chain.crt.pem");
                X509Certificate2 cert_chain = new X509Certificate2("E:\\PesalinkCerts\\Transport.pfx", "123456", X509KeyStorageFlags.MachineKeySet);
                string certstring = "E:\\PesalinkCerts\\Seal.pfx";

                var httpRequest = (HttpWebRequest)WebRequest.Create(_url);
                httpRequest.Method = "POST";
                httpRequest.ContentType = "text/xml";
                httpRequest.KeepAlive = false;
                httpRequest.ProtocolVersion = HttpVersion.Version10;
                httpRequest.ClientCertificates.Add(cert_chain1);
                httpRequest.ClientCertificates.Add(cert_chain);
               // httpRequest.ClientCertificates.Add(cert_chain3);
                httpRequest.ServicePoint.Expect100Continue = true;
                ServicePointManager.CheckCertificateRevocationList = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                XmlDocument doc = new XmlDocument();
                byte[] bytes = Encoding.UTF8.GetBytes(postData);
                doc.LoadXml(postData);
                var xml=await SignDocument(doc, certstring,"123456");
                string request=xml.InnerXml.Replace("<OrgnlTxRef></OrgnlTxRef><OrgnlTxRef>", "<OrgnlTxRef></OrgnlTxRef>");
                byte[] reqBytes = new UTF8Encoding().GetBytes(request);
                httpRequest.ContentLength = reqBytes.Length;
                //Logfile.DBLError("Url "+_url+" Request "+request);
                httpRequest.ServerCertificateValidationCallback = (sender, cert, chain, errors) =>
                {
                    return true;
                };
                using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
                {
                    await reqStream.WriteAsync(reqBytes, 0, reqBytes.Length);
                }

                //---- Get response
                string xmlResponse = null;
                HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();
               
                using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                {
                    xmlResponse = sr.ReadToEnd();

                    //========== Log response ==========
                    Logfile.DBLError("Status Code "+resp.StatusCode.ToString());
                    // LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsync:Response", xmlResponse);
                    //==================================

                    return xmlResponse;
                }
            }
            catch (WebException wex)
            {
                
                using (var stream = wex.Response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        string respContent = await reader.ReadToEndAsync();
                        if (!string.IsNullOrEmpty(respContent))
                        {
                            //========== Log response ==========
                            Logfile.DBLError("Status Code " + wex.Status.ToString() + "|" + respContent);
                            return respContent;
                            //==================================
                        }
                    }
                }

                throw wex;
            }
            catch (Exception ex)
            {
                Logfile.DBLError( ex.ToString());
                //LogUtil.Error(LogFile, "BCABCBSGateway.DoPostAsynct:ErrorRespose", ex);
                throw ex;
            }
        }

        public async Task<XmlDocument> SignDocument(XmlDocument doc, string certificate,string password)
        {
            try
            {
                
                X509Certificate2 cert = new X509Certificate2(certificate, password,X509KeyStorageFlags.MachineKeySet);

                string keyId = "#_" + Guid.NewGuid();
                

                SignedXml signedXml = new SignedXml(doc) { SigningKey = cert.PrivateKey};
                signedXml.SignedInfo.SignatureMethod = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
                

                Reference reference = new Reference();
                reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
                reference.AddTransform(new XmlDsigC14NTransform());
                reference.Uri = "";
                reference.DigestMethod = "http://www.w3.org/2001/04/xmlenc#sha256";
                signedXml.AddReference(reference);

                KeyInfo keyInfo = new KeyInfo();
                keyInfo.AddClause(new KeyInfoX509Data(cert));
                keyInfo.Id = keyId;

                signedXml.KeyInfo = keyInfo;
                signedXml.ComputeSignature();
                doc.DocumentElement.AppendChild(signedXml.GetXml());
            }
            catch (Exception ex)
            {
                Logfile.DBLError(ex.ToString());
            }
            return doc;
        }

        //public class RSAPKCS1SHA256SignatureDescription : SignatureDescription
        //{
        //    /// <summary>
        //    /// Registers the http://www.w3.org/2001/04/xmldsig-more#rsa-sha256 algorithm
        //    /// with the .NET CrytoConfig registry. This needs to be called once per
        //    /// appdomain before attempting to validate SHA256 signatures.
        //    /// </summary>
        //    public static void Register()
        //    {
        //        CryptoConfig.AddAlgorithm(
        //            typeof(RSAPKCS1SHA256SignatureDescription),
        //            "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256");
        //    }
        //    //================New Services=====================================================
        //    /// <summary>
        //    /// .NET calls this parameterless ctor
        //    /// </summary>
        //    public RSAPKCS1SHA256SignatureDescription()
        //    {
        //        KeyAlgorithm = "System.Security.Cryptography.RSACryptoServiceProvider";
        //        DigestAlgorithm = "System.Security.Cryptography.SHA256Managed";
        //        FormatterAlgorithm = "System.Security.Cryptography.RSAPKCS1SignatureFormatter";
        //        DeformatterAlgorithm = "System.Security.Cryptography.RSAPKCS1SignatureDeformatter";
        //    }

        //    public override AsymmetricSignatureDeformatter CreateDeformatter(AsymmetricAlgorithm key)
        //    {
        //        var asymmetricSignatureDeformatter =
        //            (AsymmetricSignatureDeformatter)CryptoConfig.CreateFromName(DeformatterAlgorithm);
        //        asymmetricSignatureDeformatter.SetKey(key);
        //        asymmetricSignatureDeformatter.SetHashAlgorithm("SHA256");
        //        return asymmetricSignatureDeformatter;
        //    }

        //    public override AsymmetricSignatureFormatter CreateFormatter(AsymmetricAlgorithm key)
        //    {
        //        var asymmetricSignatureFormatter =
        //            (AsymmetricSignatureFormatter)CryptoConfig.CreateFromName(FormatterAlgorithm);
        //        asymmetricSignatureFormatter.SetKey(key);
        //        asymmetricSignatureFormatter.SetHashAlgorithm("SHA256");
        //        return asymmetricSignatureFormatter;
        //    }
        //}
        #endregion
    }
}
