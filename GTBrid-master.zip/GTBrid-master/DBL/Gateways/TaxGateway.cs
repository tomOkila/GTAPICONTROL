﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace DBL.Gateways
{
    public class TaxGateway
    {

        private string _url;
        private string _userName;
        private string _password;
        public TaxGateway(string url, string username, string password)
        {
            _url = url;
            _userName = username;
            _password = password;
        }


        public async Task<RequestResponseModel> QueryTaxDeclaration(string slipnumber)
        {
            RequestResponseModel resp = new RequestResponseModel();

            string errorCode = "";
            string errorMsg = "";
            string systemCode = "";
            string slipNo = "";
            string slipCode = "";
            string adviceDate = "";
            string PIN = "";
            string name = "";
            string TTAmount = "";
            string docRef = "";
            string currency = "";
            string taxCode = "";
            string taxHead = "";
            string component = "";
            string Amt = "";
            string taxPeriod = "";

            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);

                    //---- Write get getDeclarationDetails
                    writer.WriteStartElement("impl:checkEslip");

                    //--- Add
                    //< officeCode > BIPOR </ officeCode >
                    writer.WriteStartElement("loginId");
                    writer.WriteString(_userName);
                    writer.WriteFullEndElement();
                    //<registrationYear > 2018 </ registrationYear >
                    writer.WriteStartElement("password");
                    writer.WriteString(_password);
                    writer.WriteFullEndElement();
                    //<registrationSerial ></ registrationSerial >
                    writer.WriteStartElement("eSlipNumber");
                    writer.WriteString(slipnumber);
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());


                    if (!string.IsNullOrEmpty(xmlString))
                    {
                        var postResp = await DoPost(xmlString);

                        //var postResp = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body><ns2:checkEslipResponse xmlns:ns2=\"http://impl.facade.pg.kra.tcs.com/\"><paymentEslip>&lt;ESLIP>&lt;RESULT>&lt;Status>ERROR&lt;/Status>&lt;Remarks>INVALID USER&lt;/Remarks>&lt;/RESULT>&lt;/ESLIP></paymentEslip></ns2:checkEslipResponse></soap:Body></soap:Envelope>";
                        var xmlvalue = XElement.Parse(postResp).Value;
                        if (xmlvalue != "")
                        {
                            XDocument Xml = XDocument.Parse(xmlvalue);
                            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "ESLIP").FirstOrDefault();

                            if (myData != null)
                            {
                                myData = Xml.Descendants().Where(x => x.Name.LocalName == "RESULT").FirstOrDefault();
                                if (myData != null)
                                {
                                    errorCode = (string)myData.Element("Status");
                                    errorMsg = (string)myData.Element("Remarks");
                                }
                               
                                myData = Xml.Descendants().Where(x => x.Name.LocalName == "ESLIPHEADER").FirstOrDefault();
                                if(myData != null)
                                {
                                     systemCode = (string)myData.Element("SystemCode");
                                     slipNo = (string)myData.Element("EslipNumber");
                                     slipCode = (string)myData.Element("SlipPaymentCode");
                                     adviceDate = (string)myData.Element("PaymentAdviceDate");
                                     PIN = (string)myData.Element("TaxpayerPin");
                                     name = (string)myData.Element("TaxpayerFullName");
                                     TTAmount = (string)myData.Element("TotalAmount");
                                     docRef = (string)myData.Element("DocRefNumber");
                                     currency = (string)myData.Element("Currency");
                                }

                                myData = Xml.Descendants().Where(x => x.Name.LocalName == "ESLIPDETAILS").FirstOrDefault();
                                if (myData != null)
                                {
                                     taxCode = (string)myData.Element("TaxCode");
                                     taxHead = (string)myData.Element("TaxHead");
                                     component = (string)myData.Element("TaxComponent");
                                     Amt = (string)myData.Element("AmountPerTax");
                                     taxPeriod = (string)myData.Element("TaxPeriod");
                                }

                                
                                resp.Status = 0;
                                resp.Message = "";
                                resp.Content = new KRAQueryResponse
                                {
                                    Status = errorCode,
                                    Message = errorMsg,
                                    TaxCode = taxCode,
                                    SystemCode = systemCode,
                                    ESlipNumber = slipNo,
                                    SlipPaymentCode = slipCode,
                                    PaymentAdviceDate = adviceDate,
                                    PIN = PIN,
                                    PayerName = name,
                                    TotalAmount = TTAmount,
                                    DocRefNumber = docRef,
                                    Currency = currency,
                                    TaxHead = taxHead,
                                    Component = component,
                                    Amt = Amt,
                                    TaxPeriod = taxPeriod
                                };
                            }
                            else
                            {
                                resp.Status = 1;
                                resp.Message = "Request Failed!";
                            }
                        }
                        else
                        {
                            resp.Status = 1;
                            resp.Message = "Generating request data failed!";
                        }
                    }
                }
            }
            return resp;
        }

        private async Task<RequestResponseModel> PayTaxDeclaration(DataTable dt)
        {
            RequestResponseModel resp = new RequestResponseModel();

            using (StringWriter str = new StringWriter())
            {
                using (XmlTextWriter writer = new XmlTextWriter(str))
                {
                    //---- Initiate writer
                    CreateRequestHeader(writer);


                    writer.WriteStartElement("impl:acceptPayment");

                    writer.WriteStartElement("loginId");
                    writer.WriteString(_userName);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("password");
                    writer.WriteString(_password);
                    writer.WriteFullEndElement();

                    writer.WriteStartElement("CCRESPAYMENT");

                    writer.WriteStartElement("PAYMENT");

                    writer.WriteStartElement("PAYMENTHEADER");


                    foreach (DataRow txns in dt.Rows)
                    {
                        writer.WriteStartElement("SystemCode");
                        writer.WriteString(txns["SystemCode"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("BranchCode");
                        writer.WriteString(txns["BranchCode"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("BankTellerId");
                        writer.WriteString(txns["TellerId"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("BankTellerName");
                        writer.WriteString(txns["TellerName"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("PaymentMode");
                        writer.WriteString(txns["PayMode"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("MeansOfPayment");
                        writer.WriteString(txns["MOP"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("RemitterId");
                        writer.WriteString(txns["Phone"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("RemitterName");
                        writer.WriteString(txns["CusName"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("EslipNumber");
                        writer.WriteString(txns["SlipNo"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("SlipPaymentCode");
                        writer.WriteString(txns["SlipCode"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("PaymentAdviceDate");
                        writer.WriteString(txns["AdvDate"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("PaymentReference");
                        writer.WriteString(txns["PayRef"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("TaxpayerPin");
                        writer.WriteString(txns["PIN"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("TaxpayerFullName");
                        writer.WriteString(txns["PayerName"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("TotalAmount");
                        writer.WriteString(txns["TTAmt"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("DocRefNumber");
                        writer.WriteString(txns["DocRef"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("DateOfCollection");
                        writer.WriteString(txns["DOC"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("Currency");
                        writer.WriteString(txns["Curr"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("CashAmount");
                        writer.WriteString(txns["Amt"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChequesAmount");
                        writer.WriteString(txns["CheqAmt"].ToString());
                        writer.WriteFullEndElement();
                    }

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("PAYMENTCHEQUE");


                    foreach (DataRow txns in dt.Rows)
                    {
                        writer.WriteStartElement("BankOfCheques");
                        writer.WriteString(txns["Bank"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("BranchOfCheque");
                        writer.WriteString(txns["Branch"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChequeNumber");
                        writer.WriteString(txns["CheqNo"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChequeDate");
                        writer.WriteString(txns["CheqDate"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChequeAmount");
                        writer.WriteString(txns["CheqAmt"].ToString());
                        writer.WriteFullEndElement();

                        writer.WriteStartElement("ChequeAccount");
                        writer.WriteString(txns["CheqAcc"].ToString());
                        writer.WriteFullEndElement();

                    }

                    writer.WriteFullEndElement();

                    writer.WriteStartElement("hashCode");
                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();

                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteFullEndElement();
                    writer.WriteEndDocument();

                    //----Result is a formated string.
                    string xmlString = FormatXml(str.ToString());


                    if (!string.IsNullOrEmpty(xmlString))
                    {
                        var postResp = await DoPost(xmlString);

                        XDocument Xml = XDocument.Parse(postResp);
                        var myData = Xml.Descendants().Where(x => x.Name.LocalName == "RESPONSE").FirstOrDefault();
                        if (myData != null)
                        {
                            string errorCode = (string)myData.Descendants().Where(x => x.Name.LocalName == "PAYMENTS").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Status").FirstOrDefault();
                            string errorMsg = (string)myData.Descendants().Where(x => x.Name.LocalName == "PAYMENTS").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Message").FirstOrDefault();
                            string systemCode = (string)myData.Descendants().Where(x => x.Name.LocalName == "PAYMENTS").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PaymentNumber").FirstOrDefault() ?? "";
                            string slipNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "PAYMENTS").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "ResponseCode").FirstOrDefault() ?? "";

                            resp.Status = 0;
                            resp.Message = "";
                            resp.Content = new KRAQueryResponse
                            {
                                Status = errorCode,
                                Message = errorMsg,
                                SystemCode = systemCode,
                                ESlipNumber = slipNo
                            };
                        }
                    }
                    else
                    {
                        resp.Status = 1;
                        resp.Message = "Generating payment data failed!";
                    }
                }
            }
            return resp;
        }

        #region Private Methods

        private void CreateRequestHeader(XmlTextWriter writer)
        {
            //---- Write root
            writer.WriteStartDocument();
            writer.WriteStartElement("soapenv:Envelope");
            writer.WriteAttributeString("xmlns", "soapenv", null, "http://schemas.xmlsoap.org/soap/envelope/");
            writer.WriteAttributeString("xmlns", "impl", null, "http://impl.facade.pg.kra.tcs.com/");
            //---- Write header
            writer.WriteStartElement("soapenv:Header");
            writer.WriteFullEndElement();
            //---- Write body
            writer.WriteStartElement("soapenv:Body");
        }

        private string FormatXml(string xml)
        {
            try
            {
                var stringBuilder = new StringBuilder();

                var element = XDocument.Parse(xml);

                XmlWriterSettings writerSettings = new XmlWriterSettings();
                writerSettings.OmitXmlDeclaration = true;
                writerSettings.Indent = true;
                writerSettings.NewLineHandling = NewLineHandling.None;

                using (var xmlWriter = XmlWriter.Create(stringBuilder, writerSettings))
                    element.Save(xmlWriter);

                return stringBuilder.ToString();
            }
            catch (Exception ex)
            {
                //AppUtil.Log.Error(LogFile, "Format xml", new Exception(ex.Message + "||" + xml));
                return xml;
            }
        }

        private async Task<string> DoPost(string postData)
        {

            var httpRequest = (HttpWebRequest)WebRequest.Create(_url);
            httpRequest.Method = "POST";
            httpRequest.ContentType = "text/xml";
            //httpRequest.Headers.Add("SOAPAction", _url);
            httpRequest.KeepAlive = false;
            httpRequest.ProtocolVersion = HttpVersion.Version10;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            //NetworkCredential credential = new NetworkCredential();
            //credential.UserName = _userName;
            //credential.Password = _password;
            //httpRequest.Credentials = credential;

            byte[] reqBytes = new UTF8Encoding().GetBytes(postData);
            httpRequest.ContentLength = reqBytes.Length;

            using (Stream reqStream = await httpRequest.GetRequestStreamAsync())
            {
                await reqStream.WriteAsync(reqBytes, 0, reqBytes.Length);
            }

            //---- Get response
            string xmlResponse = null;
            HttpWebResponse resp = (HttpWebResponse)await httpRequest.GetResponseAsync();
            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
            {
                xmlResponse = await sr.ReadToEndAsync();

                //========== Log response ==========
                AppUtil.Log.Error("", "TaxGateway.DoPost:Respose", xmlResponse);
                //==================================

                return xmlResponse;
            }
        }

        #endregion
    }
}
