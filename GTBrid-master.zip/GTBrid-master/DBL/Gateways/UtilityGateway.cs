﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Gateways
{
    public class UtilityGateway
    {
        public string LogFile { get; set; }
        private string _baseUrl, _userName, _password;
        public UtilityGateway(string baseUrl, string userName, string password)
        {
            _baseUrl = baseUrl;
            _userName = userName;
            _password = password;
        }

        public async Task<ValidationResultModel> Validation(string jsonData)
        {

            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + "ServiceLayer/presentment/ePay";
            var headers = new Dictionary<string, string>();
            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Post, headers))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new UtilityLookUP();

                    Logfile.UtilityError("Validation :" + JsonConvert.SerializeObject(result.Data));

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<UtilityLookUP>(result.Data);




                    if (respData.Status != "00")
                    {
                        return new ValidationResultModel
                        {
                            RespStat = 1,
                            RespMsg = respData.Message.RespMsg
                        };
                    }
                    else
                    {
                        return new ValidationResultModel
                        {
                            RespStat = 0,
                            RespMsg = respData.Message.RespMsg,
                            CusName = respData.Message.CusName,
                            Amount = respData.Message.Amount,
                            TransactionID=respData.Message.TransID
                        };
                    }
                    
                }
                else
                {
                    //--- Error response
                    Logfile.UtilityError("Validation :" + result.Exception.ToString());
                    return new ValidationResultModel
                    {
                        RespStat = 1,
                        RespMsg = "Request failed due to an error!"
                    };
                }
            }
        }

        public async Task<ValidationResultModel> Purchase(string jsonData)
        {
            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + "ServiceLayer/request/postRequest";
            var headers = new Dictionary<string, string>();

            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Post, headers))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new UtilityResponseModel();

                    Logfile.UtilityError("Purchase :" + JsonConvert.SerializeObject(result.Data));

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<UtilityResponseModel>(result.Data);



                    if (respData.Status != "00")
                    {
                        return new ValidationResultModel
                        {
                            RespStat = 1,
                            RespMsg = respData.RespMsg,
                            ResponseCode=respData.Status
                        };
                    }

                    

                    return new ValidationResultModel
                    {
                        RespStat = 0,
                        RespMsg = respData.RespMsg,
                        ResponseCode = respData.Status,
                        ReferenceNo = respData.CloudPacketID
                    };
                }
                else
                {
                    //--- Error response
                    Logfile.UtilityError("Purchase :" + result.Exception.ToString());
                    return new ValidationResultModel
                    {
                        RespStat = 1,
                        RespMsg = "Request failed due to an error!"
                    };
                }

            }
        }


        public async Task<TokenResponse> GetToken(string jsonData,string username,string password)
        {
            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + "oauth/v1/generate?grant_type=client_credentials";
            var headers = new Dictionary<string, string>();
            headers.Add("Authorization", "Basic " + Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password)));
            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Get, headers))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new TokenResponse();

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<TokenResponse>(result.Data);

                    return respData;
                }
                else
                {
                    //--- Error response
                    Logfile.MpesaC2B("Mpesa :" + result.Exception.ToString());
                    return new TokenResponse();
                }

            }
        }

        public async Task<STKResponse> PostSTK(string jsonData, Dictionary<string, string> headers)
        {
            _baseUrl = _baseUrl + (_baseUrl.EndsWith("/") ? "" : "/") + "mpesa/stkpush/v1/processrequest";
          

            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Post, headers))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new STKResponse();

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<STKResponse>(result.Data);

                    return respData;
                }
                else
                {
                    //--- Error response
                    return new STKResponse
                    {
                        Response = "1"
                    };
                    
                }

            }
        }

        public async Task<STKResponse> Callback(string jsonData)
        {
            using (var restApi = new RestApiClient(_baseUrl, RestApiClient.RequestType.Post))
            {
                //--- Make request
                var result = await restApi.SendRequestAsync(jsonData);

                //---- Process result
                if (result.Success)
                {
                    var respData = new STKResponse();

                    //--- Get data
                    respData = JsonConvert.DeserializeObject<STKResponse>(result.Data);

                    return respData;
                }
                else
                {
                    //--- Error response
                    return new STKResponse
                    {
                        Response = "1"
                    };

                }

            }
        }
    }

    public class ValidationResultModel
    {
        public int RespStat { get; set; }
        public string RespMsg { get; set; }
        public string ResponseCode { get; set; }
        public string ReferenceNo { get; set; }
        public string CusName { get; set; }
        public decimal Amount { get; set; }
        public string DueDate { get; set; }
        public string TransactionID { get; set; }
    }


    public class UtilityResponseModel
    {
        [JsonProperty("status")]
        public string Status { get; set; }
        [JsonProperty("statusDescription")]
        public string RespMsg { get; set; }
        [JsonProperty("transactionID")]
        public string TransactionID { get; set; }
        [JsonProperty("cloudPacketID")]
        public string CloudPacketID { get; set; }
    }

    public class TokenResponse
    {
        [JsonProperty("access_token")]
        public string Token { get; set; }
        [JsonProperty("expires_in")]
        public string Expiry { get; set; }
    }

    public class STKResponse
    {
        [JsonProperty("MerchantRequestID")]
        public string Merchant { get; set; }
        [JsonProperty("CheckoutRequestID")]
        public string Checkout { get; set; }
        [JsonProperty("ResponseCode")]
        public string Response { get; set; }
        [JsonProperty("ResponseDescription")]
        public string Description { get; set; }
        [JsonProperty("CustomerMessage")]
        public string Message { get; set; }
    }

    public class UtilityLookUP
    {
        [JsonProperty("STATUS")]
        public string Status { get; set; }
        [JsonProperty("MESSAGE")]
        public UtilityLookUPData Message { get; set; }
    }

    public class UtilityLookUPData
    {
        [JsonProperty("Message")]
        public string RespMsg { get; set; }
        [JsonProperty("Name")]
        public string CusName { get; set; }
        [JsonProperty("AmountDue")]
        public decimal Amount { get; set; }
        [JsonProperty("Amount")]
        private decimal AmountDue { set { Amount = value; } }
        [JsonProperty("Names")]
        private string Names { set { CusName = value; } }
        [JsonProperty("TransactionID")]
        public string TransID { get; set; }
        [JsonProperty("StudentCourseInfo")]
        public StudentDetails Student { get; set; }
    }

    public class StudentDetails
    {
        [JsonProperty("RegistrationNumber")]
        public string RegNo { get; set; }
        [JsonProperty("Course")]
        public string Cour { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
    }
}
