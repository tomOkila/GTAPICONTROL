﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBL
{
    public static class ExtensionMethods
    {
        public static string JsonToQuery(this string jsonQuery)
        {
            string str = "?";
            str += jsonQuery.Replace(":", "=").Replace("{", "").
                        Replace("}", "").Replace(",", "&").
                            Replace("\"", "");
            return str;
        }
    }
}
