﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace DBL
{
    public class Logfile
    {
        public static void GTPAYErrors(string content)
        {
            string folder = @"E:\GTPAY\STK" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }

        public static void Errors(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }

        public static void MpesaErrors(string content)
        {
            string folder = @"D:\MpesaCallbacks\" + DateTime.Now.ToString("dd-MM-yyyy");
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }

        public static void DBLError(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "DBLError.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void UtilityError(string content)
        {
            string folder = @"C:\Utilities\Utility" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Utility.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }

        public static void MpesaC2B(string content)
        {
            string folder = @"C:\Utilities\MpesaC2B" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "MpesaC2B.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }
    }
}
