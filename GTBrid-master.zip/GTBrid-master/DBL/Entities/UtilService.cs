using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  DBL.Entities
{
    [Table("UtilServices")]
    public class UtilService
    {
        [NotMapped]
        public static string TableName { get { return "UtilServices"; } }

        [Column("Id")]
        public int Id { get; set; }

        [Column("ServiceCode")]
        [Required()]
        [Display(Name = "Service Code")]
        public int ServiceCode { get; set; }

        [Column("ServiceId")]
        [Required()]
        [StringLength(25)]
        public string ServiceId { get; set; }

        [Column("serviceName")]
        [Required()]
        [StringLength(35)]
        [Display(Name = "Service Name")]
        public string ServiceName { get; set; }

        [Column("ServiceStat")]
        [Required()]
        public int ServiceStat { get; set; }

        [Column("BaseUrl")]
        [Required()]
        [StringLength(250)]
        [Display(Name = "Service Url")]
        public string BaseUrl { get; set; }

        [Column("Username")]
        [StringLength(250)]
        [Display(Name = "Service Username")]
        public string Username { get; set; }

        [Column("Pwd")]
        [StringLength(500)]
        [Display(Name = "Service Password")]
        public string Pwd { get; set; }

        [Column("MinAmount")]
        [Required()]
        [Display(Name = "Minimum Tran Amount")]
        public decimal MinAmount { get; set; }

        [Column("MaxAmount")]
        [Required()]
        [Display(Name = "Maximum Tran Amount")]
        public decimal MaxAmount { get; set; }

        [Column("Logo")]
        public byte[] Logo { get; set; }

        [Column("OfflineMsg")]
        [StringLength(250)]
        public string OfflineMsg { get; set; }

        [Column("Extra1")]
        [StringLength(200)]
        [Display(Name = "Service Trust Account")]
        public string Extra1 { get; set; }

        [Column("Extra2")]
        [StringLength(200)]
        public string Extra2 { get; set; }

        [Column("Extra3")]
        [StringLength(200)]
        public string Extra3 { get; set; }

        [Column("Extra4")]
        [StringLength(200)]
        public string Extra4 { get; set; }

        public string ServiceStatName { get; set; }
    }
}
