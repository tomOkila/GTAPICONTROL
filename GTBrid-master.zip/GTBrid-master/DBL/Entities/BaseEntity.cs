﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace  DBL.Entities
{
    public class BaseEntity
    {
        [NotMapped]
        public static string IDColumn { get { return "Id"; } }

        [NotMapped]
        public int RespStat { get; set; }

        [NotMapped]
        public string RespMsg { get; set; }
    }
}
