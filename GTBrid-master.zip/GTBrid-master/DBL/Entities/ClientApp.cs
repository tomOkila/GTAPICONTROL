using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  DBL.Entities
{
    [Table("ClientApps")]
    public class ClientApp
    {
        [NotMapped]
        public static string TableName { get { return "ClientApps"; } }
        [Column("Id")]
        public int Id { get; set; }

        [Column("AppCode")]
        [Required()]
        public int AppCode { get; set; }

        [Column("ClientCode")]
        [Required()]
        public int ClientCode { get; set; }

        [Column("AppName")]
        [Required()]
        [StringLength(35)]
        [Display(Name = "App Name")]
        public string AppName { get; set; }

        [Column("AppStat")]
        [Required()]
        public int AppStat { get; set; }

        [Column("AppId")]
        [StringLength(50)]
        public string AppId { get; set; }

        [Column("AppKey")]
        [StringLength(200)]
        public string AppKey { get; set; }

        [Column("Salt")]
        public string Salt { get; set; }

        [Column("CreateDate")]
        public DateTime CreateDate { get; set; }

        public string AppStatName { get; set; }
    }
}
