using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace  DBL.Entities
{
    [Table("Clients")]
    public class Client
    {
        [NotMapped]
        public static string TableName { get { return "Clients"; } }

        [Column("Id")]
        public int Id { get; set; }

        [Column("ClientCode")]
        public int ClientCode { get; set; }

        [Column("ClientName")]
        [Required()]
        [StringLength(35)]
        [Display(Name = "Client Name")]
        public string ClientName { get; set; }

        [Column("EMail")]
        [Required()]
        [StringLength(50)]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "E-Mail Address")]
        public string EMail { get; set; }

        [Column("Contacts")]
        [Required()]
        [StringLength(35)]
        public string Contacts { get; set; }

        [Column("PAddress")]
        [Required()]
        [StringLength(150)]
        [Display(Name = "Physical Address")]
        public string PAddress { get; set; }

        [Column("CreateDate")]
        public DateTime CreateDate { get; set; }

        [Column("CreatedBy")]
        public int CreatedBy { get; set; }

        [Column("ClientStat")]
        public int ClientStat { get; set; }

        [Column("AccountNo")]
        [Required()]
        [StringLength(20)]
        [Display(Name = "Account No")]
        public string AccountNo { get; set; }

        [Column("CallbackUrl")]
        [Required()]
        [StringLength(250)]
        [Display(Name = "Callback URL")]
        public string CallBack { get; set; }

        public string ClientStatName { get; set; }
    }
}
