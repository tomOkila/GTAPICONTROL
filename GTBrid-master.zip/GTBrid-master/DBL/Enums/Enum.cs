﻿using System;
using System.Collections.Generic;
using System.Text;

namespace  DBL.Enums
{
    public enum UserLoginStatus { Ok = 0, ChangePassword = 1, PassExpired = 2, UserLocked = 3, AttemptsExceeded = 4 }

    public enum ListItemType
    {
        Currency = 0,
        Branch = 1,
    }

    public enum ParamSetType
    {
        CBSAccountUrl = 0,
        PostingUrl = 1
    }
}
