﻿using DBL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.UOW
{
    public interface IUnitOfWork
    {
        IPesaLinkRepository PesaLinkRepository { get; }
        IUSSDRepository USSDRepository { get; }
        IUtilityRepository UtilityRepository { get; }
        ICBSRepository CBSRepository { get; }
        IMpesaRepository MpesaRepository { get; }
        ISecurityRepository SecurityRepository { get; }
        IClientRepository ClientRepository { get; }
        IServiceRepository ServiceRepository { get; }
        IGeneralRepository GeneralRepository { get; }
        ITAXRepository TAXRepository { get; }
        ICardRepository CardRepository { get; }
    }
}
