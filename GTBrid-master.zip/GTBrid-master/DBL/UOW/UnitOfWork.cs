﻿using DBL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.UOW
{
    public class UnitOfWork : IUnitOfWork
    {
        public string connString;
        private bool _disposed;

        private IPesaLinkRepository pesaLinkRepository;
        private IUSSDRepository ussdRepository;
        private IUtilityRepository utilityRepository;
        private ICBSRepository cbsRepository;
        private IMpesaRepository mpesaRepository;
        private ISecurityRepository securityRepository;
        private IClientRepository clientRepository;
        private IServiceRepository serviceRepository;
        private IGeneralRepository generalRepository;
        private ITAXRepository taxRepository;
        private ICardRepository cardRepository;
        public ISecurityRepository SecurityRepository
        {
            get { return securityRepository ?? (securityRepository = new SecurityRepository(connString)); }
        }

        public IClientRepository ClientRepository
        {
            get { return clientRepository ?? (clientRepository = new ClientRepository(connString)); }
        }

        public IServiceRepository ServiceRepository
        {
            get { return serviceRepository ?? (serviceRepository = new ServiceRepository(connString)); }
        }

        public IGeneralRepository GeneralRepository
        {
            get { return generalRepository ?? (generalRepository = new GeneralRepository(connString)); }
        }

        public IMpesaRepository MpesaRepository
        {
            get { return mpesaRepository ?? (mpesaRepository = new MpesaRepository(connString)); }
        }

        public IPesaLinkRepository PesaLinkRepository
        {
            get { return pesaLinkRepository ?? (pesaLinkRepository = new PesaLinkRepository(connString)); }
        }

        public IUSSDRepository USSDRepository
        {
            get { return ussdRepository ?? (ussdRepository = new USSDRepository(connString)); }
        }

        public IUtilityRepository UtilityRepository
        {
            get { return utilityRepository ?? (utilityRepository = new UtilityRepository(connString)); }
        }

        public ICBSRepository CBSRepository
        {
            get { return cbsRepository ?? (cbsRepository = new CBSRepository(connString)); }
        }

        public ITAXRepository TAXRepository
        {
            get { return taxRepository ?? (taxRepository = new TAXRepository(connString)); }
        }

        public ICardRepository CardRepository
        {
            get { return cardRepository ?? (cardRepository = new CardRepository(connString)); }
        }
        public UnitOfWork(string dbconnection)
        {
            connString = dbconnection;
        }

        public void Reset()
        {
            pesaLinkRepository = null;
            ussdRepository = null;
            cbsRepository = null;
            mpesaRepository = null;
            securityRepository = null;
            clientRepository = null;
            serviceRepository = null;
            generalRepository = null;
            taxRepository = null;
            cardRepository = null;
        }

        public void Dispose()
        {
            dispose(true);
            GC.SuppressFinalize(this);
        }

        private void dispose(bool disposing)
        {
            if (!_disposed)
            {
                _disposed = true;
            }
        }

        UnitOfWork()
        {
            dispose(false);
        }
    }
}
