﻿using Dapper;
using DBL.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class PesaLinkRepository:BaseRepository,IPesaLinkRepository
    {
        public PesaLinkRepository(string conn) : base(conn)
        {

        }

        public async Task<GenericModel> CheckDetails(AuthData model,int type)
        {
            GenericModel result = new GenericModel();
            GenericModel res = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", type);
                    parameters.Add("@refno", model.MsgId);
                    parameters.Add("@sender", model.SenderId);
                    parameters.Add("@receiver", model.ReceiverId);
                    parameters.Add("@acc_num", model.AccNo);
                    parameters.Add("@dest", model.DestinationId);

                    result = (await connection.QueryAsync<GenericModel>("sp_validateaccount", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch(Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }


            if (String.IsNullOrEmpty(result.Data5)==false)
            {
                try
                {
                    using (OracleConnection oracleConnection = new OracleConnection(result.Data4))
                    {
                        // create the command for the function
                        string query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('"+model.AccNo+"') from dual" });
                        if (oracleConnection.State == ConnectionState.Closed)
                        {
                            oracleConnection.Open();
                        }
                        using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                        {
                            oracleCommand.Connection = oracleConnection;
                            oracleCommand.CommandText = query_str;
                            oracleCommand.CommandType = CommandType.Text;
                            using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                oracleDataReader.Read();
                                if (oracleDataReader.HasRows)
                                {
                                    string data = oracleDataReader.GetString(0);
                                    string[] cus = data.Split("|");

                                    
                                    return res = new GenericModel
                                    {
                                        RespStat = 0,
                                        RespMsg = "",
                                        Data1 = result.Data1,
                                        Data5 = model.AccNo,
                                        Data4 = cus[1]
                                    };
                                   
                                }
                                else
                                {
                                    result = new GenericModel
                                    {
                                        RespStat = 1,
                                        RespMsg = "AC01",
                                        Data4 = result.Data6,
                                        Data5 = result.Data7
                                    };
                                    return result;
                                }
                            }
                        }
                    }
                    
                }
                catch (Exception ex)
                {
                    return res = new GenericModel
                    {
                        RespStat = -1,
                        RespMsg = ex.Message,
                        Data1 = result.Data1,
                    };
                }
            }
            return result;
        }

        public async Task<GenericModel> PayOut(PaymentRequest model,DataTable dt, string mainRef)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OrgRef", model.ReferenceNo);
                    parameters.Add("@MainRef", mainRef);
                    parameters.Add("@Channel", model.Channel);
                    parameters.Add("@TxnType", model.TxnType);
                    parameters.Add("@Txns",dt.AsTableValuedParameter("dbo.PaymentData"));

                    result = connection.Query<GenericModel>("sp_CreatePayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    
                }
            }
            catch(Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> PostIn(PaymentAccpetance model,DataTable dt, string mainRef)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@OrgRef", model.OrgEndToEnd);
                    parameters.Add("@MainRef", mainRef);
                    parameters.Add("@Channel", model.Channel);
                    parameters.Add("@TxnType", model.TxnType);
                    parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.PaymentData"));

                    result = connection.Query<GenericModel>("sp_CreateIncomingPay", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> GetOldAccount(PaymentAccpetance model,int type)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", type);
                    parameters.Add("@refno", model.MsgId);
                    parameters.Add("@sender", model.SenderId);
                    parameters.Add("@receiver", model.ReceiverId);
                    parameters.Add("@acc_num", model.CrAccNo);
                    parameters.Add("@dest", model.ReceiverId);

                    result = (await connection.QueryAsync<GenericModel>("sp_validateaccount", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            if(result.RespStat != 0)
            {
                return result;
            }
            string str = result.Data4;
            
            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(str))
                {
                    // create the command for the function
                   string query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('"+model.CrAccNo+"') from dual" });
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string data = oracleDataReader.GetString(0);
                                string[] cus = data.Split("|");
                                if (Convert.ToInt32(cus[5]) == 1)
                                {
                                    cus[4] = "RESTRICT";
                                }
                                result = new GenericModel
                                {
                                    RespStat = 0,
                                    RespMsg = "",
                                    Data4 = result.Data6,
                                    Data5 = result.Data7,
                                    Data6 = cus[1],
                                    Data7 = cus[2],
                                    Data9=cus[4]
                                };
                               
                                return result;
                            }
                            else
                            {
                                result = new GenericModel
                                {
                                    RespStat = 1,
                                    RespMsg = "AC01",
                                    Data4 = result.Data6,
                                    Data5 = result.Data7
                                };
                                return result;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new GenericModel
                {
                    RespStat = 1,
                    RespMsg = "AC01",
                    Data4 = result.Data6,
                    Data5 = result.Data7
                };
            }
            return result;
        }

        public async Task<GenericModel> ValidateCustomer(AuthData model,int type)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", type);
                    parameters.Add("@refno", model.MsgId);
                    parameters.Add("@sender", model.SenderId);
                    parameters.Add("@receiver", model.ReceiverId);
                    parameters.Add("@acc_num", model.AccNo);
                    parameters.Add("@dest", model.DestinationId);

                    result = (await connection.QueryAsync<GenericModel>("sp_validateaccount", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> PostToBasis(string Acct_from, string Acct_to, double Tra_amt, int Expl_code, string Remark, string Req_code,string connection)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (OracleConnection oraconn = new OracleConnection(connection))
                {
                    using (OracleCommand oracomm = new OracleCommand("GTBPBSC0_FULL", oraconn))
                    {
                        oracomm.CommandType = CommandType.StoredProcedure;
                        if (oraconn.State == ConnectionState.Closed)
                        {
                            oraconn.Open();
                        }
                        oracomm.Parameters.Add("INP_ACCT_FROM", OracleDbType.NVarchar2, 21).Value = Acct_from.Trim();
                        oracomm.Parameters.Add("INP_ACCT_TO", OracleDbType.NVarchar2, 21).Value = Acct_to.Trim();
                        oracomm.Parameters.Add("INP_TRA_AMT", OracleDbType.Double, 15).Value = Tra_amt;
                        oracomm.Parameters.Add("INP_EXPL_CODE", OracleDbType.NVarchar2, 15).Value = Expl_code;
                        oracomm.Parameters.Add("INP_REMARKS", OracleDbType.NVarchar2, 200).Value = Remark;
                        oracomm.Parameters.Add("INP_RQST_CODE", OracleDbType.NVarchar2, 15).Value = Req_code.Trim();
                        oracomm.Parameters.Add("OUT_RETURN_STATUS", OracleDbType.NVarchar2, 100).Direction = ParameterDirection.Output;
                        oracomm.ExecuteNonQuery();
                        result = new GenericModel
                        {
                            RespStat = 0,
                            RespMsg = "",
                            Data1 = oracomm.Parameters["OUT_RETURN_STATUS"].Value.ToString()
                        };
                        oraconn.Close();
                    } 
                } 
            } 
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 1,
                    RespMsg = ex.Message
                };
                //CUtilities.LogFileGlobal_static("Basis", "PostToBasis", ex.ToString(), ex.StackTrace.ToString(), "ERRORS");
            }
            //return ErrorMsg(Result);
            return result;
        }

        public async Task<GenericModel> UpdateTransaction(string msgId, string crAccNo, decimal amount, string cbsres)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MsgId", msgId);
                    parameters.Add("@CrAccNo", crAccNo);
                    parameters.Add("@Amt", amount);
                    parameters.Add("@CBSRef", cbsres);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateTransaction", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdateOutTransactions(PayResponse model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MsgId", model.MsgId);
                    parameters.Add("@ResStat", model.Response);
                    parameters.Add("@ResMsg", model.Msg);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateOutTransaction", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<List<PaymentLookUp>> GetPending()
        {
            List<PaymentLookUp> result = new List<PaymentLookUp>();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();

                    result = connection.Query<PaymentLookUp>("sp_PaymentLookUp", parameters, commandType: CommandType.StoredProcedure).ToList();

                }
            }
            catch (Exception ex)
            {
                
            }
            return result;
        }

        public async Task<GenericModel> PostInstruct(PaymentInst model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@refno", model.MsgId);
                    parameters.Add("@srcref", model.AccMsgId);
                    parameters.Add("@orgref", model.OrgEndToEnd);
                    parameters.Add("@sender", model.SenderId);
                    parameters.Add("@receiver", model.ReceiverId);
                    parameters.Add("@channel", model.Channel);
                    parameters.Add("@txntype", model.TxnType);
                    parameters.Add("@currency", model.Currency);
                    parameters.Add("@amt", model.Amount);
                    parameters.Add("@debit_acc", model.DebAccNo);
                    parameters.Add("@credit_acc", model.CrAccNo);
                    parameters.Add("@remarks", model.Narration);


                    result = connection.Query<GenericModel>("sp_CreateInstructionPay", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> RegisterCustomer(Register model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AccNo", model.AccNo);
                    parameters.Add("@Default", model.Default);
                    parameters.Add("@Doc", model.Document);
                    parameters.Add("@DocNo", model.DocumentNo);
                    parameters.Add("@Email", model.Email);
                    parameters.Add("@PhoneNo", model.PhoneNo);
                    parameters.Add("@CustName", model.CustomerName);

                    result = connection.Query<GenericModel>("sp_RegisterCustomer", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdateCustomerStatus(Register model, RegisterResponse register)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AccNo", model.AccNo);
                    parameters.Add("@Response", register.RegisterDetails);

                    result = connection.Query<GenericModel>("sp_UpdateCustomer", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }
    }
}
