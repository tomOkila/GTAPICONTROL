﻿using DBL.Entities;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IServiceRepository
    {
        Task<IEnumerable<UtilService>> GetListAsync(string name);
        Task<UtilService> GetAsync(int code);
        Task<BaseEntity> UpdateLogoAsync(int serviceCode, byte[] image);
        Task<BaseEntity> ChangeStatAsync(int serviceCode, int stat, string message);
        Task<byte[]> GetLogoAsync(int serviceCode);
        Task<GenericModel> InitApiRequestAsync(int serviceCode, int appCode, int actionCode, string extra1 = "", string extra2 = "", string extra3 = "");
        Task<GenericModel> CreatePaymentAsync(PaymentModel payment,DataTable dt);
        Task<GenericModel> UpdatePaymentAsync(int action, string referenceNo,int deststat, string destref, string destmsg, string extra1 ="", string extra2="");
        Task<GenericModel> PushTransactionAsync(string code, int userCode);
        Task<GenericModel> CreatePesalinkPaymentAsync(PaymentModel payment, DataTable dt);
    }
}
