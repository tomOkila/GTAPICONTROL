﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using DBL.Entities;
using DBL.Models;
using DBL.Repositories;

namespace DBL.Repositories
{
    public class SecurityRepository : BaseRepository, ISecurityRepository
    {
        public SecurityRepository(string connectionString) : base(connectionString)
        {
        }

        public async Task<BaseEntity> ChangeUserPasswordAsync(int userCode, string password, string salt)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserCode", userCode);
                parameters.Add("@Pwd", password);
                parameters.Add("@Salt", salt);

                return (await connection.QueryAsync<BaseEntity>("sp_ChangeUserPassword", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> ChangeUserStatusAsync(int userCode, int status, int maker)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserCode", userCode);
                parameters.Add("@Stat", status);
                parameters.Add("@MakerCode", maker);

                return (await connection.QueryAsync<GenericModel>("sp_ChangeUserStatus", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<BaseEntity> CreateServiceAsync(UtilService service)
        {
            throw new NotImplementedException();
        }

        public async Task<GenericModel> CreateUserAsync(User user, int creator, string password)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Username", user.UserName);
                parameters.Add("@UserRole", user.UserRole);
                parameters.Add("@FullNames", user.FullNames);
                parameters.Add("@Email", user.Email);
                parameters.Add("@PhoneNo", user.PhoneNo);
                parameters.Add("@Salt", user.Salt);
                parameters.Add("@Pwd", user.Pwd);
                parameters.Add("@CreatedBy", creator);
                parameters.Add("@RawPwd", password);

                return (await connection.QueryAsync<GenericModel>("sp_CreateUser", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> GenerateAppTokenAsync(int appCode, string token)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AppCode", appCode);
                parameters.Add("@Token", token);

                return (await connection.QueryAsync<GenericModel>("sp_GenerateAppToken", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> GetAppTokenAsync(int tokenCode, string serviceId)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TokenCode", tokenCode);
                parameters.Add("@ServiceId", serviceId);

                return (await connection.QueryAsync<GenericModel>("sp_GetAppToken", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<SysUserModel> GetUserAsync(int code)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", code);

                return (await connection.QueryAsync<SysUserModel>(FindStatement("vw_Users", "UserCode"), parameters)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> GetUserPasswordAsync(int userCode,string oldpwd,string newpwd)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserCode", userCode);
                parameters.Add("@OldPwd", oldpwd);
                parameters.Add("@NewPwd", newpwd);

                return (await connection.QueryAsync<GenericModel>("sp_ChangeUserPassword", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<IEnumerable<SysUserModel>> GetUsersAsync()
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                return (await connection.QueryAsync<SysUserModel>(GetAllStatement("vw_Users"))).ToList();
            }
        }

        public async Task<GenericModel> ResetUserPasswordAsync(int userCode, string salt, string password, int maker, string pass)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserCode", userCode);
                parameters.Add("@Salt", salt);
                parameters.Add("@Password", password);
                parameters.Add("@MakerCode", maker);
                parameters.Add("@MyPass", pass);

                return (await connection.QueryAsync<GenericModel>("sp_ResetUserPassword", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> UserLoginAsync(int userCode, int status)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserCode", userCode);
                parameters.Add("@LoginStatus", status);

                return (await connection.QueryAsync<GenericModel>("sp_UserLogin", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> VerifyAppAsync(string appId,string appKey)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AppId", appId);
                parameters.Add("@AppKey", appKey);

                return (await connection.QueryAsync<GenericModel>("sp_VerifyApp", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> VerifyAsync(string userName,string password)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserName", userName);
                parameters.Add("@Password", password);

                return (await connection.QueryAsync<GenericModel>("sp_VerifyUser", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

    }
}
