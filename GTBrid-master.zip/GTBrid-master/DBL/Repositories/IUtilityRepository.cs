﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IUtilityRepository
    {
        Task<GenericModel> CreatePayment(ApiRequestModel model, UtilityData airtimeRequest);
        Task<GenericModel> UpdatePayment(string payRef, string msg, string responseCode, string cloudPacket,string identier);
        Task<GenericModel> InitPayment(ApiRequestModel model, UtilityData powerRequest);
        Task<GenericModel> UpdatePayment(Utilities model);
    }
}
