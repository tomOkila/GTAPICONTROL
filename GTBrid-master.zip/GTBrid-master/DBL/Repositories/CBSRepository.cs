﻿using Dapper;
using DBL.Models;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class CBSRepository : BaseRepository, ICBSRepository
    {
        public CBSRepository(string conn) : base(conn)
        {

        }

        public async Task<GenericModel> GetSysSettings()
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> AuthenticateAdvance(string AccountNo)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            if (result.RespStat != 0)
            {
                return result;
            }

            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                {
                    // create the command for the function
                    string query_str = string.Concat(new string[] { "SELECT (CASE WHEN a.LED_CODE BETWEEN 400 AND 499 AND a.CUS_NUM=b.cus_num THEN 1 ELSE 0 END) ||'|' || to_char(a.LIM_MAT_DATE,'ddmmyyyy')  ||'|'|| " +
                        " (Select to_char(bank_date,'ddmmyyyy')  from process where bra_code = a.bra_code) FROM ACCOUNT a "+
                    "Inner Join map_acct b on  a.bra_code= b.bra_code and a.cus_num=b.cus_num  and a.cur_code=b.cur_code and a.led_Code= b.led_code and a.sub_acct_code = b.sub_acct_code "+
                    "where  b.map_acc_no = '"+AccountNo+"' or b.old_acct_no = '"+AccountNo+"'"});
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string data = oracleDataReader.GetString(0);
                                string[] cus = data.Split("|");
                                query_str = string.Concat(new string[] { "select c.tra_amt from transact c inner join  map_acct b on  c.bra_code= b.bra_code and c.cus_num=b.cus_num  and c.cur_code=b.cur_code "+
                                "and c.led_Code= b.led_code and c.sub_acct_code = b.sub_acct_code and c.deb_cre_ind=2 AND c.tra_date>=add_months(trunc(sysdate,'MM'),-3) And UPPER(c.remarks) Like '%SALAR%' "+
                                "where  b.map_acc_no = '"+AccountNo+"' or b.old_acct_no = '"+AccountNo+"'"});

                                oracleCommand.Connection = oracleConnection;
                                oracleCommand.CommandText = query_str;
                                oracleCommand.CommandType = CommandType.Text;
                                DataSet dataSet = new DataSet();
                                using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                {

                                    using (OracleDataAdapter dataAdapter = new OracleDataAdapter())
                                    {
                                        dataAdapter.SelectCommand = oracleCommand;
                                        dataAdapter.Fill(dataSet);
                                    }

                                    DataTable dt = dataSet.Tables[0];

                                    string amount = "";

                                    for (int count = 0; count < dt.Rows.Count; count++)
                                    {
                                         amount += dt.Rows[count]["TRA_AMT"] +"|";
                                    }

                                    return result = new GenericModel
                                    {
                                        RespStat = 0,
                                        RespMsg = "",
                                        Data1 = cus[0],
                                        Data2 = cus[1],
                                        Data3 = amount,
                                        Data4 = cus[2]
                                     };
                                }
                            }
                            else
                            {
                                result = new GenericModel
                                {
                                    RespStat = 1,
                                    RespMsg = "Account doesn't exist!!"
                                };
                                return result;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Unable to retrieve Account details"
                };
            }
            return result;
        }

        public async Task<GenericModel> GetBalance(string AccountNo)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.ToString()
                };
            }

            if (result.RespStat != 0)
            {
                return result;
            }

            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                {
                    // create the command for the function
                    string query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('" + AccountNo + "') from dual" });
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string data = oracleDataReader.GetString(0);
                                string[] cus = data.Split("|");
                                query_str = string.Concat(new string[] { "select navailbal(" + cus[0].Replace("/",",") + ") from dual" });
                                oracleCommand.Connection = oracleConnection;
                                oracleCommand.CommandText = query_str;
                                oracleCommand.CommandType = CommandType.Text;
                                using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                {
                                    oracleDataReader2.Read();
                                    if (oracleDataReader2.HasRows)
                                    {
                                       

                                        return result = new GenericModel
                                        {
                                            RespStat = 0,
                                            RespMsg = "",
                                            Data1 = cus[1],
                                            Data2 = cus[2],
                                            Data3 = cus[4],
                                            Data4 = oracleDataReader2.GetString(0),
                                            Data5=cus[5],
                                            Data6 = cus[6],
                                            Data7 = cus[7]
                                        };
                                    }
                                }
                            }
                            else
                            {
                                result = new GenericModel
                                {
                                    RespStat = 1,
                                    RespMsg = "Account doesn't exist!!"
                                };
                                return result;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Unable to retrieve Account details"
                };
            }
            return result;
        }

        public async Task<GenericModel> GetID(string AccountNo)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            if (result.RespStat != 0)
            {
                return result;
            }

            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                {
                    // create the command for the function
                    string query_str = string.Concat(new string[] { "select crb_id('" + AccountNo + "') from dual" });
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string data = oracleDataReader.GetString(0);
                                string[] cus = data.Split("|");
                                query_str = string.Concat(new string[] { "select navailbal(" + cus[0].Replace("/", ",") + ") from dual" });
                                oracleCommand.Connection = oracleConnection;
                                oracleCommand.CommandText = query_str;
                                oracleCommand.CommandType = CommandType.Text;
                                using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                {
                                    oracleDataReader2.Read();
                                    if (oracleDataReader2.HasRows)
                                    {


                                        return result = new GenericModel
                                        {
                                            RespStat = 0,
                                            RespMsg = "",
                                            Data1=result.Data2,
                                            Data2 = result.Data3,
                                            Data3 = result.Data4,
                                            Data4 = cus[0],
                                            Data5 = cus[2],
                                            Data6 = oracleDataReader2.GetString(0),
                                            Data7=result.Data5,
                                            Data8=result.Data6,
                                            Data9 = cus[3],
                                            Data10= cus[4]
                                        };
                                    }
                                }
                            }
                            else
                            {
                                result = new GenericModel
                                {
                                    RespStat = 1,
                                    RespMsg = "Account doesn't exist!!"
                                };
                                return result;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Unable to retrieve Account details"
                };
            }
            return result;
        }


        public async Task<GenericModel> GetAccountDetails(string accountNumber)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Failed Due to a Technical Issue!"
                };
            }

            if (result.RespStat != 0)
            {
                return result;
            }

            string[] accNo = accountNumber.Split('/');
            string query_str = "";

            if (accNo.Length > 1)
            {
                try
                {
                    using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                    {
                        // create the command for the function
                        query_str = string.Concat(new string[] { "select MAP_ACC_NO from map_acct where bra_code = " + accNo[0] + " and cus_num = " + accNo[1] + "and cur_code = " + accNo[2] + " and led_code = " + accNo[3] + " and sub_acct_code = " + accNo[4] + "" });
                        if (oracleConnection.State == ConnectionState.Closed)
                        {
                            oracleConnection.Open();
                        }
                        using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                        {
                            oracleCommand.Connection = oracleConnection;
                            oracleCommand.CommandText = query_str;
                            oracleCommand.CommandType = CommandType.Text;
                            using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                oracleDataReader.Read();
                                if (oracleDataReader.HasRows)
                                {
                                    string data = oracleDataReader.GetString(0);
                                    query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('" + data + "') from dual" });
                                    oracleCommand.Connection = oracleConnection;
                                    oracleCommand.CommandText = query_str;
                                    oracleCommand.CommandType = CommandType.Text;
                                    using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                    {
                                        oracleDataReader2.Read();
                                        if (oracleDataReader2.HasRows)
                                        {
                                            string[] cus = oracleDataReader2.GetString(0).Split("|");

                                            return result = new GenericModel
                                            {
                                                RespStat = 0,
                                                RespMsg = "",
                                                Data1 = data,
                                                Data2 = cus[1],
                                                Data3 = cus[0],
                                                Data4 = cus[5]
                                            };
                                        }
                                    }
                                }
                                else
                                {
                                    result = new GenericModel
                                    {
                                        RespStat = 1,
                                        RespMsg = "Account doesn't exist!!"
                                    };
                                    return result;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    result = new GenericModel
                    {
                        RespStat = 2,
                        RespMsg = "Unable to retrieve Account details"
                    };
                }
            }
            else
            {
                try
                {
                    using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                    {
                        // create the command for the function
                        query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('" + accountNumber + "') from dual" });
                        if (oracleConnection.State == ConnectionState.Closed)
                        {
                            oracleConnection.Open();
                        }
                        using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                        {
                            oracleCommand.Connection = oracleConnection;
                            oracleCommand.CommandText = query_str;
                            oracleCommand.CommandType = CommandType.Text;
                            using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                oracleDataReader.Read();
                                if (oracleDataReader.HasRows)
                                {
                                    string data = oracleDataReader.GetString(0);
                                    string[] cus = data.Split("|");

                                    return result = new GenericModel
                                    {
                                        RespStat = 0,
                                        RespMsg = "",
                                        Data1 = accountNumber,
                                        Data2 = cus[1],
                                        Data3=cus[0]
                                    };
                                }
                                else
                                {
                                    result = new GenericModel
                                    {
                                        RespStat = 1,
                                        RespMsg = "Account doesn't exist!!"
                                    };
                                    return result;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    result = new GenericModel
                    {
                        RespStat = 2,
                        RespMsg = "Unable to retrieve Account details"
                    };
                }
            }
           
            return result;
        }

        public async Task<List<StatementResp>> GetStatement(StatementReq data)
        {
            GenericModel result = new GenericModel();
            List<StatementResp> statement = new List<StatementResp>();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            if (result.RespStat != 0)
            {
                return statement;
            }

            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(result.Data4))
                {
                    // create the command for the function
                    string query_str = string.Concat(new string[] { "select banksys.pslink_get_cus('" + data.AccountNo + "') from dual" });
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string odata = oracleDataReader.GetString(0);
                                string[] cus = odata.Split("|");
                                string[] cusdata = cus[0].Split("/");
                                query_str = string.Concat(new string[] { "select navailbal(" + cus[0].Replace("/", ",") + ") from dual" });
                                oracleCommand.Connection = oracleConnection;
                                oracleCommand.CommandText = query_str;
                                oracleCommand.CommandType = CommandType.Text;
                                using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                {
                                    oracleDataReader2.Read();
                                    if (oracleDataReader2.HasRows)
                                    {
                                        return statement;
                                    }
                                }
                            }
                            else
                            {
                                return statement;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Unable to retrieve Account details"
                };
            }
            return statement;
        }

        public async Task<List<CBSPosting>> GetUploadTxsnAsync(int batch, int txnpriority)
        {
            List<CBSPosting> posting = new List<CBSPosting>();
            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "Select * From vw_CBSPosting where BatchCode="+batch+ "and TxnPriority=" +txnpriority+ " order by transID asc,Amount desc";
                    DynamicParameters parameters = new DynamicParameters();
                    posting= conn.Query<CBSPosting>(sql, parameters, commandType: CommandType.Text).ToList();
                }
            }
            catch (Exception ex)
            {
                posting = new List<CBSPosting>();
            }
            return posting;
        }

        public async Task<List<CBSPosting>> GetUploadCutOffTxsnAsync(int batch, string transid, int txnpriority)
        {
            List<CBSPosting> posting = new List<CBSPosting>();
            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "Select * From vw_CBSPosting where TxnPriority=" + txnpriority + "  order by transID asc,Amount desc";
                    DynamicParameters parameters = new DynamicParameters();
                    posting = conn.Query<CBSPosting>(sql, parameters, commandType: CommandType.Text).ToList();
                }
            }
            catch (Exception ex)
            {
                posting = new List<CBSPosting>();
            }
            return posting;
        }

        public async Task<List<CBSPosting>> GetDeadlockedPosting()
        {
            List<CBSPosting> posting = new List<CBSPosting>();
            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "Select * From vw_DeadlockTransactions order by transID asc,Amount desc";
                    DynamicParameters parameters = new DynamicParameters();
                    posting = conn.Query<CBSPosting>(sql, parameters, commandType: CommandType.Text).ToList();
                }
            }
            catch (Exception ex)
            {
                posting = new List<CBSPosting>();
            }
            return posting;
        }

        public async Task<GenericModel> LogUploadTxnsAync(DataTable txnTable, string cusNo,int appId, PostTransaction model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection=new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AppId", appId);
                    parameters.Add("@CusNo", cusNo);
                    parameters.Add("@Batch", model.Batch);
                    parameters.Add("@Txns", txnTable.AsTableValuedParameter("dbo.PostTxnTable"));

                    result = (await connection.QueryAsync<GenericModel>("sp_LogUploadTxns", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 3600)).FirstOrDefault();
                }
            }
            catch(Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }

        public async Task<GenericModel> UpdateTransation(DataTable dt)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.TxnUploadResultTable"));

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateUploadTxns", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }

        public async Task<GenericModel> UpdateUtilityTransation(DataTable dt)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.TxnUploadResultTable"));

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateTransTxns", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }

        public async Task<List<UtilReq>> GetTransactions(int batchCode, string transID,int TxnCode)
        {
            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "Select * From vw_PendingUtil where SourceRef="+ transID + " and BatchCode="+batchCode;
                    DynamicParameters parameters = new DynamicParameters();
                    return conn.Query<UtilReq>(sql, parameters, commandType: CommandType.Text).ToList();
                }
            }
            catch (Exception ex)
            {
                
            }
            return new List<UtilReq>();
        }

        public async Task<GenericModel> PostTransactions(int appID, int sourceRef, int batchCode, int txnType)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AppCode", appID);
                    parameters.Add("@SourceRef", sourceRef);
                    parameters.Add("@Batch", batchCode);
                    parameters.Add("@PayType", txnType);

                    result = (await connection.QueryAsync<GenericModel>("sp_PostUtilityTrans", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }

        public async Task<GenericModel> GetLeastMonth(string accountNo,decimal advance)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 0);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetSysSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            if (result.RespStat != 0)
            {
                return result;
            }

            string[] Acct_From = accountNo.Split("/");

            try
            {
                using (OracleConnection oracleConnection = new OracleConnection(result.Data1))
                {
                    // create the command for the function
                    string query_str = string.Concat(new string[] { "SELECT  to_char(bank_date,'ddmmyyyy')||'|'||to_char(to_date((SELECT min(extract( day from trunc(tra_date))) as tra_date FROM TRANSACT " +
                        "WHERE bra_code='" + Acct_From[0] + "' and cus_num='"  + Acct_From[1] + "' and cur_code='" + Acct_From[2] + "' and led_Code='"  + Acct_From[3] + "' And " +
                        "sub_acct_code ='" + Acct_From[4] + "' and deb_cre_ind=2 And UPPER(remarks) Like '%SALAR%' AND tra_date>=add_months(trunc(sysdate,'MM'),-3)" +
                        ")|| to_char(bank_date,'MM-YY'),'DD-MM-YY'),'ddmmyyyy') from process where bra_code ='" + Acct_From[0] + "'" });
                    if (oracleConnection.State == ConnectionState.Closed)
                    {
                        oracleConnection.Open();
                    }
                    using (OracleCommand oracleCommand = new OracleCommand("SQLCheckExist", oracleConnection))
                    {
                        oracleCommand.Connection = oracleConnection;
                        oracleCommand.CommandText = query_str;
                        oracleCommand.CommandType = CommandType.Text;
                        using (OracleDataReader oracleDataReader = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            oracleDataReader.Read();
                            if (oracleDataReader.HasRows)
                            {
                                string[] days= oracleDataReader.GetString(0).ToString().Split("|");



                                if (DateTime.Parse(DateTime.ParseExact(days[0], "ddMMyyyy", CultureInfo.InvariantCulture).ToString()) < DateTime.Parse(DateTime.ParseExact(days[1], "ddMMyyyy", CultureInfo.InvariantCulture).ToString()))
                                {
                                    query_str = string.Concat(new string[] { "update account set BAL_LIM = " + advance + " ,LIM_MAT_DATE= '" + DateTime.Parse(DateTime.ParseExact(days[1], "ddMMyyyy", CultureInfo.InvariantCulture).ToString()).AddDays(-3).ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture) + "' WHERE bra_code= " + Acct_From[0] + " and cus_num= " + Acct_From[1] + " and cur_code=" + Acct_From[2] + " and led_Code= " + Acct_From[3] + " And sub_acct_code = " + Acct_From[4] + "" });
                                }
                                else
                                {
                                    query_str = string.Concat(new string[] { "update account set BAL_LIM = " + advance + " ,LIM_MAT_DATE= '" + DateTime.Parse(DateTime.ParseExact(days[1], "ddMMyyyy", CultureInfo.InvariantCulture).ToString()).AddDays(-3).AddMonths(1).ToString("dd-MMM-yyyy", CultureInfo.InvariantCulture) + "' WHERE bra_code= " + Acct_From[0] + " and cus_num= " + Acct_From[1] + " and cur_code=" + Acct_From[2] + " and led_Code= " + Acct_From[3] + " And sub_acct_code = " + Acct_From[4] + "" });
                                }

                               
                                oracleCommand.Connection = oracleConnection;
                                oracleCommand.CommandText = query_str;
                                oracleCommand.CommandType = CommandType.Text;
                                using (OracleDataReader oracleDataReader2 = oracleCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                {
                                    result = new GenericModel
                                    {
                                        RespStat = 0
                                    };
                                    return result;
                                }
                            }
                            else
                            {
                                result = new GenericModel
                                {
                                    RespStat = 1
                                };
                                return result;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Unable to retrieve Account details"
                };
            }
            return result;
        }

        public async Task<List<PostTran>> GetGapsTransactions(int batch ,int txnType)
        {
            try
            {
                using (var conn = new SqlConnection(_connString))
                {
                    conn.Open();

                    string sql = "Select  * From vw_PendingSMTransactions where Batch=" + batch+ " and Type=" + txnType;
                    DynamicParameters parameters = new DynamicParameters();
                    return conn.Query<PostTran>(sql, parameters, commandType: CommandType.Text,commandTimeout : 3600).ToList();
                }
            }
            catch (Exception ex)
            {
                
            }
            return new List<PostTran>();
        }

        public async Task<GenericModel> LogSalaryAdvReq(int appId, SalaryAdReq sal)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AppId", appId);
                    parameters.Add("@CusNo", sal.CustomerNumber);
                    parameters.Add("@Acc", sal.AccountNo);
                    parameters.Add("@Amt", sal.Amount);

                    result = (await connection.QueryAsync<GenericModel>("sp_LogSalaryAdv", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }

        public async Task<GenericModel> UpdateChannelTxns(DataTable dt, int appID)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@App", appID);
                    parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.UpdateChannels"));

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateChannelTxns", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }

            return result;
        }
    }
}
