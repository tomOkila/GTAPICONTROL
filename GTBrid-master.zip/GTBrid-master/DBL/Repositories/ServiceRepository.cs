﻿using Dapper;
using DBL.Entities;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class ServiceRepository : BaseRepository, IServiceRepository
    {
        public ServiceRepository(string connectionString) : base(connectionString)
        {
        }

        public async Task<BaseEntity> ChangeStatAsync(int serviceCode, int stat, string message)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ServiceCode", serviceCode);
                parameters.Add("@Stat", stat);
                parameters.Add("@Msg", message);

                return (await connection.QueryAsync<BaseEntity>("sp_ChangeServiceStat", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> CreatePaymentAsync(PaymentModel payment,DataTable dt)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ServiceCode", payment.ServiceCode);
                parameters.Add("@AppCode", payment.AppCode);
                parameters.Add("@ActionCode", payment.ActionCode);
                parameters.Add("@PaymentRef", payment.PaymentRef);
                parameters.Add("@Currency", payment.Currency);
                parameters.Add("@Process", payment.Process);
                parameters.Add("@PayType", payment.PayType);
                parameters.Add("@Balance", payment.Balance);
                parameters.Add("@CusAcc", payment.CusAcc);
                parameters.Add("@SrcID", payment.SourceID);
                parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.BatchData"));

                return (await connection.QueryAsync<GenericModel>("sp_CreatePayment", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 3600)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> CreatePesalinkPaymentAsync(PaymentModel payment, DataTable dt)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ServiceCode", payment.ServiceCode);
                parameters.Add("@AppCode", payment.AppCode);
                parameters.Add("@ActionCode", payment.ActionCode);
                parameters.Add("@PaymentRef", payment.PaymentRef);
                parameters.Add("@Currency", payment.Currency);
                parameters.Add("@PayType", payment.PayType);
                parameters.Add("@Balance", payment.Balance);
                parameters.Add("@CusAcc", payment.CusAcc);
                parameters.Add("@Txns", dt.AsTableValuedParameter("dbo.BatchData"));

                return (await connection.QueryAsync<GenericModel>("sp_CreatePesalinkPayment", parameters, commandType: CommandType.StoredProcedure, commandTimeout: 3600)).FirstOrDefault();
            }
        }

        public async Task<UtilService> GetAsync(int code)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", code);

                return (await connection.QueryAsync<UtilService>(FindStatement("vw_UtilServices", "ServiceCode"), parameters)).FirstOrDefault();
            }
        }

        public async Task<IEnumerable<UtilService>> GetListAsync(string name)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                string sql = "Select top 20 * From vw_UtilServices";
                if (!string.IsNullOrEmpty(name))
                    sql += " where serviceName like '%" + name + "%'";

                return (await connection.QueryAsync<UtilService>(sql)).ToList();
            }
        }

        public async Task<byte[]> GetLogoAsync(int serviceCode)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", serviceCode);

                string sql = "Select Logo From UtilServices Where ServiceCode = @Id";

                return (await connection.QueryAsync<byte[]>(sql, parameters)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> InitApiRequestAsync(int serviceCode, int appCode, int actionCode, string extra1 = "", string extra2 = "", string extra3 = "")
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ServiceCode", serviceCode);
                parameters.Add("@AppCode", appCode);
                parameters.Add("@ActionCode", actionCode);
                parameters.Add("@Extra1", extra1);
                parameters.Add("@Extra2", extra2);
                parameters.Add("@Extra3", extra3);

                return (await connection.QueryAsync<GenericModel>("sp_InitServiceApiReq", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<BaseEntity> UpdateLogoAsync(int serviceCode, byte[] image)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ServiceCode", serviceCode);
                parameters.Add("@Logo", image);

                return (await connection.QueryAsync<BaseEntity>("sp_UpdateServiceLogo", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> UpdatePaymentAsync(int action, string referenceNo,int deststat, string destref, string destmsg, string extra1 = "", string extra2 = "")
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ActionCode", action);
                parameters.Add("@RefNo", referenceNo);
                parameters.Add("@DestStat", deststat);
                parameters.Add("@DestRef", destref);
                parameters.Add("@DestMsg", destmsg);
                parameters.Add("@Extra1", extra1);
                parameters.Add("@Extra2", extra2);

                return (await connection.QueryAsync<GenericModel>("sp_UpdatePayments", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

       

        public async Task<GenericModel> PushTransactionAsync(string code, int userCode)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@tranCode", code);
                parameters.Add("@userCode", userCode);

                return (await connection.QueryAsync<GenericModel>("sp_PushTransaction", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }
    }
}
