﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface ICBSRepository
    {
        Task<GenericModel> GetBalance(string AccountNo);
        Task<GenericModel> GetAccountDetails(string AccountNo);
        Task<GenericModel> GetID(string AccountNo);
        Task<List<StatementResp>> GetStatement(StatementReq data);
        Task<GenericModel> AuthenticateAdvance(string accountNo);
        Task<GenericModel> LogUploadTxnsAync(DataTable txnTable, string cusNo,int appId, PostTransaction postTxns);
        Task<List<CBSPosting>> GetUploadTxsnAsync(int batch, int v);
        Task<List<CBSPosting>> GetUploadCutOffTxsnAsync(int batchCode, string transID, int TxnCode);

        Task<GenericModel> UpdateTransation(DataTable dt);
        Task<List<UtilReq>> GetTransactions(int batchCode, string transID,int TxnCode);
        Task<GenericModel> PostTransactions(int appID, int sourceRef, int batchCode, int txnType);
        Task<GenericModel> UpdateUtilityTransation(DataTable dt);
        Task<GenericModel> GetLeastMonth( string accountNo,decimal advance);
        Task<List<PostTran>> GetGapsTransactions(int batch, int txnType);
        Task<GenericModel> LogSalaryAdvReq(int appId, SalaryAdReq sal);
        Task<GenericModel> UpdateChannelTxns(DataTable dt, int appID);
        Task<GenericModel> GetSysSettings();
        Task<List<CBSPosting>> GetDeadlockedPosting();
    }
}
