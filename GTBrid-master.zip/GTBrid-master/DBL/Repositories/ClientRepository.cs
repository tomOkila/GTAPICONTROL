﻿using Dapper;
using DBL.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class ClientRepository : BaseRepository, IClientRepository
    {
        public ClientRepository(string connectionString) : base(connectionString)
        {
        }

        public async Task<BaseEntity> ChangeAppStatAsync(int appCode, int stat)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AppCode", appCode);
                parameters.Add("@Stat", stat);

                return (await connection.QueryAsync<BaseEntity>("sp_ChangeAppStat", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<BaseEntity> ChangeStatAsync(int clientCode, int stat)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ClientCode", clientCode);
                parameters.Add("@Stat", stat);

                return (await connection.QueryAsync<BaseEntity>("sp_ChangeClientStat", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<BaseEntity> CreateAppAsync(ClientApp clientApp)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ClientCode", clientApp.ClientCode);
                parameters.Add("@AppName", clientApp.AppName);
                parameters.Add("@AppId", clientApp.AppId);
                parameters.Add("@AppKey", clientApp.AppKey);
                parameters.Add("@Salt", clientApp.Salt);

                return (await connection.QueryAsync<BaseEntity>("sp_CreateApp", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<BaseEntity> CreateAsync(Client client, ClientApp clientApp)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@ClientName", client.ClientName);
                parameters.Add("@EMail", client.EMail);
                parameters.Add("@Contacts", client.Contacts);
                parameters.Add("@PAddress", client.PAddress);
                parameters.Add("@CreatedBy", client.CreatedBy);
                parameters.Add("@AccountNo", client.AccountNo);
                parameters.Add("@AppId", clientApp.AppId);
                parameters.Add("@AppKey", clientApp.AppKey);
                parameters.Add("@Url", client.CallBack);

                return (await connection.QueryAsync<BaseEntity>("sp_CreateClient", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<ClientApp> GetAppAsync(int appCode)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", appCode);

                return (await connection.QueryAsync<ClientApp>(FindStatement("vw_ClientApps", "AppCode"), parameters)).FirstOrDefault();
            }
        }

        public async Task<IEnumerable<ClientApp>> GetAppsAsync(int clientCode)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", clientCode);

                return (await connection.QueryAsync<ClientApp>(FindStatement("vw_ClientApps", "ClientCode"), parameters)).ToList();
            }
        }

        public async Task<Client> GetAsync(int code)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Id", code);

                return (await connection.QueryAsync<Client>(FindStatement("vw_Clients", "ClientCode"), parameters)).FirstOrDefault();
            }
        }

        public async Task<IEnumerable<Client>> GetListAsync(string name)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                string sql = "Select top 20 * From vw_Clients";
                if (!string.IsNullOrEmpty(name))
                    sql += " where ClientName like '%" + name + "%'";
                sql += " Order By ClientCode Desc";

                return (await connection.QueryAsync<Client>(sql)).ToList();
            }
        }

        public async Task<BaseEntity> ResetAppAsync(int appCode, string key, string salt)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AppCode", appCode);
                parameters.Add("@AppKey", key);
                parameters.Add("@Salt", salt);

                return (await connection.QueryAsync<BaseEntity>("sp_ResetApp", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

    }
}
