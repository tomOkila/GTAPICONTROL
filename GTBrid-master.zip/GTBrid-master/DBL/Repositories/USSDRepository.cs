﻿using Dapper;
using DBL.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class USSDRepository : BaseRepository, IUSSDRepository
    {

        public USSDRepository(string conn) : base(conn)
        {

        }

        public async Task<DataTable> GetAccounts(string data2)
        {
            DataTable table = new DataTable();
            
            try
            {
                using (OracleConnection OraConn = new OracleConnection("Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.0.208)(PORT=1521)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=HOBANK.WORLD4))); User Id=banksys;Password=banksys;Persist Security Info=False;"))
                {

                    using (OracleCommand OraSelect = new OracleCommand())
                    {
                        OracleDataReader OraDrSelect;
                        try
                        {
                            if (OraConn.State == ConnectionState.Closed)
                            {
                                OraConn.Open();
                            }
                            OraSelect.Connection = OraConn;
                            string selectquery = "select  Map_Acc_No from map_acct where Cus_Num = '" + data2 + "'";
                            OraSelect.CommandText = selectquery;
                            OraSelect.CommandType = CommandType.Text;
                            using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                if (OraDrSelect.HasRows == true)
                                {
                                    table.Load(OraDrSelect);
                                }                                  
                            }
                        }
                        catch (Exception ex)
                        {
                            return table;
                        }
                        finally
                        {
                            if (OraConn.State == ConnectionState.Open)
                            {
                                OraConn.Close();
                            }
                            OraConn.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                table = null ;
            }
            return table;
        }

        public async Task<GenericModel> ProcessRequestAsync(USSDRequest model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MNOCode", model.MnoCode);
                    parameters.Add("@PhoneNo", model.PhoneNo);
                    parameters.Add("@DataText", model.DataText);
                    parameters.Add("@SessionId", model.SessionId);
                    //parameters.Add("@acc_num", model.AccNo);

                    result = (await connection.QueryAsync<GenericModel>("sp_ProcessUSSDReq", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Service Unaivalable due to Technical Error"
                };
            }
            return result;
        }

        public async Task<GenericModel> SaveAccount(string data12, string cus_accts)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 1);
                    parameters.Add("@SessionId", data12);
                    parameters.Add("@acc_num", cus_accts);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateSessionAccounts", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> SaveAccounts(string data12, string cus_accts)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", 2);
                    parameters.Add("@SessionId", data12);
                    parameters.Add("@acc_num", cus_accts);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateSessionAccounts", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }
    }
}
