﻿using DBL.Enums;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IGeneralRepository
    {
        Task<GenericModel> GetParamSetAsync(ParamSetType setType, int code);
        Task<IEnumerable<ListModel>> GetItemListAsync( int code);
    }
}
