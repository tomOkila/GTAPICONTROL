﻿
using DBL.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IClientRepository
    {
        Task<IEnumerable<Client>> GetListAsync(string name);
        Task<Client> GetAsync(int code);
        Task<BaseEntity> CreateAsync(Client client, ClientApp clientApp);
        Task<BaseEntity> ChangeStatAsync(int clientCode, int stat);

        Task<IEnumerable<ClientApp>> GetAppsAsync(int clientCode);
        Task<ClientApp> GetAppAsync(int appCode);
        Task<BaseEntity> ResetAppAsync(int appCode, string key, string salt);
        Task<BaseEntity> ChangeAppStatAsync(int appCode, int stat);
        Task<BaseEntity> CreateAppAsync(ClientApp clientApp);
    }
}
