﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IPesaLinkRepository
    {
        Task<GenericModel> CheckDetails(AuthData model, int v);
        Task<GenericModel> PayOut(PaymentRequest model, DataTable dt, string mainRef);
        Task<GenericModel> ValidateCustomer(AuthData model, int v);
        Task<GenericModel> PostIn(PaymentAccpetance model, DataTable dt, string mainRef);
        Task<GenericModel> GetOldAccount(PaymentAccpetance model, int v);
        Task<GenericModel> PostToBasis(string v1, string crAccNo, double v2, int v3, string narration, string v4, string data2);
        Task<GenericModel> UpdateTransaction(string msgId, string crAccNo, decimal amount, string data1);
        Task<GenericModel> UpdateOutTransactions(PayResponse model);
        Task<List<PaymentLookUp>> GetPending();
        Task<GenericModel> PostInstruct(PaymentInst model);
        Task<GenericModel> RegisterCustomer(Register model);
        Task<GenericModel> UpdateCustomerStatus(Register model, RegisterResponse register);
    }
}
