﻿using Dapper;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class UtilityRepository : BaseRepository, IUtilityRepository
    {
        public UtilityRepository(string conn) : base(conn)
        {

        }

        public async Task<GenericModel> CreatePayment(ApiRequestModel model, UtilityData req)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AppCode", model.AppId);
                    parameters.Add("@ActionCode", model.Action);
                    parameters.Add("@ServiceCode", req.Service);
                    parameters.Add("@Amount", req.Amount);
                    parameters.Add("@SourceRef", req.TransactionRef);
                    parameters.Add("@PaymentRef", req.PayRef);
                    parameters.Add("@Phone", req.PhoneNo);
                    parameters.Add("@Account", req.AccNo);

                    result = (await connection.QueryAsync<GenericModel>("sp_CreateUtilityPayment", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> InitPayment(ApiRequestModel model, UtilityData req)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@AppCode", model.AppId);
                    parameters.Add("@ActionCode", model.Action);
                    parameters.Add("@ServiceCode", req.Service);
                    parameters.Add("@Account", req.AccNo);
                    parameters.Add("@Query", req.Presentment);
                    parameters.Add("@SrcRef", req.TransactionRef);
                    parameters.Add("@Amount", req.Amount);

                    result = (await connection.QueryAsync<GenericModel>("sp_InitUtilityPayment", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdatePayment(string payRef, string msg, string responseCode, string cloudPacket,string identier)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PayRef", payRef);
                    parameters.Add("@Msg", msg);
                    parameters.Add("@Receipt", cloudPacket);
                    parameters.Add("@ResCode", responseCode);
                    parameters.Add("@Unique", identier);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateUtilityPayment", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdateWaterPayment(string payRef, string msg, string responseCode, string cloudPacket, string identier)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PayRef", payRef);
                    parameters.Add("@Msg", msg);
                    parameters.Add("@Receipt", cloudPacket);
                    parameters.Add("@ResCode", responseCode);
                    parameters.Add("@Unique", identier);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateUtilityPayment", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdatePayment(Utilities model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PayRef", model.TransactionID);
                    parameters.Add("@Hash", model.HASH);
                    parameters.Add("@Status", model.Status);
                    parameters.Add("@ResCode", model.ResponseCode);
                    parameters.Add("@Response", model.Response);

                    result = (await connection.QueryAsync<GenericModel>("sp_UpdateUtilityCallback", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }
    }
}
