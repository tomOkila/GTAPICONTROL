﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IMpesaRepository
    {
        Task<GenericModel> UpdatePayment(int stat,string param, decimal amount, string receipt, string date, string phone);
        Task<GenericModel> MakePayment(GTCollectStk model);
        Task<GenericModel> UpdateStkPayment(int stat, string merchant,string referenceNo);
        Task<GenericModel> MpesaLookUp(string transref, string referenceNo);
        Task<GenericModel> RegisterMerchant(DataTable dt);
        Task<GenericModel> Settlement(DataTable dt);
        Task<GenericModel> MpesaB2CUpdate(MpesaData mpesa);
        Task<GenericModel> MpesaB2BUpdate(MpesaData mpesa);
        Task<GenericModel> GetSystemSettings(MpesaPayment mpesa);
        Task<GenericModel> CreateCollectionPayment(GTCollect model);
        Task<GenericModel> UpdateCollectionPayment(int v, string merchant, string data5);
        Task<GenericModel> QueryTransaction(string data4);
        Task<GenericModel> CreateGTCollectionPayment(MpesaPayment model);
    }
}
