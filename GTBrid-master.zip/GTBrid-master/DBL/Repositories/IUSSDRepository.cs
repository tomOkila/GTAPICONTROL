﻿using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface IUSSDRepository
    {
        Task<GenericModel> ProcessRequestAsync(USSDRequest requestData);
        Task<DataTable> GetAccounts(string data2, string data4);
        Task<GenericModel> UpdateSessionAsync(int sessionCode, int callCode, GenericModel extraData);
    }
}
