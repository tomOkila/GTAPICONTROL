﻿using Dapper;
using DBL.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class USSDRepository : BaseRepository, IUSSDRepository
    {

        public USSDRepository(string conn) : base(conn)
        {

        }

        public async Task<DataTable> GetAccounts(string data2, string data4)
        {
            DataTable table = new DataTable();
            
            try
            {
                using (OracleConnection OraConn = new OracleConnection(data4))
                {

                    using (OracleCommand OraSelect = new OracleCommand())
                    {
                        OracleDataReader OraDrSelect;
                        try
                        {
                            if (OraConn.State == ConnectionState.Closed)
                            {
                                OraConn.Open();
                            }
                            OraSelect.Connection = OraConn;
                            string selectquery = "select  Map_Acc_No from map_acct where Cus_Num = '" + data2 + "'";
                            OraSelect.CommandText = selectquery;
                            OraSelect.CommandType = CommandType.Text;
                            using (OraDrSelect = OraSelect.ExecuteReader(CommandBehavior.CloseConnection))
                            {
                                if (OraDrSelect.HasRows == true)
                                {
                                    table.Load(OraDrSelect);
                                }                                  
                            }
                        }
                        catch (Exception ex)
                        {
                            return table;
                        }
                        finally
                        {
                            if (OraConn.State == ConnectionState.Open)
                            {
                                OraConn.Close();
                            }
                            OraConn.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                table = null ;
            }
            return table;
        }

        public async Task<GenericModel> ProcessRequestAsync(USSDRequest model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MNOCode", model.MnoCode);
                    parameters.Add("@PhoneNo", model.PhoneNo);
                    parameters.Add("@DataText", model.DataText);
                    parameters.Add("@SessionId", model.SessionId);
                    //parameters.Add("@acc_num", model.AccNo);

                    result = (await connection.QueryAsync<GenericModel>("sp_ProcessUSSDReq", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = "Failed Due to a Technical Issue!"
                };
            }
            return result;
        }


        public async Task<GenericModel> UpdateSessionAsync(int sessionCode, int callCode, GenericModel data)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@SessionCode", sessionCode);
                parameters.Add("@CallCode", callCode);
                parameters.Add("@UpdateStat", data.RespStat);
                parameters.Add("@UpdateMsg", data.RespMsg);
                parameters.Add("@Data1", data.Data1);
                parameters.Add("@Data2", data.Data2);
                parameters.Add("@Data3", data.Data3);
                parameters.Add("@Data4", data.Data4);
                parameters.Add("@Data5", data.Data5);
                parameters.Add("@Data6", data.Data6);
                return (await connection.QueryAsync<GenericModel>("sp_UpdateUSSDSesssion", parameters, commandType: System.Data.CommandType.StoredProcedure)).FirstOrDefault();
            }
        }
    }

}