﻿using DBL.Entities;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public interface ISecurityRepository
    {
        Task<GenericModel> VerifyAsync(string userName,string password);
        Task<GenericModel> UserLoginAsync(int userCode, int status);
        Task<GenericModel> CreateUserAsync(User user, int creator, string password);
        Task<IEnumerable<SysUserModel>> GetUsersAsync();
        Task<SysUserModel> GetUserAsync(int code);

        Task<GenericModel> ResetUserPasswordAsync(int userCode, string salt, string password, int maker, string pass);
        Task<GenericModel> GetUserPasswordAsync(int userCode, string oldpwd, string newpwd);
        Task<BaseEntity> ChangeUserPasswordAsync(int userCode, string password, string salt);
        Task<GenericModel> ChangeUserStatusAsync(int userCode, int status, int scope);

        Task<GenericModel> VerifyAppAsync(string appId,string appKey);
        Task<GenericModel> GenerateAppTokenAsync(int appCode, string token);
        Task<GenericModel> GetAppTokenAsync(int tokenCode, string serviceId);
        Task<BaseEntity> CreateServiceAsync(UtilService service);
    }
}
