﻿using Dapper;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class TAXRepository : BaseRepository, ITAXRepository
    {
        public TAXRepository(string connectionString) : base(connectionString)
        {
        }

        public async Task<GenericModel> LogTaxDetails(KRAQueryResponse data)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AppCode", data.ESlipNumber);
                parameters.Add("@Stat", data.SlipPaymentCode);
                parameters.Add("@AppCode", data.PaymentAdviceDate);
                parameters.Add("@Stat", data.PIN);
                parameters.Add("@AppCode", data.PayerName);
                parameters.Add("@Stat", data.TotalAmount);
                parameters.Add("@AppCode", data.DocRefNumber);
                parameters.Add("@Stat", data.Currency);
                parameters.Add("@AppCode", data.TaxCode);
                parameters.Add("@Stat", data.TaxHead);
                parameters.Add("@AppCode", data.Component);
                parameters.Add("@Stat", data.Amt);
                parameters.Add("@AppCode", data.TaxPeriod);

                return (await connection.QueryAsync<GenericModel>("sp_LogTaxDetails", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }

        public async Task<GenericModel> QueryTax(DeclarationQueryData model)
        {
            using (var connection = new SqlConnection(_connString))
            {
                connection.Open();

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@SlipNumber", model.SlipNumber);

                return (await connection.QueryAsync<GenericModel>("sp_ValidateRRN", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();
            }
        }
    }
}
