﻿using Dapper;
using DBL.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DBL.Repositories
{
    public class MpesaRepository : BaseRepository, IMpesaRepository
    {
        public MpesaRepository(string conn) : base(conn)
        {

        }

        public async Task<GenericModel> MakePayment(GTCollectStk model)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MainRef", Guid.NewGuid().ToString("N"));
                    parameters.Add("@SourceRef", model.ReferenceNo);
                    parameters.Add("@WareHouse", model.WareHouse);
                    parameters.Add("@AccountName", model.AccountName);
                    parameters.Add("@AccountNo", model.AccountNumber);
                    parameters.Add("@App", model.AppCode);
                    parameters.Add("@Phone", model.PhoneNo);
                    parameters.Add("@Amt", model.Amount);

                    result = connection.Query<GenericModel>("sp_CreateMpesaPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }


        public async Task<GenericModel> GetSystemSettings(MpesaPayment model)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@type", model.PayBillNo);

                    result = (await connection.QueryAsync<GenericModel>("sp_GetGtCollectSettings", parameters, commandType: CommandType.StoredProcedure)).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> MpesaB2CUpdate(MpesaData mpesa)
        {
            GenericModel result = new GenericModel();

            var tries = 5;
            string msg = "";
            while (tries > 0)
            {
                try
                {
                    using (var connection = new SqlConnection(_connString))
                    {
                        connection.Open();

                        DynamicParameters parameters = new DynamicParameters();
                        parameters.Add("@Broker", mpesa.BrokerId);
                        parameters.Add("@ResultCode", mpesa.ResultCode);
                        parameters.Add("@Msg", mpesa.RespMsg);
                        parameters.Add("@ConvId", mpesa.ConvId);
                        parameters.Add("@Receipt", mpesa.Receipt);
                        parameters.Add("@Date", mpesa.Date);
                        parameters.Add("@Float", mpesa.Float);
                        parameters.Add("@Remarks", mpesa.Remarks);

                       result = connection.Query<GenericModel>("sp_UpdateMpesaB2C", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                        tries = 0;
                    }
                }
                catch (Exception ex)
                {
                    Thread.Sleep(500);
                    tries--;
                    result= new GenericModel
                    {
                        RespStat = 2,
                        RespMsg = msg
                    };
                }
            }
            return result;
        }

        public async Task<GenericModel> MpesaB2BUpdate(MpesaData mpesa)
        {
            GenericModel result = new GenericModel();
            var tries = 0;
            string msg = "";
            while (tries <= 5)
            {
                try
                {
                    using (var connection = new SqlConnection(_connString))
                    {
                        connection.Open();

                        DynamicParameters parameters = new DynamicParameters();
                        parameters.Add("@Broker", mpesa.BrokerId);
                        parameters.Add("@ResultCode", mpesa.ResultCode);
                        parameters.Add("@Msg", mpesa.RespMsg);
                        parameters.Add("@ConvId", mpesa.ConvId);
                        parameters.Add("@Receipt", mpesa.Receipt);
                        parameters.Add("@Date", mpesa.Date);
                        parameters.Add("@Float", mpesa.Float);
                        parameters.Add("@Remarks", mpesa.Remarks);

                        return result = connection.Query<GenericModel>("sp_UpdateMpesaB2B", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                    }
                }
                catch (Exception ex)
                {
                    tries++;
                    msg = ex.ToString();
                }
            } 
            return new GenericModel
            {
                RespStat = 2,
                RespMsg = msg
            };
        }


        public async Task<GenericModel> MpesaLookUp(string transref, string referenceNo)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@TransRef", transref);
                    parameters.Add("@RefNo", referenceNo);

                    result = connection.Query<GenericModel>("sp_MpesaLookUp", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> RegisterMerchant(DataTable dt)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Merchants", dt.AsTableValuedParameter("dbo.MerchantData"));

                    result = connection.Query<GenericModel>("sp_RegisterMerchant", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> Settlement(DataTable dt)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Settlemet", dt.AsTableValuedParameter("dbo.SettlementData"));

                    result = connection.Query<GenericModel>("sp_CreateSettlementPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdatePayment(int stat,string param, decimal amount, string receipt, string date, string phone)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Stat", stat);
                    parameters.Add("@SourceRef", param);
                    parameters.Add("@Amt", amount);
                    parameters.Add("@Receipt", receipt);
                    parameters.Add("@Phone", phone);

                    result = connection.Query<GenericModel>("sp_CallBackUpdate", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> UpdateStkPayment(int stat, string merchant,string referenceNo)
        {
            GenericModel result = new GenericModel();

            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Stat", stat);
                    parameters.Add("@SourceRef", referenceNo);
                    parameters.Add("@MerchantRes", merchant);

                    result = connection.Query<GenericModel>("sp_UpdateSTK", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> CreateCollectionPayment(GTCollect model)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@MainRef", Guid.NewGuid().ToString("N"));
                    parameters.Add("@Institution", model.Institution);
                    parameters.Add("@PayReason", model.PayReason);
                    parameters.Add("@PayMethod", model.PayMethod);
                    parameters.Add("@AccountNo", model.StudentNumber);
                    parameters.Add("@Email", model.Email);
                    parameters.Add("@Phone", model.Phone);
                    parameters.Add("@Amt", model.Amount);
                    parameters.Add("@Name", model.Name);
                    parameters.Add("@OtherReason", model.OtherReason);

                    result = connection.Query<GenericModel>("sp_CreateCollectionPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }


        public async Task<GenericModel> CreateGTCollectionPayment(MpesaPayment model)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PayBill", model.PayBillNo);
                    parameters.Add("@StuNo", model.AccountNo);
                    parameters.Add("@MpesaID", model.CustRefno);
                    parameters.Add("@Phone", model.Phone);
                    parameters.Add("@StuName", model.StudentName);
                    result = connection.Query<GenericModel>("sp_CreateGtCollectCollectionPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }



        public async Task<GenericModel> UpdateCollectionPayment(int respcode, string merchant, string refNo)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@RespCode", respcode);
                    parameters.Add("@MerchantRes", merchant);
                    parameters.Add("@RefNo", refNo);


                    result = connection.Query<GenericModel>("sp_UpdateCollectionPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }

        public async Task<GenericModel> QueryTransaction(string refNo)
        {
            GenericModel result = new GenericModel();
            try
            {
                using (var connection = new SqlConnection(_connString))
                {
                    connection.Open();

                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@RefNo", refNo);


                    result = connection.Query<GenericModel>("sp_ValidateCollectionPayment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
            }
            catch (Exception ex)
            {
                result = new GenericModel
                {
                    RespStat = 2,
                    RespMsg = ex.Message
                };
            }
            return result;
        }
    }
}
