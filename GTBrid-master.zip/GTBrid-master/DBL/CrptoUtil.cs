﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DBL
{
    public class CrptoUtil
    {
        public static string MD5Hash(string input)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string HEXValue(string plainText)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToHexString(bytes);
        }

        public static string DESEncrypt(string text, string kes)
        {
            System.Security.Cryptography.TripleDESCryptoServiceProvider tripleDES = new System.Security.Cryptography.TripleDESCryptoServiceProvider();
            byte[] data = Encoding.UTF8.GetBytes(text);
            byte[] key = Encoding.UTF8.GetBytes(kes);
            tripleDES.Key = key;
            tripleDES.IV = new byte[tripleDES.BlockSize / 8];
            var encryptor = tripleDES.CreateEncryptor();
            byte[] result = new byte[data.Length];
            result = encryptor.TransformFinalBlock(data, 0, data.Length);
            string res = BitConverter.ToString(result).Replace("-", "");
            Console.WriteLine(BitConverter.ToString(result).Replace("-", ""));

            byte[] data2 = result;
            tripleDES.Key = key;
            tripleDES.IV = new byte[tripleDES.BlockSize / 8];
            var decryptor = tripleDES.CreateDecryptor();
            byte[] result2 = new byte[data2.Length];
            result2 = decryptor.TransformFinalBlock(data2, 0, data2.Length);
            Console.WriteLine(Encoding.UTF8.GetString(result2));
            return "";
        }

        public static string Bin2Hex(byte[] bin)
        {
            StringBuilder sb = new StringBuilder(bin.Length * 2);
            foreach (byte b in bin)
            {
                sb.Append(b.ToString("x").PadLeft(2, '0'));
            }
            return sb.ToString();
        }


        public static string DESDecrypt(string encodedText, string key)
        {
            TripleDESCryptoServiceProvider desCrytoProvider = new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider hashMD5Provider = new MD5CryptoServiceProvider();

            byte[] byteHash;
            byte[] byteBuff;

            var bytes = Encoding.UTF8.GetBytes(key);

            byteHash = hashMD5Provider.ComputeHash(bytes);
            desCrytoProvider.Key = byteHash;
            desCrytoProvider.Mode = CipherMode.ECB;
            desCrytoProvider.Padding = PaddingMode.Zeros;
            byteBuff = Convert.FromBase64String(encodedText);

            string plaintext = Encoding.UTF8.GetString(desCrytoProvider.CreateDecryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
            return plaintext;
        }

        private static TripleDES CreateDes(string key)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            TripleDES des = new TripleDESCryptoServiceProvider();
            var desKey = md5.ComputeHash(Encoding.UTF8.GetBytes(key));
            des.Key = desKey;
            des.IV = new byte[des.BlockSize / 8];
            des.Padding = PaddingMode.PKCS7;
            des.Mode = CipherMode.ECB;
            return des;
        }
    }
}
