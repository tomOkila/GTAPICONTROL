﻿using DBL.Consts;
using DBL.Entities;
using DBL.Enums;
using DBL.Gateways;
using DBL.Models;
using DBL.UOW;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;
using System.Xml.Linq;
using static DBL.Gateways.MetropolGateway;

namespace DBL
{
    public class Bl
    {
        private string dbConnString;
        public string Logfile;
        private UnitOfWork db;
        public Bl(string dbconn,string logfile)
        {
            this.dbConnString = dbconn;
            this.Logfile = logfile;
            if (!string.IsNullOrEmpty(dbconn))
                db = new UnitOfWork(dbconn);
        }

       


        #region PesaLink
        public async Task<string> GetAuthData(string xml)
        {
            PesaLinkGateway pesaLink = null;

            XDocument Xml = XDocument.Parse(xml);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "IdVrfctnReq").FirstOrDefault();
            if(myData != null)
            {
                
                AuthData model = new AuthData
                {
                    DestinationId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FrstAgt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    MsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                    SenderId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgnr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    ReceiverId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Assgne").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Agt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    VerifyId = (string)myData.Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    Date = (string)myData.Descendants().Where(x => x.Name.LocalName == "Assgnmt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CreDtTm").FirstOrDefault(),
                    AccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "Vrfctn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PtyAndAcctId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Acct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault()
                };

                var result =await db.PesaLinkRepository.CheckDetails(model,0);
                db.Reset();
                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
                var request = await pesaLink.ReturnAuthResponse(result, model);
                return "";
            }
            return "";
        }

       

        public async Task<string> VerifyConnection(string xml)
        {
            PesaLinkGateway pesaLink = null;

            XDocument Xml = XDocument.Parse(xml);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "SysEvtNtfctn").FirstOrDefault();
            if (myData != null)
            {
                string request = (string)myData.Descendants().Where(x => x.Name.LocalName == "EvtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EvtCd").FirstOrDefault();
                if(request == "PING")
                {
                    var model = new AuthData();
                    var result = await db.PesaLinkRepository.CheckDetails(model, 1);
                    db.Reset();
                    pesaLink = new PesaLinkGateway(result.Data1,result.Data2,result.Data3);
                    var req = await pesaLink.ReturnVerification();
                    return req;
                }
                else if (request== "DCON")
                {
                    var model = new AuthData();
                    model.SenderId= (string)myData.Descendants().Where(x => x.Name.LocalName == "EvtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EvtParam").FirstOrDefault();
                    var result = await db.PesaLinkRepository.CheckDetails(model, 2);
                    db.Reset();
                    return "";
                }
                else if (request == "AVLB")
                {
                    var model = new AuthData();
                    model.SenderId = (string)myData.Descendants().Where(x => x.Name.LocalName == "EvtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EvtParam").FirstOrDefault();
                    var result = await db.PesaLinkRepository.CheckDetails(model, 3);
                    db.Reset();
                    return "";
                }
            }
            return "";
        }

        public async Task<string> UpdatePayment(string xml)
        {
            XDocument Xml = XDocument.Parse(xml);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "FIToFIPmtStsRpt").FirstOrDefault();
            if (myData != null)
            {
                string response = "";
                string respMsg = "";
                string MsgId = "";
                
                var datas = myData.Descendants().Where(x => x.Name.LocalName == "TxInfAndSts").ToList();

                foreach (var data in datas)
                {
                    response = (string)data.Descendants().Where(x => x.Name.LocalName == "TxSts").FirstOrDefault();
                    if (response == "RJCT")
                    {
                        respMsg = (string)data.Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault()+
                            (string)data.Descendants().Where(x => x.Name.LocalName == "StsRsnInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault();
                    }
                    MsgId = (string)data.Descendants().Where(x => x.Name.LocalName == "OrgnlEndToEndId").FirstOrDefault();

                    PayResponse model = new PayResponse
                    {
                        MsgId = MsgId,
                        Response = response,
                        Msg = respMsg
                    };
                    var update = db.PesaLinkRepository.UpdateOutTransactions(model);
                }
            }
            return "";
        }


        public async Task<string> MessageRejection(string xml)
        {
            XDocument Xml = XDocument.Parse(xml);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "Rsn").FirstOrDefault();
            if (myData != null)
            {
                string response = "";
                string respMsg = "";
                string MsgId = "";

                response = (string)myData.Descendants().Where(x => x.Name.LocalName == "RjctgPtyRsn").FirstOrDefault();

                string Data = (string)Xml.Descendants().Where(x => x.Name.LocalName == "AddtlData").FirstOrDefault();

                Data = Data.Replace("\n", "");

                Xml = XDocument.Parse(Data);

                MsgId = (string)Xml.Descendants().Where(x => x.Name.LocalName == "OrgnlEndToEndId").FirstOrDefault();


                PayResponse model = new PayResponse
                {
                    MsgId = MsgId,
                    Response = response,
                    Msg = respMsg
                };
                var update = db.PesaLinkRepository.UpdateOutTransactions(model);
               
            }
            return "";
        }


        public async Task<List<UserBanksData>> LookUpCustomer(Register model)
        {
            PesaLinkGateway pesaLink = null;
            var data = new AuthData();
            var result = await db.PesaLinkRepository.CheckDetails(data, 7);
            db.Reset();
            pesaLink = new PesaLinkGateway(result.Data3, result.Data2, result.Data3);
            var register = await pesaLink.CustomerLookUp(model, result);
            
            return register;
        }

        public async Task<RegisterResponse> RegisterCustomer(Register model)
        {
            PesaLinkGateway pesaLink = null;
            var result = await db.PesaLinkRepository.RegisterCustomer(model);
            db.Reset();

            if (result.RespStat == 0)
            {
                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
                var register = await pesaLink.RegisterCustomer(model, result);
                if (register.Status == 0)
                {
                   var response= db.PesaLinkRepository.UpdateCustomerStatus(model, register);
                }
                return register;
            }
            return new RegisterResponse
            {
                Status=result.RespStat,
                Message=result.RespMsg
            };

        }

        public async Task<PaymentRespose> PayOut(PaymentRequest model)
        {
            PaymentRespose respose = new PaymentRespose();
            try
            {
                PesaLinkGateway pesaLink = null;


                DataTable dt = new DataTable();
                dt.Columns.Add("Beneficiary");
                dt.Columns.Add("Currency");
                dt.Columns.Add("Amount", typeof(decimal));
                dt.Columns.Add("DrAccount");
                dt.Columns.Add("DrAccountName");
                dt.Columns.Add("CrAccount");
                dt.Columns.Add("CrAccountPhone");
                dt.Columns.Add("CrAccountName");
                dt.Columns.Add("Narration");
                dt.Columns.Add("Purpose");
                dt.Columns.Add("UniqueRef");
                dt.Columns.Add("Phone");
                dt.Columns.Add("TransID");

                string MainRef = Guid.NewGuid().ToString("N");
                foreach (var item in model.Transactions)
                {
                    dt.Rows.Add(item.BeneficiaryId, item.CurrencyCode, item.Amount, item.DrAccNo, item.DrAccName, item.CrAccNo, item.CrAccPhone, item.CrName, item.Narration, item.Purpose, Guid.NewGuid().ToString("N"), item.DrAccPhone,item.TransactionID);
                }
                var result = await db.PesaLinkRepository.PayOut(model, dt, MainRef);
                db.Reset();
                if (result.RespStat == 0)
                {
                    string[] msgId = result.Data7.Split('|');
                    msgId = msgId.Take(msgId.Count() - 1).ToArray();
                    dt.Columns.Add("TranRef");

                    for (int count = 0; count < dt.Rows.Count; count++)
                    {
                        dt.Rows[count]["TranRef"] = msgId[count];
                    }
                    pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                    var request = await pesaLink.PayOutwards(model, dt, result, MainRef);
                    return request;
                }
                return new PaymentRespose
                {
                    Status = result.RespStat,
                    Message = result.RespMsg
                };
            }
            catch(Exception ex)
            {
                return new PaymentRespose
                {
                    Status = 1,
                    Message = "An Error Occurred"
                };
            }
        }

        public async Task<string> Unavailable(Unavailable mod)
        {
            PesaLinkGateway pesaLink = null;
            var model = new AuthData();
            var result = await db.PesaLinkRepository.CheckDetails(model, 1);
            db.Reset();
            pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
            var req = await pesaLink.Unavailable(mod);
            return req;
        }

        public async Task<string> PayIN(string xml)
        {
            PesaLinkGateway pesaLink = null;
            XDocument Xml = XDocument.Parse(xml);
            string request;
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "Document").FirstOrDefault();
            //while (true)
            //{
            //    var empties = myData.Descendants().Where(x => x.IsEmpty && !x.HasAttributes).ToList();
            //    if (empties.Count == 0)
            //        break;

            //    empties.ForEach(e => e.ReplaceWith("<Cdtr><Nm></Nm><CtctDtls><PhneNb></PhneNb></CtctDtls></Cdtr>"));
            //}

            //xml = HttpUtility.HtmlDecode(myData.ToString());
            Xml = XDocument.Parse(myData.ToString());
             myData = Xml.Descendants().Where(x => x.Name.LocalName == "FIToFICstmrCdtTrf").FirstOrDefault();
            if (myData != null)
            {
                string response = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EndToEndId").FirstOrDefault();

                string pac = (string)Xml.Descendants().Where(x => x.Name.LocalName == "Document").FirstOrDefault().Attribute("xmlns");
                string[] pacs = pac.Split(':');


                PaymentAccpetance model = new PaymentAccpetance
                {
                    MsgId = Guid.NewGuid().ToString("N"),
                    MsgType = pacs[7].Substring(0, 8),
                    AccMsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                    OrgEndToEnd = response,
                    AccDate = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CreDtTm").FirstOrDefault(),
                    SenderId = response.Substring(4, 4),
                    Currency = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "IntrBkSttlmAmt").FirstOrDefault().Attribute("Ccy"),
                    Amount = (decimal)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "IntrBkSttlmAmt").FirstOrDefault(),
                    ReceiverId = response.Substring(0, 4),
                    SettlMd = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmMtd").FirstOrDefault(),
                    SettlPrt = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "ClrSys").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    TxnType = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SvcLvl").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    LclInst = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "LclInstrm").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault(),
                    Channel = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtgyPurp").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    ManDates = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EndToEndId").FirstOrDefault(),
                    Narration =  HttpUtility.HtmlDecode((string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "RmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Ustrd").FirstOrDefault()),
                    Purpose = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Purp").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    DebCBSName = HttpUtility.HtmlDecode((string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Dbtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault()),
                    DebCBSPhone = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Dbtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtctDtls").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PhneNb").FirstOrDefault(),
                    DebAccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "DbtrAcct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    DebAccAgt = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "DbtrAgt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrAccAgt = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CdtrAgt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrAccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CdtrAcct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrCBSName = "",// HttpUtility.HtmlDecode((string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cdtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault()),
                    CrCBSPhone = ""// (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cdtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtctDtls").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PhneNb").FirstOrDefault(),
                };

                DataTable dt = new DataTable();
                dt.Columns.Add("Beneficiary");
                dt.Columns.Add("Currency");
                dt.Columns.Add("Amount", typeof(decimal));
                dt.Columns.Add("DrAccount");
                dt.Columns.Add("DrAccountName");
                dt.Columns.Add("CrAccount");
                dt.Columns.Add("CrAccountPhone");
                dt.Columns.Add("CrAccountName");
                dt.Columns.Add("Narration");
                dt.Columns.Add("Purpose");
                dt.Columns.Add("UniqueRef");
                dt.Columns.Add("Phone");

                string MainRef = model.MsgId;
                dt.Rows.Add(model.ReceiverId, model.Currency, model.Amount, model.DebAccNo, model.DebCBSName, model.CrAccNo, model.CrCBSPhone, model.CrCBSName, model.Narration, model.Purpose, Guid.NewGuid().ToString("N"), model.DebCBSPhone);
                

                var result = await db.PesaLinkRepository.PostIn(model,dt, MainRef);
                db.Reset();
                if (result.RespStat == 0)
                {
                    var res = await db.PesaLinkRepository.GetOldAccount(model, 0);
                    db.Reset();
                    if (res.RespStat == 0)
                    {
                    //    char[] delim = new char[] { '/' };
                    //    string[] tempstr = res.Data1.Split(delim);
                    //    string AccNo = tempstr[0].PadLeft(4, '0') + tempstr[1].PadLeft(7, '0') + tempstr[2].PadLeft(3, '0') + tempstr[3].PadLeft(4, '0') + tempstr[4].PadLeft(3, '0');
                    //    var post = await db.PesaLinkRepository.PostToBasis(result.Data2, AccNo, Convert.ToDouble(model.Amount), 988, model.Narration, "", res.Data2);

                      

                        var resu = await db.PesaLinkRepository.UpdateTransaction(model.MsgId, model.CrAccNo, model.Amount, res.Data9);

                        pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                        resu.Data6 = res.Data6;
                        resu.Data7 = res.Data7;

                        request = await pesaLink.PayINwards(model, resu);
                        return request;
                    }
                    pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
                    res.Data6 = model.MsgId;
                    request = await pesaLink.PayINwards(model, res);
                    return request;

                }


                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                request = await pesaLink.PayINwards(model, result);
                return request;

            }
            return null;
        }

        public async Task<ApiResponseModel> ValidateCustomer(AuthData model)
        {
            PesaLinkGateway pesaLink = null;

            var result = await db.PesaLinkRepository.ValidateCustomer(model,1);
            db.Reset();
            if (result.RespStat == 0)
            {
                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                var request = await pesaLink.ValidateCustomer(model);

                if(request.Success == true)
                {
                    return new ApiResponseModel
                    {
                        Status = 0,
                        Message = "",
                        Data = request.AccName
                    };
                }
                else
                {
                    return new ApiResponseModel
                    {
                        Status = 1
                    };
                }
            }
            else
            {
                return new ApiResponseModel
                {
                    Status = result.RespStat,
                    Message = result.RespMsg
                };
            }
           
        }

        public async Task<ApiResponseModel> ValidateBulkCustomer(List<AuthData> data)
        {
            PesaLinkGateway pesaLink = null;
            List<AuthResponse> response = new List<AuthResponse>();
            AuthResponse res = new AuthResponse();
            foreach (var item in data)
            {
                var result = await db.PesaLinkRepository.ValidateCustomer(item, 1);
                db.Reset();
                if (result.RespStat == 0)
                {
                    pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                    var request = await pesaLink.ValidateCustomer(item);

                    res = new AuthResponse
                    {
                        AccName=request.AccName,
                        Success=request.Success,
                        VerifyId=item.VerifyId,
                        Status=result.RespStat
                    };
                }
                else
                {
                    res = new AuthResponse
                    {
                        AccName = "",
                        Success = true,
                        VerifyId = item.VerifyId,
                        Status = result.RespStat
                    };
                }

                response.Add(res);
            }
            return new ApiResponseModel
            {
                Status = 0,
                Message = "",
                Data = response
            };
        }

        public async Task<string> TransactionLookUp()
        {
            PesaLinkGateway pesaLink = null;
            var model = new AuthData();
            var result = await db.PesaLinkRepository.CheckDetails(model, 1);
            db.Reset();
           
            List<PaymentLookUp> look = new List<PaymentLookUp>();
            look = await db.PesaLinkRepository.GetPending();
            db.Reset();
            foreach (var item in look)
            {
                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
                var req = await pesaLink.TransactionQuery(result, item);
            }
            
            return "";
        }


        public async Task<string> PayFor(string xml)
        {
            PesaLinkGateway pesaLink = null;
            XDocument Xml = XDocument.Parse(xml);
            string request;
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "Document").FirstOrDefault();
            while (true)
            {
                var empties = myData.Descendants().Where(x => x.IsEmpty && !x.HasAttributes).ToList();
                if (empties.Count == 0)
                    break;

                empties.ForEach(e => e.ReplaceWith("<Cdtr><Nm></Nm><CtctDtls><PhneNb></PhneNb></CtctDtls></Cdtr>"));
            }

            xml = HttpUtility.HtmlDecode(myData.ToString());
            Xml = XDocument.Parse(xml);
            myData = Xml.Descendants().Where(x => x.Name.LocalName == "CstmrCdtTrfInitn").FirstOrDefault();
            if (myData != null)
            {
                string response = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EndToEndId").FirstOrDefault();

                string pac = (string)Xml.Descendants().Where(x => x.Name.LocalName == "Document").FirstOrDefault().Attribute("xmlns");
                string[] pacs = pac.Split(':');

                string CrAccPhone = "";
                string CrAccName = "";
               
                  CrAccPhone = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cdtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtctDtls").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PhneNb").FirstOrDefault();
                  CrAccName = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cdtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault();
                

                PaymentInst model = new PaymentInst
                {
                    SenderDate= (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CreDtTm").FirstOrDefault(),
                    MsgId = Guid.NewGuid().ToString("N"),
                    MsgType = pacs[7].Substring(0, 8),
                    AccMsgId = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "MsgId").FirstOrDefault(),
                    OrgEndToEnd = response,
                    AccDate = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "ReqdExctnDt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "DtTm").FirstOrDefault(),
                    SenderId = response.Substring(4, 4),
                    Currency = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Amt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "InstdAmt").FirstOrDefault().Attribute("Ccy"),
                    Amount = (decimal)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Amt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "InstdAmt").FirstOrDefault(),
                    ReceiverId = response.Substring(0, 4),
                    //SettlMd = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmMtd").FirstOrDefault(),
                    //SettlPrt = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SttlmInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "ClrSys").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    TxnType = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "SvcLvl").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    LclInst = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "LclInstrm").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Cd").FirstOrDefault(),
                    Channel = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtTpInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtgyPurp").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    ManDates = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PmtId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "EndToEndId").FirstOrDefault(),
                    Purpose = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Purp").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Prtry").FirstOrDefault(),
                    Narration = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "RmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Ustrd").FirstOrDefault(),
                    DebCBSName = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Dbtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Nm").FirstOrDefault(),
                    DebCBSPhone = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Dbtr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CtctDtls").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "PhneNb").FirstOrDefault(),
                    DebAccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "PmtInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "DbtrAcct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    InstgAgt = (string)myData.Descendants().Where(x => x.Name.LocalName == "GrpHdr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "InitgPty").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "OrgId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrAccAgt = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CdtrAgt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrAccNo = (string)myData.Descendants().Where(x => x.Name.LocalName == "CdtTrfTxInf").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "CdtrAcct").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                    CrAccPhone = CrAccPhone,
                    CrAccName = CrAccName,
                    DrAccAgt = (string)myData.Descendants().Where(x => x.Name.LocalName == "DbtrAgt").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "FinInstnId").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Othr").FirstOrDefault().Descendants().Where(x => x.Name.LocalName == "Id").FirstOrDefault(),
                };

                var result = await db.PesaLinkRepository.PostInstruct(model);
                db.Reset();
                if (result.RespStat == 0)
                {
                    PaymentAccpetance mode = new PaymentAccpetance
                    {
                        SenderId=model.SenderId,
                        ReceiverId=model.DrAccAgt,
                        MsgId=model.MsgId,
                        CrAccNo=model.DebAccNo
                    };
                    var res = await db.PesaLinkRepository.GetOldAccount(mode, 0);
                    if (res.RespStat == 0)
                    {
                        var res2 = await db.CBSRepository.GetBalance(model.CrAccNo);
                        db.Reset();
                        if (Convert.ToDecimal(res2.Data4) < model.Amount)
                        {
                            res.Data9 = "BAL";
                        }
                        var resu = await db.PesaLinkRepository.UpdateTransaction(model.MsgId, model.CrAccNo, model.Amount, res.Data9);
                        db.Reset();
                        if (!string.IsNullOrEmpty(resu.RespMsg))
                        {
                            pesaLink = new PesaLinkGateway(resu.Data1, resu.Data2, resu.Data3);

                            resu.Data6 = res.Data6;
                            resu.Data7 = res.Data7;

                            request = await pesaLink.PayForRjct(model, resu);
                        }
                        else
                        {
                            pesaLink = new PesaLinkGateway(resu.Data1, resu.Data2, resu.Data3);

                            resu.Data6 = res.Data6;
                            resu.Data7 = res.Data7;

                            request = await pesaLink.PayForAcc(model, resu);
                        }

                        
                        return request;
                    }
                    pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);
                    res.Data6 = model.MsgId;
                    request = await pesaLink.PayForRjct(model,res);
                    return request;

                }


                pesaLink = new PesaLinkGateway(result.Data1, result.Data2, result.Data3);

                request = await pesaLink.PayForRjct(model, result);
                return request;

            }
            return null;
        }
        #endregion

        #region Cards

        public async Task<ApiResponseModel> ProcessCardPayment(ApiRequestModel model)
        {
            var response = new ApiResponseModel();
            switch (model.Action)
            {
                case 10://Balance
                    response = await ProcessCardBalance(model);
                    break;
                //case 20://
                //    response = await ProcessCardPayment(model);
                //    break;
                default://
                    response = new ApiResponseModel
                    {
                        Status = 1,
                        Message = "Service Not Implemeted"
                    };
                    break;
            }
            return response;
        }

        private async Task<ApiResponseModel> ProcessCardBalance(ApiRequestModel model)
        {
            CardGateway card = null;
            GenericModel result = null;
            CardQueryCard cardBalRequest = JsonConvert.DeserializeObject<CardQueryCard>(model.Data.ToString());

            if (cardBalRequest != null)
            {
                result = await db.CardRepository.InitPayment(cardBalRequest);
                db.Reset();

                if (result.RespStat == 0)
                {
                    card = new CardGateway(result.Data1, result.Data2,result.Data3, Logfile);

                    InitResponse request = await card.InitSession(result);

                    if (!string.IsNullOrEmpty(request.NextChallenge))
                    {
                        string password = CrptoUtil.HEXValue(result.Data3).ToUpper();

                        password = CrptoUtil.DESEncrypt(password, password);

                        password = CrptoUtil.DESDecrypt(password, "2020202020202020");

                        password = CrptoUtil.DESEncrypt(password, CrptoUtil.HEXValue(result.Data3));

                        result = new GenericModel
                        {
                            Data1=result.Data2,
                            Data2=request.Session,
                            Data3=password
                        };

                        request = await card.Logon(result);

                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                    }
                    return new ApiResponseModel
                    {
                        Status =1,
                        Message = "An Erro Occurred!"
                    };
                }

            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        #endregion

        #region USSD

        public async Task<USSDResponse> ProcessUSSDRequestAsync(USSDRequest requestData)
        {
            var resp = new USSDResponse { StatusCode = 1 ,DataText ="Service Unavailable at the moment"};

            // JsonConvert.SerializeObject(requestData);


            var callCode = 0;
            var sessionCode = 0;
            var url = "";
            var actionCode = "";
            var callData = "";
            var extraData1 = "";
            var extraData2 = "";
            var failMsg = "";
            var successMsg = "";
            GenericModel callResult = new GenericModel();


            //--- Process request
            var result = await db.USSDRepository.ProcessRequestAsync(requestData);
            db.Reset();

            if (result.RespStat == 0)
            { 
                int action = Convert.ToInt32(result.Data1);
                switch (action)
                {
                    case 0:
                        #region Return menu
                        //--- Return menu
                        //resp.Extra1 = result.Data12;
                        resp.StatusCode = 0;
                        resp.DataText = result.Data2;
                        #endregion
                        break;
                    case 1:
                        #region End session
                        //---- End session
                        resp.StatusCode = 2;
                        resp.DataText = result.Data2;
                        #endregion
                        break;
                    case 10:
                        #region Service call
                        //----- Service call
                        callCode = Convert.ToInt32(result.Data2);
                        sessionCode = Convert.ToInt32(result.Data3);
                        url = result.Data4;
                        actionCode = result.Data5;
                        callData = result.Data6;
                        extraData1 = result.Data7;
                        extraData2 = result.Data8;
                        var extraData3 = result.Data9;
                        failMsg = result.Data10;
                        successMsg = result.Data11;

                        ////--- Make service call
                        callResult = await ServiceCallAsync(url, actionCode, callData, callCode, sessionCode, extraData1, extraData2, extraData3);
                        if (callResult.RespStat == 0)
                        {
                            //--- Process response data
                            // resp.Extra1 = result.Data12;
                            resp.StatusCode = Convert.ToInt32(callResult.Data1);
                            if (string.IsNullOrEmpty(successMsg))
                                resp.DataText = callResult.Data2;
                            else
                                resp.DataText = successMsg;
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(callResult.RespMsg))
                            {
                                resp.StatusCode = 1;
                                resp.DataText = callResult.RespMsg;
                            }
                            else
                            {
                                resp.StatusCode = 2;
                                resp.DataText = failMsg;
                            }

                        }
                        #endregion
                        break;
                    case 4:
                        #region Return menu on first login
                        //--- Return menu
                        //resp.Extra1 = result.Data12;
                        resp.StatusCode = 0;
                        resp.DataText = result.Data2;
                        #endregion
                        break;
                    case 11:
                        #region Transaction Approval
                        callCode = Convert.ToInt32(result.Data2);
                        sessionCode = Convert.ToInt32(result.Data3);
                        url = result.Data4;
                        actionCode = result.Data5;
                        callData = result.Data6;
                        extraData1 = result.Data7;
                        extraData2 = result.Data8;
                        var extraData4 = result.Data9;
                        failMsg = result.Data10;
                        successMsg = result.Data11;

                        ////--- Make service call
                        callResult = await ServiceCallAsync(url, actionCode, callData, callCode, sessionCode, extraData1, extraData2, extraData4);
                        if (callResult.RespStat == 0)
                        {
                            //--- Process response data
                            // resp.Extra1 = result.Data12;
                            resp.StatusCode = Convert.ToInt32(callResult.Data1);
                            if (string.IsNullOrEmpty(successMsg))
                                resp.DataText = callResult.Data2;
                            else
                                resp.DataText = successMsg;
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(callResult.RespMsg))
                            {
                                resp.StatusCode = 1;
                                resp.DataText = callResult.RespMsg;
                            }
                            else
                            {
                                resp.StatusCode = 2;
                                resp.DataText = failMsg;
                            }

                        }
                        #endregion
                        break;
                    default:
                        break;
                }
            }
            else
            {
               // resp.DataText = result.Data12;
                resp.StatusCode = result.RespStat == 2 ? 3 : 1;
                resp.DataText = result.RespMsg;
            }

            return resp;
        }


        private async Task<GenericModel> ServiceCallAsync(string url, string actionCode, string data, int callCode, int sessionCode = 0, string extra1 = "", string extra2 = "", string extra3 = "", GenericModel settings = null)
        {
            int returnStat = 0;
            string returnText = "";
            var postData = "";

            //--- Create headers
            var headers = new Dictionary<string, string>();

            //---- Settings
            string serviceUr = "";
            string serviceUser = "";
            string servicePass = "";
            string requestId = "";
            string userCode = "";
            string serviceName = "";

            if (settings != null)
            {
                serviceUr = settings.Data1;
                serviceUser = settings.Data2 ?? "";
                servicePass = settings.Data3 ?? "";
                requestId = settings.Data4 ?? "";
                userCode = settings.Data5 ?? "";
                serviceName = settings.Data6 ?? "";
            }
            
            //---- Create data
            if (callCode != 106)
            {
                var dataContent = JObject.Parse(data);
                var dataObj = new
                {
                    appid = 1,
                    act = actionCode,
                    data = dataContent
                };
                postData = JsonConvert.SerializeObject(dataObj);
            }
            else
            {
                var dataContent = JObject.Parse(data);
                postData = JsonConvert.SerializeObject(dataContent);
            }
           
            if (callCode != 106)
            {
                //--- Send request to service
                using (var httpClient = new RestApiClient(url, RestApiClient.RequestType.Post, headers))
                {
                    var result = await httpClient.SendRequestAsync(postData);
                    if (result.Success)
                    {
                        var httpResult = JsonConvert.DeserializeObject<ApiResponseModel>(result.Data);
                        if (httpResult.Status == 0)
                        {
                            var extraData = new GenericModel();
                            GenericModel updateResult;

                            switch (callCode)
                            {
                                case 101:
                                    #region Query account balance
                                    var balResult = JsonConvert.DeserializeObject<BalanceRes>(new JObject(httpResult.Data).ToString());

                                    returnText = string.Format(extra1, String.Format("{0:n}", balResult.Amount));
                                    returnStat = 0;
                                    #endregion
                                    break;
                                case 102:
                                    #region Funds transfer
                                    //---- Generate funds transfer response
                                    extraData = new GenericModel { RespStat = 0, RespMsg = "" };
                                    var postResults = JsonConvert.DeserializeObject<PostRes[]>(new JObject(httpResult.Data).ToString());
                                    if (postResults != null)
                                    {
                                        extraData.Data1 = string.Format("{0}|{1}|{2}",
                                            postResults[0].UniqueRef,
                                            postResults[0].CBSRef,
                                            postResults[0].CBSRef);

                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    #endregion
                                    break;
                                case 103:
                                    #region Account mini-statement
                                    //returnText = extra1;
                                    extraData = new GenericModel { RespStat = 0, RespMsg = "" };

                                    updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                    if (updateResult.RespStat == 0)
                                    {
                                        returnText = updateResult.Data1;
                                    }
                                    else
                                    {
                                        return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                    }
                                    #endregion
                                    break;
                                case 104:
                                    #region Query Utility                                
                                    var utilData = JsonConvert.DeserializeObject<ApiResponseData>(new JObject(httpResult.Data).ToString());
                                    if (utilData != null)
                                    {
                                        extraData = new GenericModel();
                                        extraData.Data1 = string.Format("{0}|{1}",
                                            utilData.CusName,
                                            utilData.Amount);

                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    else
                                        return new GenericModel { RespStat = 1 };
                                    #endregion
                                    break;
                                case 105:
                                    #region Pay Utility
                                    var utilPay = JsonConvert.DeserializeObject<ApiResponseData>(new JObject(httpResult.Data).ToString());
                                    if (utilPay != null)
                                    {
                                        extraData = new GenericModel();


                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    else
                                        return new GenericModel { RespStat = 1 };
                                    #endregion
                                    break;
                                case 106:
                                    #region Pesalink Query

                                    var pesalink = JsonConvert.DeserializeObject<ApiResponseModel>(new JObject(httpResult.Data).ToString());
                                    if (pesalink != null)
                                    {
                                        extraData = new GenericModel();
                                        extraData.Data1 = string.Format("{0}",
                                            pesalink.Data);

                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    else
                                        return new GenericModel { RespStat = 1 };
                                    #endregion
                                    break;
                                case 107:
                                    #region Query account balance
                                    var valResult = JsonConvert.DeserializeObject<BalanceRes>(new JObject(httpResult.Data).ToString());
                                    if (valResult != null)
                                    {
                                        extraData = new GenericModel();
                                        extraData.Data1 = string.Format("{0}",
                                            valResult.CusName);

                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    else
                                        return new GenericModel { RespStat = 1 };
                                    #endregion
                                    break;
                                case 108:
                                    #region Query account txn balance
                                    var txnResult = JsonConvert.DeserializeObject<BalanceRes>(new JObject(httpResult.Data).ToString());
                                    if (txnResult != null)
                                    {
                                        extraData = new GenericModel();
                                        extraData.Data1 = string.Format("{0}",txnResult.Amount);
                                        extraData.Data2 = string.Format("{0}", txnResult.AccountStatus);
                                        extraData.Data3 = string.Format("{0}", txnResult.RestrictionStat);

                                        updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                        if (updateResult.RespStat == 0)
                                        {
                                            returnText = updateResult.Data1;
                                        }
                                        else
                                        {
                                            return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                        }
                                    }
                                    else
                                        return new GenericModel { RespStat = 1 };
                                    #endregion
                                    break;
                                default:
                                    break;

                            }
                        }
                        else
                        {
                            if (sessionCode == 0)
                            {

                            }
                            else
                            {
                                return new GenericModel { RespStat = 1, RespMsg = httpResult.Message };
                            }
                        }
                    }
                    else
                    {
                        if (result.Exception != null)
                            AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", result.Exception);

                        string respMsg = "";

                        if (!string.IsNullOrEmpty(result.Exception.Message))
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", result.Exception);
                            respMsg = result.Exception.Message;
                        }
                        else if (!string.IsNullOrEmpty(result.Data))
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", result.Data);
                            respMsg = result.Data;
                        }
                        return new GenericModel { RespStat = 1, RespMsg = respMsg };
                    }
                }
            }
            else
            {
                //--- Send request to service
                HttpConnect httpClient = new HttpConnect(url, HttpConnect.RequestType.Post);
                Exception ex;
                var httpResult = httpClient.SendRequest(postData, out ex);

                if (string.IsNullOrEmpty(httpResult))
                {
                    if (ex != null)
                        AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", ex);

                    string respMsg = "";

                    if (!string.IsNullOrEmpty(ex.Message))
                    {
                        AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", ex);
                        respMsg = ex.Message;
                    }
                    else if (!string.IsNullOrEmpty(httpResult))
                    {
                        AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", httpResult);
                        respMsg = httpResult;
                    }
                    return new GenericModel { RespStat = 1, RespMsg = respMsg };
                }
                else
                {
                    var extraData = new GenericModel();
                    GenericModel updateResult;

                    switch (callCode)
                    {
                        case 101:
                            #region Query account balance
                            var balResult = JsonConvert.DeserializeObject<BalanceRes>(new JObject(httpResult).ToString());

                            returnText = string.Format(extra1, balResult.Amount);
                            returnStat = 2;
                            #endregion
                            break;
                        case 102:
                            #region Funds transfer
                            //---- Generate funds transfer response
                            extraData = new GenericModel { RespStat = 0, RespMsg = "" };
                            var postResults = JsonConvert.DeserializeObject<PostRes[]>(new JObject(httpResult).ToString());
                            if (postResults != null)
                            {
                                extraData.Data1 = string.Format("{0}|{1}|{2}",
                                    postResults[0].UniqueRef,
                                    postResults[0].CBSRef,
                                    postResults[0].CBSRef);

                                updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                if (updateResult.RespStat == 0)
                                {
                                    returnText = updateResult.Data1;
                                }
                                else
                                {
                                    return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                }
                            }
                            #endregion
                            break;
                        case 103:
                            #region Account mini-statement
                            //returnText = extra1;
                            extraData = new GenericModel { RespStat = 0, RespMsg = "" };

                            updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                            if (updateResult.RespStat == 0)
                            {
                                returnText = updateResult.Data1;
                            }
                            else
                            {
                                return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                            }
                            #endregion
                            break;
                        case 104:
                            #region Query Utility                                
                            var utilData = JsonConvert.DeserializeObject<ApiResponseData>(new JObject(httpResult).ToString());
                            if (utilData != null)
                            {
                                extraData = new GenericModel();
                                extraData.Data1 = string.Format("{0}|{1}",
                                    utilData.CusName,
                                    utilData.Amount);

                                updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                if (updateResult.RespStat == 0)
                                {
                                    returnText = updateResult.Data1;
                                }
                                else
                                {
                                    return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                }
                            }
                            else
                                return new GenericModel { RespStat = 1 };
                            #endregion
                            break;
                        case 105:
                            #region Pay Utility


                            var utilPay = JsonConvert.DeserializeObject<ApiResponseData>(new JObject(httpResult).ToString());
                            if (utilPay != null)
                            {
                                extraData = new GenericModel();


                                updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                if (updateResult.RespStat == 0)
                                {
                                    returnText = updateResult.Data1;
                                }
                                else
                                {
                                    return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                }
                            }
                            else
                                return new GenericModel { RespStat = 1 };
                            #endregion
                            break;
                        case 106:
                            #region Pesalink Query

                            var pesalink = JsonConvert.DeserializeObject<PesalinkResModel>(httpResult);
                            if (pesalink != null)
                            {
                                extraData = new GenericModel();
                                extraData.Data1 = string.Format("{0}",
                                    pesalink.Data);

                                updateResult = await db.USSDRepository.UpdateSessionAsync(sessionCode, callCode, extraData);
                                if (updateResult.RespStat == 0)
                                {
                                    returnText = updateResult.Data1;
                                }
                                else
                                {
                                    return new GenericModel { RespStat = 1, RespMsg = updateResult.RespMsg };
                                }
                            }
                            else
                                return new GenericModel { RespStat = 1 };
                            #endregion
                            break;
                        default:
                            break;

                    }
                }
            }
            
            

            return new GenericModel
            {
                RespStat = 0,
                Data1 = returnStat.ToString(),
                Data2 = returnText
            };
        }

        #endregion

        #region Utilities
        public async Task<ApiResponseModel> ProcessUtilityPayment(ApiRequestModel model)
        {
            var response = new ApiResponseModel();
            switch (model.Action)
            {
                case 10://Airtime
                    response = await ProcessAirtime(model);
                    break;
                case 20://Power
                    response = await ProcessPower(model);
                    break;
                case 30://PayTv
                    response = await ProcessPayTV(model);
                    break;
                case 40://Water
                    response = await ProcessWater(model);
                    break;
                case 50://Internet
                    response = await ProcessInternet(model);
                    break;
                case 60://Kasneb
                    response = await ProcessKasneb(model);
                    break;
                case 70://NRB Parking
                    response = await ProcessParking(model);
                    break;
                default://
                    response = new ApiResponseModel
                    {
                        Status = 1,
                        Message = "Service Not Implemeted"
                    };
                    break;
            }
            return response;
        }

        public async Task<UtilitiesCallback> ProcessUtilityCallback(Utilities model)
        {
            var result = await db.UtilityRepository.UpdatePayment(model);
            db.Reset();

            return new UtilitiesCallback
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessKasneb(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payKasnebRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payKasnebRequest != null)
            {
                switch (payKasnebRequest.Presentment)
                {
                    case 0: //purchase
                        payKasnebRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, payKasnebRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payKasnebPurchase = await util.Validation(result.Data5);
                            if (payKasnebPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payKasnebRequest.PayRef, payKasnebPurchase.RespMsg, payKasnebPurchase.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = payKasnebPurchase.RespStat,
                                    Message = payKasnebPurchase.RespMsg
                                };
                            }
                            identier = CrptoUtil.MD5Hash(payKasnebRequest.TransactionRef + payKasnebRequest.AccNo + (Convert.ToDouble(payKasnebRequest.Amount)).ToString() + payKasnebPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payKasnebRequest.PayRef, payKasnebPurchase.RespMsg, payKasnebPurchase.ResponseCode, payKasnebPurchase.ReferenceNo, identier);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data=new ApiResponseData
                                {
                                    CusName=payKasnebPurchase.CusName,
                                    Amount=payKasnebPurchase.Amount
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        result = await db.UtilityRepository.InitPayment(model, payKasnebRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payKasnebLookUp = await util.Purchase(result.Data5);
                            if (payKasnebLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = payKasnebLookUp.RespStat,
                                    Message = payKasnebLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data = new ApiResponseData
                                {
                                    CusName = payKasnebLookUp.CusName,
                                    Amount = payKasnebLookUp.Amount
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessNHIF(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payTvRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payTvRequest != null)
            {
                switch (payTvRequest.Presentment)
                {
                    case 0: //presentment
                        payTvRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, payTvRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payTvPurchase = await util.Validation(result.Data5);
                            if (payTvPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payTvRequest.PayRef, payTvPurchase.RespMsg, payTvPurchase.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = payTvPurchase.RespStat,
                                    Message = payTvPurchase.RespMsg
                                };
                            }
                            identier = CrptoUtil.MD5Hash(payTvRequest.TransactionRef + payTvRequest.AccNo + (Convert.ToDouble(payTvRequest.Amount)).ToString() + payTvPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payTvRequest.PayRef, payTvPurchase.RespMsg, payTvPurchase.ResponseCode, payTvPurchase.ReferenceNo, identier);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        result = await db.UtilityRepository.InitPayment(model, payTvRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payTvLookUp = await util.Purchase(result.Data5);
                            if (payTvLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = payTvLookUp.RespStat,
                                    Message = payTvLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data = new ApiResponseData
                                {
                                    CusName = payTvLookUp.CusName,
                                    Amount = payTvLookUp.Amount
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessInternet(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payInternetRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payInternetRequest != null)
            {
                payInternetRequest.PayRef = Guid.NewGuid().ToString("N");
                result = await db.UtilityRepository.CreatePayment(model, payInternetRequest);
                db.Reset();
                if (result.RespStat == 0)
                {
                    util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                    var payInternetPurchase = await util.Purchase(result.Data5);
                    if (payInternetPurchase.RespStat != 0)
                    {
                        res = await db.UtilityRepository.UpdatePayment(payInternetRequest.PayRef, payInternetPurchase.RespMsg, payInternetPurchase.ResponseCode, "", identier);
                        return new ApiResponseModel
                        {
                            Status = payInternetPurchase.RespStat,
                            Message = payInternetPurchase.RespMsg
                        };
                    }
                    //identier = CrptoUtil.MD5Hash(payInternetPurchase.TransactionID + payInternetRequest.AccNo + (Convert.ToDouble(payInternetRequest.Amount)).ToString() + payInternetPurchase.ReferenceNo);
                    res = await db.UtilityRepository.UpdatePayment(payInternetRequest.PayRef, payInternetPurchase.RespMsg, payInternetPurchase.ResponseCode, payInternetPurchase.ReferenceNo, identier);
                    return new ApiResponseModel
                    {
                        Status = result.RespStat,
                        Message = result.RespMsg
                    };
                }
                res = await db.UtilityRepository.UpdatePayment(payInternetRequest.PayRef, result.RespMsg, "", "", identier);
                return new ApiResponseModel
                {
                    Status = result.RespStat,
                    Message = result.RespMsg
                };
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessParking(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payParkingRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payParkingRequest != null)
            {
                switch (payParkingRequest.Presentment)
                {
                    case 0: //presentment
                        result = await db.UtilityRepository.InitPayment(model, payParkingRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payParkingLookUp = await util.Validation(result.Data5);
                            if (payParkingLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = payParkingLookUp.RespStat,
                                    Message = payParkingLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data = new ApiResponseData
                                {
                                    CusName = payParkingLookUp.CusName,
                                    Amount = payParkingLookUp.Amount
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        payParkingRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, payParkingRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payParkingPurchase = await util.Purchase(result.Data5);
                            if (payParkingPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payParkingRequest.PayRef, payParkingPurchase.RespMsg, payParkingPurchase.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = payParkingPurchase.RespStat,
                                    Message = payParkingPurchase.RespMsg
                                };
                            }
                            // identier = CrptoUtil.MD5Hash(payParkingPurchase.TransactionID + payParkingRequest.AccNo + (Convert.ToDouble(payParkingRequest.Amount)).ToString() + payParkingPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payParkingRequest.PayRef, payParkingPurchase.RespMsg, payParkingPurchase.ResponseCode, payParkingPurchase.ReferenceNo, identier);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessWater(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payWaterRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payWaterRequest != null)
            {
                switch (payWaterRequest.Presentment)
                {
                    case 0: //presentment
                        result = await db.UtilityRepository.InitPayment(model, payWaterRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payWaterLookUp = await util.Validation(result.Data5);
                            if (payWaterLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = payWaterLookUp.RespStat,
                                    Message = payWaterLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data = new ApiResponseData
                                {
                                    CusName = payWaterLookUp.CusName,
                                    Amount = payWaterLookUp.Amount,
                                    DueDate = payWaterLookUp.DueDate
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        payWaterRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, payWaterRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payWaterPurchase = await util.Validation(result.Data5);
                            if (payWaterPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payWaterRequest.PayRef, payWaterPurchase.RespMsg, payWaterPurchase.ResponseCode, "", payWaterPurchase.TransactionID);
                                return new ApiResponseModel
                                {
                                    Status = payWaterPurchase.RespStat,
                                    Message = payWaterPurchase.RespMsg
                                };
                            }
                            //identier = CrptoUtil.MD5Hash(payWaterPurchase.TransactionID + payWaterRequest.AccNo + (Convert.ToDouble(payWaterRequest.Amount)).ToString() + payWaterPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payWaterRequest.PayRef, payWaterPurchase.RespMsg, payWaterPurchase.ResponseCode, "", payWaterPurchase.TransactionID);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 2: //confirm
                        result = await db.UtilityRepository.InitPayment(model, payWaterRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            payWaterRequest.PayRef = result.Data6;
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payWaterConfirm = await util.Purchase(result.Data5);
                            if (payWaterConfirm.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payWaterRequest.PayRef, payWaterConfirm.RespMsg, payWaterConfirm.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = payWaterConfirm.RespStat,
                                    Message = payWaterConfirm.RespMsg
                                };
                            }
                            string receipt = CrptoUtil.MD5Hash(payWaterRequest.TransactionRef + payWaterRequest.AccNo + (Convert.ToDouble(payWaterRequest.Amount)).ToString() + payWaterConfirm.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payWaterRequest.PayRef, payWaterConfirm.RespMsg, payWaterConfirm.ResponseCode, payWaterConfirm.ReferenceNo, receipt);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessPayTV(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var payTvRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if (payTvRequest != null)
            {
                switch (payTvRequest.Presentment)
                {
                    case 0: //presentment
                        result = await db.UtilityRepository.InitPayment(model, payTvRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payTvLookUp = await util.Validation(result.Data5);
                            if (payTvLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = payTvLookUp.RespStat,
                                    Message = payTvLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data = new ApiResponseData
                                {
                                    CusName = payTvLookUp.CusName,
                                    Amount = payTvLookUp.Amount,
                                    DueDate = payTvLookUp.DueDate
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        payTvRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, payTvRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var payTvPurchase = await util.Purchase(result.Data5);
                            if (payTvPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(payTvRequest.PayRef, payTvPurchase.RespMsg, payTvPurchase.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = payTvPurchase.RespStat,
                                    Message = payTvPurchase.RespMsg
                                };
                            }
                            identier = CrptoUtil.MD5Hash(payTvRequest.TransactionRef + payTvRequest.AccNo + (Convert.ToDouble(payTvRequest.Amount)).ToString() + payTvPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(payTvRequest.PayRef, payTvPurchase.RespMsg, payTvPurchase.ResponseCode, payTvPurchase.ReferenceNo, identier);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        private async Task<ApiResponseModel> ProcessPower(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel result = null;
            GenericModel res = null;
            string identier = "";
            var powerRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());

            if(powerRequest != null)
            {
                switch (powerRequest.Presentment)
                {
                    case 0: //presentment
                        result = await db.UtilityRepository.InitPayment(model, powerRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var powerLookUp = await util.Validation(result.Data5);
                            if (powerLookUp.RespStat != 0)
                            {
                                return new ApiResponseModel
                                {
                                    Status = powerLookUp.RespStat,
                                    Message = powerLookUp.RespMsg
                                };
                            }
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg,
                                Data =new ApiResponseData
                                {
                                    CusName=powerLookUp.CusName,
                                    Amount=powerLookUp.Amount,
                                    DueDate=powerLookUp.DueDate
                                }
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                    case 1: //purchase
                        powerRequest.PayRef = Guid.NewGuid().ToString("N");
                        result = await db.UtilityRepository.CreatePayment(model, powerRequest);
                        db.Reset();
                        if (result.RespStat == 0)
                        {
                            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                            var powerPurchase = await util.Purchase(result.Data5);
                            if (powerPurchase.RespStat != 0)
                            {
                                res = await db.UtilityRepository.UpdatePayment(powerRequest.PayRef, powerPurchase.RespMsg, powerPurchase.ResponseCode, "", identier);
                                return new ApiResponseModel
                                {
                                    Status = powerPurchase.RespStat,
                                    Message = powerPurchase.RespMsg
                                };
                            }
                            identier = CrptoUtil.MD5Hash(powerRequest.TransactionRef + powerRequest.AccNo + (Convert.ToDouble(powerRequest.Amount)).ToString() + powerPurchase.ReferenceNo);
                            res = await db.UtilityRepository.UpdatePayment(powerRequest.PayRef, powerPurchase.RespMsg, powerPurchase.ResponseCode, powerPurchase.ReferenceNo, identier);
                            return new ApiResponseModel
                            {
                                Status = result.RespStat,
                                Message = result.RespMsg
                            };
                        }
                        return new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                        break;
                }
            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };

        }

        private async Task<ApiResponseModel> ProcessAirtime(ApiRequestModel model)
        {
            UtilityGateway util = null;
            GenericModel res=null;
            string identier = "";
            var airtimeRequest = JsonConvert.DeserializeObject<UtilityData>(model.Data.ToString());
            airtimeRequest.PayRef = Guid.NewGuid().ToString("N");
            var result = await db.UtilityRepository.CreatePayment(model, airtimeRequest);
            db.Reset();
            if(result.RespStat == 0)
            {
                util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                var airtimePurchase = await util.Purchase(result.Data5);

                if (airtimePurchase.RespStat != 0)
                {
                     res=await db.UtilityRepository.UpdatePayment(airtimeRequest.PayRef, airtimePurchase.RespMsg, airtimePurchase.RespStat.ToString(), "", identier);
                    return new ApiResponseModel
                    {
                        Status = airtimePurchase.RespStat,
                        Message = airtimePurchase.RespMsg
                    };
                }
                identier = CrptoUtil.MD5Hash(airtimeRequest.TransactionRef + airtimeRequest.AccNo + (Convert.ToDouble(airtimeRequest.Amount)).ToString() + airtimePurchase.ReferenceNo);
                res = await db.UtilityRepository.UpdatePayment(airtimeRequest.PayRef, airtimePurchase.RespMsg, airtimePurchase.ResponseCode, airtimePurchase.ReferenceNo, identier);
                return new ApiResponseModel
                {
                    Status = result.RespStat,
                    Message = result.RespMsg
                };

            }
            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        #region Private Methods



        #endregion
        #endregion

        #region CBS


        public async Task<ApiResponseModel> ProcessCBSRequest(ApiRequestModel model)
        {
            var response = new ApiResponseModel();
            switch (model.Action)
            {
                case 10://balance
                    response = await ProcessBalance(model);
                    break;
                case 20:// posttran
                    response = await ProcessTransaction(model);
                    break;
                case 30://alternative  posttran
                    response = await ProcessTrans(model);
                    break;
                case 40://full
                    response = await ProcessStatement(model);
                    break;
                case 50://salary advance
                    response = await ProcessSalaryAdvance(model);
                    break;
                case 60://full
                    response = await ProcessPendingTransactions(model);
                    break;
                case 70://repush transactions
                    response = await ProcessDeadlockTransactions();
                    break;
                default://
                    response = new ApiResponseModel
                    {
                        Status = 1,
                        Message = "Service Not Implemeted"
                    };
                    break;
            }
            return response;
        }

        private async Task<ApiResponseModel> ProcessTransaction(ApiRequestModel model)
        {
            var resp = new ApiResponseModel { Status = 1, Message = "Service Unavailable at the moment" };

            PostTransaction postTxns = null;

            List<CBSRes> postResults = new List<CBSRes>();

            if (model.AppId == 100)
            {
                postTxns = JsonConvert.DeserializeObject<PostTransaction>(model.Data.ToString());
                postTxns.PostTran = await db.CBSRepository.GetGapsTransactions(postTxns.Batch,postTxns.TxnType);
                db.Reset();
            }
            else
            {
                postTxns = JsonConvert.DeserializeObject<PostTransaction>(model.Data.ToString());
            }
           
            //---- Log all transactions
            var txnTable = new DataTable();
            txnTable.Columns.Add("OriginCode", typeof(int));
            txnTable.Columns.Add("Amount", typeof(decimal));
            txnTable.Columns.Add("DrAccount");
            txnTable.Columns.Add("CrAccount");
            txnTable.Columns.Add("TxnCode");
            txnTable.Columns.Add("Narration");
            txnTable.Columns.Add("TxnPriority", typeof(int));
            txnTable.Columns.Add("TxnType", typeof(int));
            txnTable.Columns.Add("Currency", typeof(int));
            txnTable.Columns.Add("ExplCode", typeof(int));


            //---- Put the data in a table
            foreach (var item in postTxns.PostTran)
            {
                var accountdetails = await db.CBSRepository.GetAccountDetails(item.DebitAccount);

                string[] creditAcc = item.CreditAccount.Split('/');

                if (creditAcc.Length == 1)
                {
                    var accdetails = await db.CBSRepository.GetAccountDetails(item.CreditAccount);
                    creditAcc = accdetails.Data3.Split('/');
                }

                string remarks = "";
                string[] customer = null;
                if (!string.IsNullOrEmpty(item.CustAccount))
                {
                    var custacc = await db.CBSRepository.GetAccountDetails(item.CustAccount);
                    remarks = string.Format(item.Narration, custacc.Data2, custacc.Data1);
                }else
                {
                    remarks = string.Format(item.Narration, accountdetails.Data2, accountdetails.Data1);
                }

                if (string.IsNullOrEmpty(accountdetails.Data3))
                {
                    customer = item.DebitAccount.Split('/');
                }
                else
                {
                    customer = accountdetails.Data3.Split('/');
                }
                string debitacc = customer[0].PadLeft(4, '0') + customer[1].PadLeft(7, '0') + customer[2].PadLeft(3, '0') + customer[3].PadLeft(4, '0') + customer[4].PadLeft(3, '0');

                
                string creditacc = creditAcc[0].PadLeft(4, '0') + creditAcc[1].PadLeft(7, '0') + creditAcc[2].PadLeft(3, '0') + creditAcc[3].PadLeft(4, '0') + creditAcc[4].PadLeft(3, '0');

                txnTable.Rows.Add(
                    item.TransactionID,
                    item.Amount,
                    debitacc,
                    creditacc,
                    item.SourceRef,
                    remarks,
                    item.TxnPriority,
                    item.TxnType,
                    item.Currency,
                    item.ExplanationCode
                );
            }

            var logResult = await db.CBSRepository.LogUploadTxnsAync(txnTable,postTxns.CustomerNumber,model.AppId, postTxns);
            db.Reset();

            if (logResult.RespStat == 0)
            {
                //--- Post high priority transactions
                var hp = postTxns.PostTran.Any(x => x.TxnPriority == 1);
                if (hp)
                {
                    //---- Get high priority txns
                    var hpTxns = await db.CBSRepository.GetUploadTxsnAsync(postTxns.Batch, 1);
                    db.Reset();

                    CBSGateway cbsGateway = null;
                    cbsGateway = new CBSGateway(logResult.Data1);


                    //----- Post one by one
                    foreach (var txn in hpTxns)
                    {
                        

                        var txnResult = await cbsGateway.PostTxnAsync(txn);
                        txnResult.TxnCode = txn.TxnCode;
                        txnResult.TransID = txn.TransID;
                        txnResult.BatchCode = txn.BatchCode;
                        postResults.Add(txnResult);
                    }

                    //---- Process results(asynchronously)
                    ProcessUploadResults(postResults, logResult.Data1,model.AppId);

                    //---- Return
                    return new ApiResponseModel
                    {
                        Status = 0,
                        Message = "",
                        Data= postResults
                    };
                }
                else
                {
                  
                    var txnResult = new CBSRes();
                    txnResult.TransID = postTxns.Batch.ToString();
                    txnResult.BatchCode = postTxns.Batch;
                    postResults.Add(txnResult);
                    //---- Process results(asynchronously)
                    ProcessAlternatePostings(postResults, logResult.Data1, model.AppId);
                    return new ApiResponseModel { Status = 0, Message = "" };
                }
                    
            }
            else
            {
                if (logResult.RespStat == 1)
                {
                    resp.Status = logResult.RespStat;
                    resp.Message = logResult.RespMsg;
                }
                else
                    throw new Exception(logResult.RespMsg);
            }
            return resp;
        }

        private async Task<ApiResponseModel> ProcessTrans(ApiRequestModel model)
        {
            List<CBSRes> postResults = new List<CBSRes>();
            var resp = new ApiResponseModel { Status = 1, Message = "Service Unavailable at the moment" };
            PostTransaction postTxns = JsonConvert.DeserializeObject<PostTransaction>(model.Data.ToString());
            //---- Log all transactions
            var txnTable = new DataTable();
            txnTable.Columns.Add("OriginCode", typeof(int));
            txnTable.Columns.Add("Amount", typeof(decimal));
            txnTable.Columns.Add("DrAccount");
            txnTable.Columns.Add("CrAccount");
            txnTable.Columns.Add("TxnCode");
            txnTable.Columns.Add("Narration");
            txnTable.Columns.Add("Currency", typeof(int));
            txnTable.Columns.Add("TxnType", typeof(int));
            txnTable.Columns.Add("TxnPriority", typeof(int));

            //---- Put the data in a table
            foreach (var item in postTxns.PostTran)
            {
                var accountdetails = await db.CBSRepository.GetBalance(item.DebitAccount);
                db.Reset();

                string remarks = string.Format(item.Narration,item.DebitAccount,accountdetails.Data1);

                txnTable.Rows.Add(
                    item.TransactionID,
                    item.Amount,
                    item.DebitAccount,
                    item.CreditAccount,
                    item.SourceRef,
                    remarks,
                    item.Currency,
                    item.TxnType,
                    item.TxnPriority
                );
            }

            var logResult = await db.CBSRepository.LogUploadTxnsAync(txnTable, postTxns.CustomerNumber, model.AppId, postTxns);
            db.Reset();


            if (logResult.RespStat == 0)
            {
                //--- Post high priority transactions
                var hp = postTxns.PostTran.Any(x => x.TxnPriority == 1);
                if (hp)
                {
                    //---- Get high priority txns
                    var hpTxns = await db.CBSRepository.GetUploadTxsnAsync(postTxns.Batch, 1);
                    db.Reset();

                    CBSGateway cbsGateway = null;
                    cbsGateway = new CBSGateway(logResult.Data1);


                    //----- Post one by one
                    foreach (var txn in hpTxns)
                    {
                        var txnResult = await cbsGateway.PostTxnAsync(txn);
                        txnResult.TransID = txn.TransID;
                        txnResult.BatchCode = txn.BatchCode;
                        postResults.Add(txnResult);
                    }

                    //---- Process results(asynchronously)
                    ProcessUploadResults(postResults,logResult.Data1,model.AppId);

                    //---- Return
                    return new ApiResponseModel
                    {
                        Status = 0,
                        Data = postResults
                    };
                }
                else
                   
                return new ApiResponseModel { Status = 0 };
            }
            else
            {
                if (logResult.RespStat == 1)
                {
                    resp.Status = logResult.RespStat;
                    resp.Message = logResult.RespMsg;
                }
                else
                    throw new Exception(logResult.RespMsg);
            }
            return resp;
        }

        private async Task<ApiResponseModel> ProcessDeadlockTransactions()
        {
            List<CBSRes> postResults = new List<CBSRes>();
            var settings = await db.CBSRepository.GetSysSettings();
            db.Reset();

            if (settings.RespStat == 0)
            {
                //---- Process results(asynchronously)
                ProcessDeadlock(postResults, settings.Data1);
                return new ApiResponseModel { Status = 0, Message = "" };
            }
            else
            {
                return new ApiResponseModel { Status = settings.RespStat, Message = settings.RespMsg };
            }
        }

        private async Task<ApiResponseModel> ProcessPendingTransactions(ApiRequestModel model)
        {
            CuttOffTrans postTxns = JsonConvert.DeserializeObject<CuttOffTrans>(model.Data.ToString());
            List<CBSRes> postResults = new List<CBSRes>();
            var settings = await db.CBSRepository.GetSysSettings();
            db.Reset();

            if (settings.RespStat == 0)
            {
                var txnResult = new CBSRes();
                txnResult.TransID = postTxns.TransID.ToString();
                txnResult.BatchCode = postTxns.BatchID;
                postResults.Add(txnResult);
                //---- Process results(asynchronously)
                ProcessCustOffPostings(postResults, settings.Data1, model.AppId);
                return new ApiResponseModel { Status = 0, Message = "" };
            }
            else
            {
                return new ApiResponseModel { Status = settings.RespStat, Message = settings.RespMsg };
            }
        }

        private async void ProcessUploadResults(List<CBSRes> postResults,string cbs,int appID)
        {
            //---- Log all transactions
            DataTable dt = new DataTable();
            dt.Columns.Add("BatchCode");
            dt.Columns.Add("TransID", typeof(string));
            dt.Columns.Add("Status", typeof(int));
            dt.Columns.Add("BankRef");
            dt.Columns.Add("TxnCode");

            //---- Put the data in a table
            foreach (var item in postResults)
            {
                dt.Rows.Add(item.BatchCode, item.TransID,item.Status, item.ResponseCode,item.TxnCode);
            }

            var logResult = await db.CBSRepository.UpdateTransation(dt);
            db.Reset();

            //---- Process transactions(asynchronously)
            //---- ProcessTransactions(postResults);

            //----Process Transaction in case of alternative posting
            ProcessAlternatePostings(postResults,cbs,appID);
        }

        private async void ProcessAlternatePostings(List<CBSRes> postResults,string cbs, int appID)
        {
            foreach (var Txn in postResults)
            {
                //----Get Secondary Transactions
                var hpTxns = await db.CBSRepository.GetUploadTxsnAsync(Txn.BatchCode, 2);


                CBSGateway cbsGateway = null;
                cbsGateway = new CBSGateway(cbs);

                List<CBSRes> results = new List<CBSRes>();

                //----- Post one by one
                foreach (var txn in hpTxns)
                {
                    var txnResult = await cbsGateway.PostTxnAsync(txn);
                    txnResult.TxnCode = txn.TxnCode;
                    txnResult.TransID = txn.TransID;
                    txnResult.BatchCode = txn.BatchCode;
                    results.Add(txnResult);
                }

                //---- Process results(asynchronously)
                ProcessAlterUploadResults(results,appID);

            }
        }


        private async void ProcessCustOffPostings(List<CBSRes> postResults, string cbs, int appID)
        {
            foreach (var Txn in postResults)
            {
                //----Get Secondary Transactions
                var hpTxns = await db.CBSRepository.GetUploadCutOffTxsnAsync(Txn.BatchCode,Txn.TransID, 3);


                CBSGateway cbsGateway = null;
                cbsGateway = new CBSGateway(cbs);

                List<CBSRes> results = new List<CBSRes>();

                //----- Post one by one
                foreach (var txn in hpTxns)
                {
                    var txnResult = await cbsGateway.PostTxnAsync(txn);
                    txnResult.TxnCode = txn.TxnCode;
                    txnResult.TransID = txn.TransID;
                    txnResult.BatchCode = txn.BatchCode;
                    results.Add(txnResult);
                }

                //---- Process results(asynchronously)
                ProcessAlterUploadResults(results, appID);
            }
        }

        private async void ProcessDeadlock(List<CBSRes> postResults, string cbs)
        {
            //----Get Secondary Transactions
            var hpTxns = await db.CBSRepository.GetDeadlockedPosting();


            CBSGateway cbsGateway = null;
            cbsGateway = new CBSGateway(cbs);

            postResults = new List<CBSRes>();

            //----- Post one by one
            foreach (var txn in hpTxns)
            {
                var txnResult = await cbsGateway.PostTxnAsync(txn);
                txnResult.TxnCode = txn.TxnCode;
                txnResult.TransID = txn.TransID;
                txnResult.BatchCode = txn.BatchCode;
                postResults.Add(txnResult);
            }

            //---- Log all transactions
            DataTable dt = new DataTable();
            dt.Columns.Add("BatchCode");
            dt.Columns.Add("TransID", typeof(string));
            dt.Columns.Add("Status", typeof(int));
            dt.Columns.Add("BankRef");
            dt.Columns.Add("TxnCode");

            //---- Put the data in a table
            foreach (var item in postResults)
            {
                dt.Rows.Add(item.BatchCode, item.TransID, item.Status, item.ResponseCode, item.TxnCode);
            }

            var logResult = await db.CBSRepository.UpdateTransation(dt);
            db.Reset();
        }

        private async void ProcessAlterUploadResults(List<CBSRes> postResults, int appID)
        {
            //---- Log all transactions
            DataTable dt = new DataTable();
            dt.Columns.Add("BatchCode");
            dt.Columns.Add("TransID", typeof(string));
            dt.Columns.Add("Status", typeof(int));
            dt.Columns.Add("BankRef");
            dt.Columns.Add("TxnCode");


            //---- Put the data in a table
            foreach (var item in postResults)
            {
                dt.Rows.Add(item.BatchCode, item.TransID, item.Status, item.ResponseCode,item.TxnCode);
            }

            var logResult = await db.CBSRepository.UpdateTransation(dt);
            db.Reset();
            var results = await db.CBSRepository.UpdateChannelTxns(dt, appID);
            db.Reset();
            //var txnResult = new CBSRes();
           // txnResult.TransID = postResults.ElementAt(0).TransID.ToString();
            //txnResult.BatchCode = postResults.ElementAt(0).BatchCode;
            //postResults.Add(txnResult);

            //---- Process transactions(asynchronously)
            //---- ProcessTransactions(postResults);

        }

        private async void ProcessTransactions(List<CBSRes> postResults)
        {
            //---- Log all transactions
            DataTable dt = new DataTable();
            dt.Columns.Add("BatchCode");
            dt.Columns.Add("TransID", typeof(string));
            dt.Columns.Add("Status", typeof(int));
            dt.Columns.Add("Message");

            //---- Put the data in a table
            foreach (var item in postResults)
            {
                var logResult = await db.CBSRepository.GetTransactions(item.BatchCode,item.TransID,item.TxnCode);
                foreach (var txn in logResult)
                {
                    var postTxn = await db.CBSRepository.PostTransactions(txn.AppID, txn.SourceRef,txn.BatchCode,txn.TxnType);
                    db.Reset();

                    dt.Rows.Add(txn.BatchCode, txn.SourceRef, postTxn.RespStat, postTxn.RespMsg);
                }
            }

            var txnResult = await db.CBSRepository.UpdateUtilityTransation(dt);

        }

        public async Task<ApiResponseModel> ProcessBalance(ApiRequestModel model)
        {
            var resp = new ApiResponseModel { Status = 1, Message = "Service Unavailable at the moment" };
            var bal = JsonConvert.DeserializeObject<BalanceReq>(model.Data.ToString());
            string[] creditAcc = bal.AccountNo.Split('/');
            GenericModel accdetails = null;
            if (creditAcc.Length > 1)
            {
                accdetails = await db.CBSRepository.GetAccountDetails(bal.AccountNo);
                bal.AccountNo = accdetails.Data1;
            }
            var result = await db.CBSRepository.GetBalance(bal.AccountNo);
            db.Reset();
            resp = new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg,
                Data = new BalanceRes
                {
                    AccountNo = bal.AccountNo,
                    CusName = result.Data1,
                    PhoneNo = result.Data2,
                    AccountStatus = result.Data3,
                    Amount = Convert.ToDecimal(result.Data4),
                    RestrictionStat = Convert.ToInt32(result.Data5),
                    Location=result.Data6,
                    Limit=Convert.ToDecimal(result.Data7)
                }
            };
            return resp;
        }

        public async Task<ApiResponseModel> ProcessStatement(ApiRequestModel model)
        {
            var resp = new ApiResponseModel { Status = 1, Message = "Service Unavailable at the moment" };
            var result = await db.CBSRepository.GetStatement(model.Data);
            db.Reset();
            return resp;
        }

        public async Task<ApiResponseModel> ProcessSalaryAdvance(ApiRequestModel model)
        {
            var sal = JsonConvert.DeserializeObject<SalaryAdReq>(model.Data.ToString());
            var resp = new ApiResponseModel { Status = 1, Message = "Service Unavailable at the moment" };

            var saladvreq = await db.CBSRepository.LogSalaryAdvReq(model.AppId, sal);
            db.Reset();

            if(saladvreq.RespStat != 0)
            {
                return new ApiResponseModel
                {
                    Status = 1,
                    Message = "You are inelligble for salary advance a"
                };
            }

            var custacc = await db.CBSRepository.GetAccountDetails(sal.AccountNo);
            sal.AccountNo = custacc.Data1;

            var result = await db.CBSRepository.GetBalance(sal.AccountNo);
            db.Reset();

            if (result.RespStat == 0)
            {

                if(!(Convert.ToDecimal(result.Data4) < 1))//check for overdraft
                {
                    result = await db.CBSRepository.AuthenticateAdvance(sal.AccountNo);
                    db.Reset();


                    if (result.RespStat == 0)
                    {

                        if (result.Data1 == "1")
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "Sorry, You have an existing LOAN on this account"
                            };
                        }

                        if (DateTime.Parse(DateTime.ParseExact(result.Data4,"ddMMyyyy", CultureInfo.InvariantCulture).ToString()) < DateTime.Parse(DateTime.ParseExact(result.Data2, "ddMMyyyy", CultureInfo.InvariantCulture).ToString()))
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "Sorry, You have an existing LOAN on this account"
                            };
                        }

                        var res = await db.CBSRepository.GetID(sal.AccountNo);
                        db.Reset();

                        if (res.Data10 != "1")
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "You are inelligble for salary advance at the moment. Please try again later"
                            };
                        }

                        MetropolGateway metropol = null;

                        metropol = new MetropolGateway(res.Data1, res.Data2, res.Data9);

                        var health =await metropol.HealthCheck("");

                        if(health.ApiCode != "E200")
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = health.ApiDesc
                            };
                        }

                        if(Convert.ToDecimal(res.Data6) < Convert.ToDecimal(res.Data7))
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "Unable to complete the process due to insufficient balance"
                            };
                        }

                        string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmss");

                        MetropolScore score = new MetropolScore
                        {
                            Report = 3,
                            IDNo = "880000088",//res.Data5,
                            Type = "001",//res.Data9,
                            Score = false
                        };

                        string json = JsonConvert.SerializeObject(score);

                        string hash = CrptoUtil.MD5Hash(res.Data3+ json + res.Data2+timestamp);

                        metropol = new MetropolGateway(res.Data1, res.Data2, res.Data9);
                        var lookup = await metropol.CRBLookUp(json, hash,timestamp);

                        if (lookup.Success == true)
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "Unable to complete the process. Please retry later"
                            };
                        }

                        if (Convert.ToInt32(lookup.CreditScore) < Convert.ToInt32(res.Data8))
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "You are inelligble for salary advance b"
                            };
                        }
                       

                        string[] amt = result.Data3.Split('|');
                        amt = amt.Take(amt.Count() - 1).ToArray();
                        decimal[] amount = Array.ConvertAll<string, decimal>(amt, Convert.ToDecimal);
                        if (amount.Length < 3)
                        {
                            return new ApiResponseModel
                            {
                                Status = 1,
                                Message = "You are inelligble for salary advance c"
                            };
                        }
                        decimal max=amount.Max();
                        decimal min=amount.Min();
                        decimal advance = 0.00M;
                        decimal varianceSalary = (max - min) / max * 100;

                        if (varianceSalary > 30)
                        {
                            advance = Convert.ToDecimal(0.33) * min;
                        }
                        else
                        {
                            decimal total = 0.00M;
                            for (int index = 0; index < amount.Length; index++)
                            {
                                total += amount[index];
                            }
                            advance = Convert.ToDecimal(0.33) * (total / amount.Length);
                        }

                        advance = Math.Round(advance, 2);

                        if (sal.Amount > advance)
                        {
                            return resp = new ApiResponseModel
                            {
                                Status = 1,
                                Message = "You do not qualify for the amount being requested"
                            };
                        }

                        decimal Commission = Math.Round(sal.Amount * Convert.ToDecimal(6.5) / 100, 2);

                        decimal Excise = Math.Round(Commission * 20 / 100, 2);

                        advance = -1 * sal.Amount;
                        
                        var adv = await db.CBSRepository.GetLeastMonth(custacc.Data3,advance);
                        db.Reset();

                        if(adv.RespStat == 0)
                        {
                            return resp = new ApiResponseModel
                            {
                                Status = 0,
                                Message = "You can now access your advance"
                            };
                        }
                        else
                        {
                            return resp = new ApiResponseModel
                            {
                                Status = 1,
                                Message = "You do not qualify for the advance.Please try again later"
                            };
                        }
                    }
                    else
                    {
                        resp = new ApiResponseModel
                        {
                            Status = result.RespStat,
                            Message = result.RespMsg
                        };
                    }
                }
                else
                {
                    resp = new ApiResponseModel
                    {
                        Status = 1,
                        Message = "You currently have an overdraft"
                    };
                }
            }
            else
            {
                resp = new ApiResponseModel
                {
                    Status = result.RespStat,
                    Message = result.RespMsg
                };
            }
            return resp;
        }

        #endregion

        #region Mpesa
        public async Task<ApiResponseModel> STKPush(GTCollectStk model)
        {
            UtilityGateway util = null;
            STKResponse response = null;
            GenericModel result = await db.MpesaRepository.MakePayment(model);
            db.Reset();
           
            if (result.RespStat == 0)
            {
                util = new UtilityGateway(result.Data1, result.Data2, result.Data3);

                Dictionary<string, string> headers = new Dictionary<string, string>();

                var token = await util.GetToken("", result.Data2, result.Data3);


                headers.Add("Authorization", "Bearer " + token.Token);
                util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                response = await util.PostSTK(result.Data4, headers);

                result = await db.MpesaRepository.UpdateStkPayment(Convert.ToInt32(response.Response), response.Merchant, model.ReferenceNo);
                db.Reset();

                return new ApiResponseModel
                {
                    Status = Convert.ToInt32(response.Response),
                    Message = response.Description
                };
            }

            return new ApiResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }


        public async Task<GenericModel> StkCallbackAsync(MpesaCallBack model)
        {
            UtilityGateway util = null;
            decimal Amount=0.00M; string Receipt=""; string Date=""; string Phone = "";
            if (model.Data.Data.Meta != null)
            {
                 Amount = Convert.ToDecimal(model.Data.Data.Meta.Item.Find(item => item.Name == "Amount").Value);
                 Receipt = model.Data.Data.Meta.Item.Find(item => item.Name == "MpesaReceiptNumber").Value;
            }
            

            var resp = await db.MpesaRepository.UpdatePayment(model.Data.Data.Code, model.Data.Data.Merchant, Amount, Receipt, Date, Phone);
            db.Reset();

            util = new UtilityGateway(resp.Data1, resp.Data2, resp.Data3);
            var request = await util.Callback(resp.Data4);

            return resp;
        }

        public async Task STKLookUp(MpesaLookUp model)
        {
            var resp = await db.MpesaRepository.MpesaLookUp(model.Transref,model.ReferenceNo);
            db.Reset();

          
        }

        public async Task<GenericModel> MpesaCallBack(string xml)
        {

            GenericModel resp = new GenericModel();
            MpesaData mpesa = null;


            XDocument Xml = XDocument.Parse(xml);

            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "ResultMsg").FirstOrDefault();
            if (myData != null)
            {
                string data = myData.ToString();

                data=data.Replace("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");

                data = data.Replace("]]>", "");



                XDocument mData = XDocument.Parse(data);

                var mydata = mData.Descendants().Where(x => x.Name.LocalName == "Result").FirstOrDefault();



                if (mydata != null)
                {
                    string resultcode = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ResultCode").FirstOrDefault();

                    if (resultcode == "0")
                    {
                        var datas = mydata.Descendants().Where(x => x.Name.LocalName == "Value").ToList();

                        mpesa = new MpesaData
                        {
                            ResultCode = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ResultCode").FirstOrDefault(),
                            RespMsg = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ResultDesc").FirstOrDefault(),
                            BrokerId = (string)mydata.Descendants().Where(x => x.Name.LocalName == "OriginatorConversationID").FirstOrDefault(),
                            ConvId = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ConversationID").FirstOrDefault(),
                            Receipt = (string)datas[1].Value,
                            Remarks = (string)datas[2].Value,
                            Date = DateTime.ParseExact(datas[3].Value, "dd.MM.yyyy HH:mm:ss", CultureInfo.InvariantCulture),
                            Float = Convert.ToDecimal(datas[4].Value)
                        };
                    }
                    else
                    {

                        mpesa = new MpesaData
                        {
                            ResultCode = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ResultCode").FirstOrDefault(),
                            RespMsg = (string)mydata.Descendants().Where(x => x.Name.LocalName == "ResultDesc").FirstOrDefault(),
                            BrokerId = (string)mydata.Descendants().Where(x => x.Name.LocalName == "OriginatorConversationID").FirstOrDefault(),
                            Receipt = (string)mydata.Descendants().Where(x => x.Name.LocalName == "TransactionID").FirstOrDefault(),
                            Date = DateTime.Now
                        };
                    }
                   

                    resp =await  db.MpesaRepository.MpesaB2CUpdate(mpesa);
                    db.Reset();
                }
            }
            return resp;
        }

        public async  Task<GenericModel> MpesaB2BCallBack(string xml)
        {
            GenericModel resp = new GenericModel();

            MpesaData mpesa = null;

            XDocument Xml = XDocument.Parse(xml);
            var myData = Xml.Descendants().Where(x => x.Name.LocalName == "ResultMsg").FirstOrDefault();
            if (myData != null)
            {
                string data = myData.ToString();

                data = data.Replace("<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");

                data = data.Replace("]]>", "");

                XDocument mData = XDocument.Parse(data);

                var mydata = mData.Descendants().Where(x => x.Name.LocalName == "Result").FirstOrDefault();

                var datas = myData.Descendants().Where(x => x.Name.LocalName == "Value").ToList();

                mpesa = new MpesaData
                {
                    ResultCode = (string)myData.Descendants().Where(x => x.Name.LocalName == "ResultCode").FirstOrDefault(),
                    RespMsg = (string)myData.Descendants().Where(x => x.Name.LocalName == "ResultDesc").FirstOrDefault(),
                    BrokerId = (string)myData.Descendants().Where(x => x.Name.LocalName == "OriginatorConversationID").FirstOrDefault(),
                    ConvId = (string)myData.Descendants().Where(x => x.Name.LocalName == "ConversationID").FirstOrDefault(),
                    Receipt = (string)myData.Descendants().Where(x => x.Name.LocalName == "TransactionID").FirstOrDefault(),
                    Remarks = (string)datas[3].Value,
                    Date = DateTime.Now,
                    Float = 0.00M
                };

                resp = await db.MpesaRepository.MpesaB2BUpdate(mpesa);
                db.Reset();
            }
            return resp;
        }
        #endregion

        #region GAPS

        #region User
        public async Task<UserModel> UserLoginAsync(string userName, string password)
        {
            UserModel userModel = new UserModel { };
            //------ Get User
            var user = await db.SecurityRepository.VerifyAsync(userName,password);
            if (user == null)
            {
                userModel.RespStat = 1;
                userModel.RespMsg = "Invalid Username and/or Password!";
                return userModel;
            }

            //----- Check user status
            if (user.RespStat == 0)
            {
                var respData = await db.SecurityRepository.UserLoginAsync(Convert.ToInt32(user.Data1), 0);
                db.Reset();

                if (respData.RespStat == 0)
                {

                    bool changePass = Convert.ToBoolean(respData.Data3);
                    userModel = new UserModel
                    {
                        FullNames = respData.Data2,
                        UserStatus = UserLoginStatus.Ok,
                        UserCode = Convert.ToInt32(user.Data1)
                    };

                    if (changePass)
                        userModel.UserStatus = UserLoginStatus.ChangePassword;

                    respData = await db.SecurityRepository.UserLoginAsync(Convert.ToInt32(user.Data1), 0);
                    return userModel;
                }
                else
                {
                    respData = await db.SecurityRepository.UserLoginAsync(Convert.ToInt32(user.Data1), 1);
                    userModel.RespStat = 1;
                    userModel.RespMsg = respData.RespMsg;
                }
              
            }
            else
            {
                userModel.RespStat = 1;
                userModel.RespMsg = user.RespMsg;
            }
            return userModel;
        }



        public async Task<BaseEntity> ChangeUserPasswordAsync(ChangeUserPassModel data, int scope)
        {
            //---- Get user
            var passDets = await db.SecurityRepository.GetUserPasswordAsync(data.UserCode,data.OldPassword,data.NewPassword);
            if (passDets.RespStat != 0)
            {
                return new BaseEntity
                {
                    RespStat = passDets.RespStat,
                    RespMsg = passDets.RespMsg
                };
            }

            return new BaseEntity
            {
                RespStat = passDets.RespStat,
                RespMsg = passDets.RespMsg
            };
        }

        public async Task<IEnumerable<SysUserModel>> GetUsersAsync()
        {
            var user = await db.SecurityRepository.GetUsersAsync();
            return user;
        }

        public async Task<SysUserModel> GetUserAsync(int userCode)
        {
            var user = await db.SecurityRepository.GetUserAsync(userCode);
            return user;
        }

        public async Task<BaseEntity> CreateUserAsync(User user, int makerUser)
        {
            //BTSecurity security = new BTSecurity();
            //string salt = security.GenerateSalt(25);
            //string rawPass = AppUtil.GenerateSimplePassword();
            //string password = security.HashPassword(rawPass, salt);

            //user.Salt = salt;
            //user.Pwd = password;

            var result = await db.SecurityRepository.CreateUserAsync(user, makerUser, "");
            db.Reset();

            return new BaseEntity
            {
                RespMsg = result.RespMsg,
                RespStat = result.RespStat
            };
        }

        public async Task<BaseEntity> CreateServiceAsync(UtilService service)
        {
            //---- Validate account
            var paraSet = await db.GeneralRepository.GetParamSetAsync(ParamSetType.CBSAccountUrl, 0);
            if (paraSet.RespStat != 0)
                return new BaseEntity { RespStat = 1, RespMsg = paraSet.RespMsg };

            var url = paraSet.Data1;
            if (string.IsNullOrEmpty(url))
                return new BaseEntity { RespStat = 1, RespMsg = "CBS account url not set!" };

            //var cbsAccount = await QueryCBSAccountAsync(url, service.Extra1);
            //if (cbsAccount.Successful)
            //    return new BaseEntity { RespStat = 1, RespMsg = "Account validation failed!" };
            //if (string.IsNullOrEmpty(cbsAccount.Accountname))
            //    return new BaseEntity { RespStat = 1, RespMsg = "Invalid account!" };

            var result = await db.SecurityRepository.CreateServiceAsync(service);
            db.Reset();

            return new BaseEntity
            {

                RespMsg = result.RespMsg,
                RespStat = result.RespStat
            };
        }

        public async Task<BaseEntity> ResetUserPasswordAsync(int userCode, int maker)
        {
          


            var result = await db.SecurityRepository.ResetUserPasswordAsync(userCode, "", "", maker, "");
            db.Reset();

            if (result.RespStat == 0)
            {
                if (!string.IsNullOrEmpty(result.Data7))
                {
                    //--- Send mail
                    string message = string.Format(result.Data7, "");
                    int port = Convert.ToInt32(result.Data2);
                    //SendMail(result.Data1, port, result.Data3 == "1", result.Data4, result.Data5, result.Data6, result.Data8, message);
                }
            }

            return new BaseEntity
            {
                RespMsg = result.RespMsg,
                RespStat = result.RespStat
            };
        }

        //public async Task<BaseEntity> ResetUserPasswordAsync(string userName)
        //{
        //    //------ Get User
        //    var user = await db.SecurityRepository.VerifyAsync(userName);
        //    if (user == null)
        //    {
        //        return new BaseEntity
        //        {
        //            RespStat = 1,
        //            RespMsg = "Invalid user details!"
        //        };
        //    }

        //    if (user.RespStat != 0)
        //    {
        //        return new BaseEntity
        //        {
        //            RespStat = 1,
        //            RespMsg = user.RespMsg
        //        };
        //    }

        //    return await ResetUserPasswordAsync(Convert.ToInt32(user.Data1), -1);
        //}

        public async Task<BaseEntity> ChangeUserStatusAsync(int userCode, int status, int maker)
        {
            var result = await db.SecurityRepository.ChangeUserStatusAsync(userCode, status, maker);
            db.Reset();

            return new BaseEntity
            {
                RespMsg = result.RespMsg,
                RespStat = result.RespStat
            };
        }



        #endregion

        #region Client
        public async Task<IEnumerable<Client>> GetClientsAsync(string name = "")
        {
            return await db.ClientRepository.GetListAsync(name);
        }

        public async Task<Client> GetClientAsync(int clientCode)
        {
            var client = await db.ClientRepository.GetAsync(clientCode);
            return client;
        }

        public async Task<BaseEntity> CreateClientAsync(Client client)
        {
            //---- Validate account
            //var paraSet = await db.GeneralRepository.GetParamSetAsync(ParamSetType.CBSAccountUrl, 0);
            //if (paraSet.RespStat != 0)
            //    return new BaseEntity { RespStat = 1, RespMsg = paraSet.RespMsg };

            //var url = paraSet.Data1;
            //if (string.IsNullOrEmpty(url))
            //    return new BaseEntity { RespStat = 1, RespMsg = "CBS account url not set!" };

            //var cbsAccount = await db.CBSRepository.GetID(client.AccountNo);
            //if (cbsAccount.RespStat != 0)
            //    return new BaseEntity { RespStat = 1, RespMsg = "Account validation failed!" };


            //client.AccountNo = cbsAccount.Data4;

            //---- Create client

            var app = new ClientApp();
            app.AppKey = Guid.NewGuid().ToString("N");
            app.AppId = Guid.NewGuid().ToString("N");

            var result = await db.ClientRepository.CreateAsync(client, app);
            db.Reset();

            var message = result.RespMsg;
            if (result.RespStat == 0)
            {
                message = "Client created.<br/>APPID:" + app.AppId + "< br/>AppKey:" + app.AppKey;
            }

            return new BaseEntity
            {
                RespMsg = message,
                RespStat = result.RespStat
            };
        }

        public async Task<IEnumerable<ClientApp>> GetClientAppsAsync(int clientCode)
        {
            return await db.ClientRepository.GetAppsAsync(clientCode);
        }

        public async Task<BaseEntity> ChangeClientStatAsync(int clientCode, int stat)
        {
            return await db.ClientRepository.ChangeStatAsync(clientCode, stat);
        }

        public async Task<ClientApp> GetClientAppAsync(int appCode)
        {
            return await db.ClientRepository.GetAppAsync(appCode);
        }

        //public async Task<GenericModel> ResetClientAppAsync(int appCode)
        //{
        //    BTSecurity security = new BTSecurity();
        //    string salt = security.GenerateSalt(25);
        //    string rawPass = security.GenerateSalt(75);
        //    string appKey = security.HashPassword(rawPass, salt);

        //    var result = await db.ClientRepository.ResetAppAsync(appCode, appKey, salt);

        //    var newKey = "";
        //    if (result.RespStat == 0)
        //    {
        //        newKey = rawPass;
        //    }

        //    return new GenericModel
        //    {
        //        RespMsg = result.RespMsg,
        //        RespStat = result.RespStat,
        //        Data1 = newKey
        //    };
        //}

        public async Task<BaseEntity> ChangeAppStatAsync(int appCode, int stat)
        {
            return await db.ClientRepository.ChangeAppStatAsync(appCode, stat);
        }

        #endregion


        #region Service
        public async Task<IEnumerable<UtilService>> GetServicesAsync(string name = "")
        {
            return await db.ServiceRepository.GetListAsync(name);
        }

        public async Task<UtilService> GetServiceAsync(int serviceCode)
        {
            return await db.ServiceRepository.GetAsync(serviceCode);
        }

        public async Task<BaseEntity> ChangeServiceStatAsync(int serviceCode, int stat, string message)
        {
            return await db.ServiceRepository.ChangeStatAsync(serviceCode, stat, message);
        }

        public async Task<byte[]> GetServiceLogoAsync(int serviceCode)
        {
            return await db.ServiceRepository.GetLogoAsync(serviceCode);
        }

        public async Task<BaseEntity> UpdateServiceLogoAsync(int serviceCode, byte[] image)
        {
            return await db.ServiceRepository.UpdateLogoAsync(serviceCode, image);
        }

        #endregion

        public async Task<ApiTokenResult> GenerateApiTokenRequestAsync(string header, string host)
        {
            Encoding encoding = Encoding.GetEncoding("iso-8859-1");

            //--- Get App Id
            string authHeader = encoding.GetString(Convert.FromBase64String(header));
            string appIdLen = authHeader.Substring(0, 3);
            string appId = authHeader.Substring(3, Convert.ToInt32(appIdLen));

            //--- Get and decode signature
            string signature = authHeader.Substring((3 + appId.Length));
            signature = encoding.GetString(Convert.FromBase64String(signature));
            string timestamp = signature.Substring(0, 12);
            string appKey = signature.Substring(12);

            //--- Validate time
            //--- UTC time should not me more than 90 seconds
            var reqTime = DateTime.ParseExact(timestamp, "yyMMddHHmmss", CultureInfo.InvariantCulture);
            var lapsedTime = DateTime.UtcNow - reqTime;

            if (lapsedTime.TotalSeconds > 300 || lapsedTime.TotalSeconds < -300)
            {
                return new ApiTokenResult
                {
                    Successful = false,
                    Message = "Request time mismatch or expired! UTC Time Now " + DateTime.UtcNow.ToString("yyMMddHHmmss") + " Sent Time " + reqTime.ToString("yyMMddHHmmss"),
                    ErrorCode = "15"
                };
            }

            //--- Validate app details
            var verifyResults = await db.SecurityRepository.VerifyAppAsync(appId,appKey);
            if (verifyResults.RespStat == 0)
            {
                int appCode = Convert.ToInt32(verifyResults.Data1);

                string token = Guid.NewGuid().ToString("N");
                var tokenResult = await db.SecurityRepository.GenerateAppTokenAsync(appCode, token);
                if (tokenResult.RespStat == 0)
                {
                    var authToken = AppUtil.GenerateAuthToken(tokenResult.Data1, token);
                    return new ApiTokenResult
                    {
                        Successful = true,
                        AuthToken = authToken,
                        Expiry = tokenResult.Data2
                    };
                }
                else 
                {
                    return new ApiTokenResult
                    {
                        Successful = false,
                        ErrorCode = "18",
                        Message = "Token generation failed!"
                    };
                }
               
            }
            else if (verifyResults.RespStat == 2)
            {
                return new ApiTokenResult
                {
                    Successful = false,
                    ErrorCode = "17",
                    Message = "App authentication failed!"
                };
            }
            else
            {
                return new ApiTokenResult
                {
                    Successful = false,
                    ErrorCode = "16",
                    Message = verifyResults.RespMsg
                };
            }
        }

        public async Task<ApiAuthResult> AuthorizeApiAsync(string header, string serviceId)
        {
            Encoding encoding = Encoding.GetEncoding("iso-8859-1");

            //--- Get raw header
            string authHeader = encoding.GetString(Convert.FromBase64String(header));

            //--- Get token details
            string tokenLen = authHeader.Substring(0, 2);
            string tokenCode = authHeader.Substring(2, Convert.ToInt32(tokenLen));
            string authToken = authHeader.Substring((2 + tokenCode.Length));

            var tokenResult = await db.SecurityRepository.GetAppTokenAsync(Convert.ToInt32(tokenCode), serviceId);
            db.Reset();

            if (tokenResult.RespStat == 0)
            {
                if (tokenResult.Data1.Equals(authToken))
                {
                    return new ApiAuthResult
                    {
                        Successful = true,
                        AppCode = Convert.ToInt32(tokenResult.Data2),
                        ServiceCode = Convert.ToInt32(tokenResult.Data3),
                        TokenCode = Convert.ToInt32(tokenCode),
                        CallLog = tokenResult.Data4 == "1",
                    };
                }
                else
                {
                    return new ApiAuthResult
                    {
                        Successful = false,
                        Message = "Invalid authentication token!",
                        ErrorCode = "22"
                    };
                }
            }
            else
            {
                return new ApiAuthResult
                {
                    Successful = false,
                    Message = tokenResult.RespMsg,
                    ErrorCode = tokenResult.Data1
                };
            }
        }


        public async Task<GAPSApiResponseModel> ApiServiceRequestAsync(GAPSApiRequestModel request)
        {
            var resp = new GAPSApiResponseModel
            {
                RespStat = 1,
                Message = "Request received but was not processed!"
            };

            switch (request.ReservedData.ServiceCode)
            {
                case 10:
                    //--- GAPS
                    return await ProcessGAPSRequestAsync(request);
                case 20:
                    //--- Pesalink
                    return await ProcessPesalinkRequestAsync(request);
                case 30:
                    //---GTPay
                    return await ProcessGTPayRequestAsync(request);
                //case 40:
                //    //---GTPay
                //    return await ProcessMpesaAccountsRequestAsync(request);
            }

            return resp;
        }

        private async Task<GAPSApiResponseModel> ProcessGAPSRequestAsync(GAPSApiRequestModel request)
        {
            var resp = new GAPSApiResponseModel { RespStat = 1, Message = "Request was not handled!" };

            string baseUrl = "";
            string username = "";
            string password = "";
            string payRef = "";
            GAPTransfer transfer = null;
            GAPLookUp lookup = null;
            GenericModel result = null;
            PaymentModel payment = null;
            GenericModel res = null;
            DataTable dt = null;
            BalanceReq bal = null;

            switch (request.Action)
            {
                case GAPS_REQUEST_ACTIONS.GAPS_TRANSFERS:
                    #region GAPS Transfers
                    //---- Get search data
                    transfer = JsonConvert.DeserializeObject<GAPTransfer>(new JObject(request.Content).ToString());

                    if (transfer == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid gaps transfer  data!" };


                    ///validate client app and get account details
                    result = await db.ServiceRepository.InitApiRequestAsync(request.ReservedData.ServiceCode, request.ReservedData.AppCode, request.Action,transfer.AccountNo);
                    db.Reset();

                    if (result.RespStat != 0)
                    {
                        if (result.RespStat == 1)
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().ValidateTransaction", new Exception(result.RespMsg));

                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().ValidateTransaction", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    var balance = await db.CBSRepository.GetBalance(transfer.AccountNo);

                    if (balance.RespStat != 0)
                    {
                        if (balance.RespStat == 1)
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().GetBalance", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().GetBalance", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    if (balance.Data5 == "1")
                    {
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Account has a restriction attached!" };
                    }

                    //---- Create payment
                    payRef = Guid.NewGuid().ToString("N");

                    dt = new DataTable();
                    dt.Columns.Add("Amount", typeof(decimal));
                    dt.Columns.Add("PayDate", typeof(DateTime));
                    dt.Columns.Add("UniqueRef");
                    dt.Columns.Add("Remarks");
                    dt.Columns.Add("BeneName");
                    dt.Columns.Add("BeneCode");
                    dt.Columns.Add("BeneAcc");
                    dt.Columns.Add("BeneBank");

                    foreach (var item in transfer.Transactions)
                    {
                        dt.Rows.Add(item.Amount, item.PaymentDate, item.TranRef, item.Narration, item.CustomerName, item.CustomerCode, item.AccountNo, item.Bank);
                    }

                    payment = new PaymentModel
                    {
                        ServiceCode = request.ReservedData.ServiceCode,
                        AppCode = request.ReservedData.AppCode,
                        ActionCode = request.Action,
                        PaymentRef = payRef,
                        PayType = transfer.PayType,
                        Process = transfer.Process,
                        Currency = transfer.Currency,
                        Balance = Convert.ToDecimal(balance.Data4),
                        CusAcc= transfer.AccountNo,
                        SourceID=request.HeaderData.SourceID
                    };

                    res = await db.ServiceRepository.CreatePaymentAsync(payment, dt);
                    db.Reset();

                    if (res.RespStat != 0)
                    {
                        if (res.RespStat == 1)
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().CreatePayment", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = res.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().CreatePayment", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    var transres= new GAPTransferRes{
                        Reference= res.Data1
                    };

                    return new GAPSApiResponseModel
                    {
                        RespStat = 0,
                        Data = transres
                    };
                        #endregion
                case GAPS_REQUEST_ACTIONS.GAPS_LOOKUP:
                    #region GAPS LookUp
                    lookup = JsonConvert.DeserializeObject<GAPLookUp>(new JObject(request.Content).ToString());

                    if (lookup == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid gaps query data!" };

                    //---- Get db data
                    result = await db.ServiceRepository.InitApiRequestAsync(request.ReservedData.ServiceCode, request.ReservedData.AppCode, request.Action, lookup.BatchID.ToString(), lookup.TransID.ToString());
                    db.Reset();

                    if (result.RespStat != 0)
                        return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };


                    return new GAPSApiResponseModel
                    {
                        RespStat = 0
                    };
                #endregion
                case GAPS_REQUEST_ACTIONS.GAPS_ACCOUNT:
                    #region GAPS Balance
                    //---- Get search data
                    bal = JsonConvert.DeserializeObject<BalanceReq>(new JObject(request.Content).ToString());

                    if (bal == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid account data!" };


                    result = await db.CBSRepository.GetBalance(bal.AccountNo);
                    db.Reset();
                    resp = new GAPSApiResponseModel
                    {
                        RespStat = result.RespStat,
                        Message = result.RespMsg,
                        Data = new BalanceRes
                        {
                            AccountNo = bal.AccountNo,
                            CusName = result.Data1,
                            PhoneNo = "+254" + result.Data2,
                            AccountStatus = result.Data3,
                            Amount = Convert.ToDecimal(result.Data4)
                        }
                    };
                    return resp;
                #endregion
                case GAPS_REQUEST_ACTIONS.PSLNK_LOOKUP:
                    #region Account Look UP
                    bal = JsonConvert.DeserializeObject<BalanceReq>(new JObject(request.Content).ToString());

                    if (bal == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid account data!" };


                    var settings = await db.CBSRepository.GetSysSettings();
                    db.Reset();

                    if (settings.RespStat != 0)
                    {
                        if (settings.RespStat == 1)
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().Pesalink", new Exception(settings.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessGAPSRequestAsync().Pesalink", new Exception(settings.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    var headers = new Dictionary<string, string>();

                    using (var httpClient = new RestApiClient(result.Data7, RestApiClient.RequestType.Post, headers))
                    {
                        var response = await httpClient.SendRequestAsync(result.Data8);
                        if (response.Success)
                        {
                            var httpResult = JsonConvert.DeserializeObject<ApiResponseModel>(response.Data);
                            if (httpResult.Status == 0)
                            {
                                var extraData = new GenericModel();
                                var balResult = JsonConvert.DeserializeObject<BalanceRes>(new JObject(httpResult.Data).ToString());
                            }
                            else
                            {
                                //if (sessionCode == 0)
                                //{

                                //}
                                //else
                                //{
                                //    return new GenericModel { RespStat = 1, RespMsg = httpResult.Message };
                                //}
                            }
                        }
                        else
                        {
                            if (response.Exception != null)
                                AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", response.Exception);

                            string respMsg = "";

                            if (!string.IsNullOrEmpty(response.Exception.Message))
                            {
                                AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", response.Exception);
                                respMsg = response.Exception.Message;
                            }
                            else if (!string.IsNullOrEmpty(response.Data))
                            {
                                AppUtil.Log.Error(Logfile, "Bl.ServiceCallAsync()", response.Data);
                                //respMsg = result.Data;
                            }
                            //return new GenericModel { RespStat = 1, RespMsg = respMsg };
                        }
                    }
                    return resp;
                    #endregion
            }

            return resp;
        }

        private async Task<GAPSApiResponseModel> ProcessPesalinkRequestAsync(GAPSApiRequestModel request)
        {
            var resp = new GAPSApiResponseModel { RespStat = 1, Message = "Request was not handled!" };

            string baseUrl = "";
            string username = "";
            string password = "";
            string payRef = "";
            PesalinkTransfer transfer = null;
            GAPLookUp lookup = null;
            PesalinkCusLookUp cusLookUp = null;
            GenericModel result = null;
            PaymentModel payment = null;
            GenericModel res = null;
            DataTable dt = null;
            BalanceReq bal = null;
            PesalinkCusLookUpData cusData = null;

            switch (request.Action)
            {
                case PSLNK_REQUEST_ACTIONS.PSLNK_CUSLOOKUP:
                    #region Pesalink Customer Look Up
                    //---- Get search data
                    cusLookUp = JsonConvert.DeserializeObject<PesalinkCusLookUp>(new JObject(request.Content).ToString());

                    if (cusLookUp == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid pesalink transfer  data!" };


                    ///validate client app and get account details
                    result = await db.ServiceRepository.InitApiRequestAsync(request.ReservedData.ServiceCode, request.ReservedData.AppCode, request.Action, cusLookUp.AccountNo);
                    db.Reset();

                    if (result.RespStat != 0)
                    {
                        if (result.RespStat == 1)
                        {
                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    var headers = new Dictionary<string, string>();

                    using (var httpClient = new RestApiClient(result.Data1, RestApiClient.RequestType.Post, headers))
                    {
                        var response = await httpClient.SendRequestAsync(result.Data4);
                        if (response.Success)
                        {
                            var httpResult = JsonConvert.DeserializeObject<ApiResponseModel>(response.Data);
                            if (httpResult.Status == 0)
                            {
                                var cusInformation = JsonConvert.DeserializeObject<List<UserBanksData>>(new JObject(httpResult).ToString());

                                var hp = cusInformation.Any(x => x.Def == "1");

                                if (hp)
                                {
                                    var item = cusInformation.FirstOrDefault(o => o.Def == "1");

                                    cusData = new PesalinkCusLookUpData
                                    {
                                        BankName=item.BankName,
                                        CustomerName=item.CustName
                                    };
                                }
                                else
                                {
                                    return new GAPSApiResponseModel { RespStat = 1, Message = "User Has Not Registered!" };
                                }

                            }
                            else
                            {
                                return new GAPSApiResponseModel { RespStat = 1, Message = httpResult.Message };
                            }
                        }
                        else
                        {
                            if (response.Exception != null)
                                AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", response.Exception);

                            string respMsg = "";

                            if (!string.IsNullOrEmpty(response.Exception.Message))
                            {
                                AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", response.Exception);
                                respMsg = response.Exception.Message;
                            }
                            else if (!string.IsNullOrEmpty(response.Data))
                            {
                                AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", response.Data);
                                respMsg = response.Data;
                            }
                            return new GAPSApiResponseModel { RespStat = 1, Message = respMsg };
                        }
                    }

                    return new GAPSApiResponseModel
                    {
                        RespStat = 0,
                        Data = cusData
                    };
                #endregion
                case PSLNK_REQUEST_ACTIONS.PSLNK_TRANSFERS:
                    #region Pesalink Transfers
                    //---- Get search data
                    transfer = JsonConvert.DeserializeObject<PesalinkTransfer>(new JObject(request.Content).ToString());

                    if (transfer == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid pesalink transfer  data!" };


                    ///validate client app and get account details
                    result = await db.ServiceRepository.InitApiRequestAsync(request.ReservedData.ServiceCode, request.ReservedData.AppCode, request.Action, transfer.AccountNo);
                    db.Reset();

                    if (result.RespStat != 0)
                    {
                        if (result.RespStat == 1)
                        {
                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    transfer.AccountNo = result.Data1;

                    var balance = await db.CBSRepository.GetBalance(transfer.AccountNo);

                    if (balance.RespStat != 0)
                    {
                        if (balance.RespStat == 1)
                        {
                            return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    //---- Create payment
                    payRef = Guid.NewGuid().ToString("N");

                    dt = new DataTable();
                    dt.Columns.Add("Amount", typeof(decimal));
                    dt.Columns.Add("PayDate", typeof(DateTime));
                    dt.Columns.Add("UniqueRef");
                    dt.Columns.Add("Remarks");
                    dt.Columns.Add("BeneName");
                    dt.Columns.Add("BeneCode");
                    dt.Columns.Add("BeneAcc");
                    dt.Columns.Add("BeneBank");

                    foreach (var item in transfer.Transactions)
                    {
                        dt.Rows.Add(item.Amount, item.PaymentDate, item.TranRef, item.Narration, item.CustomerName, "", item.AccountNo, item.Bank);
                    }

                    payment = new PaymentModel
                    {
                        ServiceCode = request.ReservedData.ServiceCode,
                        AppCode = request.ReservedData.AppCode,
                        ActionCode = request.Action,
                        PaymentRef = payRef,
                        PayType = transfer.PayType,
                        Currency = transfer.Currency,
                        Balance = Convert.ToDecimal(balance.Data4),
                        CusAcc = balance.Data1
                    };

                    res = await db.ServiceRepository.CreatePesalinkPaymentAsync(payment, dt);
                    db.Reset();

                    if (res.RespStat != 0)
                    {
                        if (res.RespStat == 1)
                        {
                            return new GAPSApiResponseModel { RespStat = 1, Message = res.RespMsg };
                        }
                        else
                        {
                            AppUtil.Log.Error(Logfile, "Bl.ProcessPesalinkRequestAsync()", new Exception(result.RespMsg));
                            return new GAPSApiResponseModel { RespStat = 1, Message = "Request failed due to a database error!" };
                        }
                    }

                    var transres = new GAPTransferRes
                    {
                        Reference = res.Data1
                    };

                    return new GAPSApiResponseModel
                    {
                        RespStat = 0,
                        Data = transres
                    };
                #endregion
                case PSLNK_REQUEST_ACTIONS.PSLNK_LOOKUP:
                    #region Pesalink LookUp
                    lookup = JsonConvert.DeserializeObject<GAPLookUp>(new JObject(request.Content).ToString());

                    if (lookup == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid pesalink query data!" };

                    //---- Get db data
                    result = await db.ServiceRepository.InitApiRequestAsync(request.ReservedData.ServiceCode, request.ReservedData.AppCode, request.Action, lookup.BatchID.ToString(), lookup.TransID.ToString());
                    db.Reset();

                    if (result.RespStat != 0)
                        return new GAPSApiResponseModel { RespStat = 1, Message = result.RespMsg };


                    return new GAPSApiResponseModel
                    {
                        RespStat = 0
                    };
                #endregion
                case PSLNK_REQUEST_ACTIONS.PSLNK_ACCOUNT:
                    #region Pesalink Balance
                    //---- Get search data
                    bal = JsonConvert.DeserializeObject<BalanceReq>(new JObject(request.Content).ToString());

                    if (bal == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid account data!" };


                    result = await db.CBSRepository.GetBalance(bal.AccountNo);
                    db.Reset();
                    resp = new GAPSApiResponseModel
                    {
                        RespStat = result.RespStat,
                        Message = result.RespMsg,
                        Data = new BalanceRes
                        {
                            AccountNo = bal.AccountNo,
                            CusName = result.Data1,
                            PhoneNo = "+254" + result.Data2,
                            AccountStatus = result.Data3,
                            Amount = Convert.ToDecimal(result.Data4)
                        }
                    };
                    return resp;
                    #endregion
            }

            return resp;
        }

        private async Task<GAPSApiResponseModel> ProcessGTPayRequestAsync(GAPSApiRequestModel request)
        {
            var resp = new GAPSApiResponseModel { RespStat = 1, Message = "Request was not handled!" };

            string baseUrl = "";
            string username = "";
            string password = "";
            string payRef = "";
            GTCollectStk transfer = null;
            STKResponse response = null;
            GenericModel result = null;
            List<Merchants> merchant = null;
            DataTable dt = null;
            List<Settlement> settle = null;

            switch (request.Action)
            {
                case GTPAY_REQUEST_ACTIONS.GTPAY_TRANSFERS:
                    #region STK Push Transfers
                    //---- Get search data
                    transfer = JsonConvert.DeserializeObject<GTCollectStk>(new JObject(request.Content).ToString());

                    if (transfer == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid stk data!" };

                    transfer.AppCode = request.ReservedData.AppCode;
                    UtilityGateway util = null;
                    result = await db.MpesaRepository.MakePayment(transfer);
                    db.Reset();
                    util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                    if (result.RespStat == 0)
                    {
                        Dictionary<string, string> headers = new Dictionary<string, string>();

                        var token = await util.GetToken("", result.Data2, result.Data3);


                        headers.Add("Authorization", "Bearer " + token.Token);
                        util = new UtilityGateway(result.Data1, result.Data2, result.Data3);

                        AppUtil.Log.Error(Logfile, "Bl.MpesaSTK()", new Exception(result.Data4));

                        response = await util.PostSTK(result.Data4, headers);

                        result = await db.MpesaRepository.UpdateStkPayment(Convert.ToInt32(response.Response), response.Merchant, transfer.ReferenceNo);
                        db.Reset();


                        return new GAPSApiResponseModel
                        {
                            RespStat = Convert.ToInt32(response.Response),
                            Message = response.Description
                        };
                    }

                    return new GAPSApiResponseModel
                    {
                        RespStat = result.RespStat,
                        Message = result.RespMsg
                    };

                    #endregion
                case GTPAY_REQUEST_ACTIONS.GTPAY_MERCHANTS:
                    #region GTPay Merchants
                    //---- Get search data
                    merchant = JsonConvert.DeserializeObject<List<Merchants>>(new JObject(request.Content).ToString());

                    if (merchant == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid merchant data!" };

                    dt = new DataTable();
                    dt.Columns.Add("Merchant");
                    dt.Columns.Add("Name");
                    dt.Columns.Add("Account");

                    foreach (var item in merchant)
                    {
                        dt.Rows.Add(item.MerchantCode, item.Name, item.AccountNumber);
                    }

                    result = await db.MpesaRepository.RegisterMerchant(dt);
                    db.Reset();

                    return new GAPSApiResponseModel
                    {
                        RespStat = result.RespStat,
                        Message = result.RespMsg
                    };
                    #endregion
                case GTPAY_REQUEST_ACTIONS.GTPAY_SETTLEMENT:
                    #region Settlement
                    //---- Get search data
                    settle = JsonConvert.DeserializeObject<List<Settlement>>(new JObject(request.Content).ToString());

                    if (settle == null)
                        return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid settlement data!" };

                    dt = new DataTable();
                    dt.Columns.Add("Merchant");
                    dt.Columns.Add("Amount");

                    foreach (var item in settle)
                    {
                        dt.Rows.Add(item.MerchantCode, item.Amount);
                    }

                    result = await db.MpesaRepository.Settlement(dt);
                    db.Reset();


                    return new GAPSApiResponseModel
                    {
                        RespStat = result.RespStat,
                        Message = result.RespMsg
                    };
                    #endregion
            }

            return resp;
        }

        //private async Task<GAPSApiResponseModel> ProcessMpesaAccountsRequestAsync(GAPSApiRequestModel request)
        //{
        //    var resp = new GAPSApiResponseModel { RespStat = 1, Message = "Request was not handled!" };

        //    string baseUrl = "";
        //    string username = "";
        //    string password = "";
        //    string payRef = "";
        //    MpesaReference mRef = null;
        //    GenericModel result = null;

        //    switch (request.Action)
        //    {
        //        case MPESA_REQUESR_ACTIONS.MPESA_INSERT:
        //            #region MPESA Reference Insert
        //            //---- Get search data
        //            mRef = JsonConvert.DeserializeObject<MpesaReference>(new JObject(request.Content).ToString());

        //            if (mRef == null)
        //                return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid stk data!" };

        //            //request.ReservedData.AppCode;
        //            UtilityGateway util = null;
        //            result = await db.MpesaRepository.MakePayment(transfer);
        //            db.Reset();
        //            util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
        //            if (result.RespStat == 0)
        //            {
        //                Dictionary<string, string> headers = new Dictionary<string, string>();

        //                var token = await util.GetToken("", result.Data2, result.Data3);


        //                headers.Add("Authorization", "Bearer " + token.Token);
        //                util = new UtilityGateway(result.Data1, result.Data2, result.Data3);

        //                AppUtil.Log.Error(Logfile, "Bl.MpesaSTK()", new Exception(result.Data4));

        //                response = await util.PostSTK(result.Data4, headers);

        //                result = await db.MpesaRepository.UpdateStkPayment(Convert.ToInt32(response.Response), response.Merchant, transfer.ReferenceNo);
        //                db.Reset();


        //                return new GAPSApiResponseModel
        //                {
        //                    RespStat = Convert.ToInt32(response.Response),
        //                    Message = response.Description
        //                };
        //            }

        //            return new GAPSApiResponseModel
        //            {
        //                RespStat = result.RespStat,
        //                Message = result.RespMsg
        //            };

        //        #endregion
        //        case MPESA_REQUESR_ACTIONS.MPESA_DELETE:
        //            #region MPESA Reference Delete
        //            //---- Get search data
        //            merchant = JsonConvert.DeserializeObject<List<MpesaReference>>(new JObject(request.Content).ToString());

        //            if (merchant == null)
        //                return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid merchant data!" };

        //            dt = new DataTable();
        //            dt.Columns.Add("Merchant");
        //            dt.Columns.Add("Name");
        //            dt.Columns.Add("Account");

        //            foreach (var item in merchant)
        //            {
        //                dt.Rows.Add(item.MerchantCode, item.Name, item.AccountNumber);
        //            }

        //            result = await db.MpesaRepository.RegisterMerchant(dt);
        //            db.Reset();

        //            return new GAPSApiResponseModel
        //            {
        //                RespStat = result.RespStat,
        //                Message = result.RespMsg
        //            };
        //        #endregion
        //        case MPESA_REQUESR_ACTIONS.MPESA_VIEW:
        //            #region MPESA Reference View
        //            //---- Get search data
        //            settle = JsonConvert.DeserializeObject<List<MpesaReference>>(new JObject(request.Content).ToString());

        //            if (settle == null)
        //                return new GAPSApiResponseModel { RespStat = 1, Message = "Invalid settlement data!" };

        //            dt = new DataTable();
        //            dt.Columns.Add("Merchant");
        //            dt.Columns.Add("Amount");

        //            foreach (var item in settle)
        //            {
        //                dt.Rows.Add(item.MerchantCode, item.Amount);
        //            }

        //            result = await db.MpesaRepository.Settlement(dt);
        //            db.Reset();


        //            return new GAPSApiResponseModel
        //            {
        //                RespStat = result.RespStat,
        //                Message = result.RespMsg
        //            };
        //            #endregion
        //    }

        //    return resp;
        //}
        #endregion

        #region GTCollect
        public async Task<StudentName> GetStudentName(MpesaPayment model)
        {
            MKUGateway mku = null;
            STKResponse response = null;
            GenericModel result = await db.MpesaRepository.GetSystemSettings(model);
            db.Reset();

            if (result.RespStat == 0)
            {
                mku = new MKUGateway(result.Data1, result.Data2, result.Data3);

                Dictionary<string, string> headers = new Dictionary<string, string>();

                var studentName = await mku.GetStudentName(model);

                model.StudentName = studentName.Name;

                result = await db.MpesaRepository.CreateGTCollectionPayment(model);
                db.Reset();

                return studentName;
            }

            return new StudentName
            {
                Name =""
            };
        }

        public async Task<ApiResponseModel> PayFees(MpesaPayment model)
        {
            MKUGateway mku = null;
            ApiResponseModel response = null;
            GenericModel result = await db.MpesaRepository.GetSystemSettings(model);
            db.Reset();

            if (result.RespStat == 0)
            {
                mku = new MKUGateway(result.Data1, result.Data2, result.Data3);

                Dictionary<string, string> headers = new Dictionary<string, string>();

                var res = await mku.PaySchoolFees(model);

                response = new ApiResponseModel
                {
                    Status = Convert.ToInt32(res.ResponseCode),
                    Message = res.ResponseMsg
                };
            }

            return response;
        }


        public async Task<IEnumerable<ListModel>> GetItemListAsync( int code = 0)
        {
            return await db.GeneralRepository.GetItemListAsync( code);
        }

        public async Task<GenericModel> CreatePayment(GTCollect model)
        {
            UtilityGateway util = null;
            STKResponse response = null;
            GenericModel result = await db.MpesaRepository.CreateCollectionPayment(model);
            db.Reset();

            if (result.RespStat == 0)
            {
                switch (model.PayMethod)
                {
                    case 1://mpesa
                        util = new UtilityGateway(result.Data1, result.Data2, result.Data3);

                        Dictionary<string, string> headers = new Dictionary<string, string>();

                        var token = await util.GetToken("", result.Data2, result.Data3);


                        headers.Add("Authorization", "Bearer " + token.Token);
                        util = new UtilityGateway(result.Data1, result.Data2, result.Data3);
                        response = await util.PostSTK(result.Data4, headers);

                        result = await db.MpesaRepository.UpdateCollectionPayment(Convert.ToInt32(response.Response), response.Merchant, result.Data5);
                        db.Reset();

                        if (result.RespStat == 0)
                        {
                            DateTime now = DateTime.Now;
                            while (DateTime.Now.Subtract(now).Seconds < 70)
                            {
                                // wait for 70 seconds
                            }

                            result = await db.MpesaRepository.QueryTransaction(result.Data4);
                            db.Reset();
                        }
                        return result;
                        break;
                    default:
                        break;
                }
            }
            return result;
        }
        #endregion

        #region CBK
        public Task<ApiResponseModel> GetGovtSecurities(CBKTransactionQuery model)
        {
            throw new NotImplementedException();
            //CBKGateway util = null;
        }
        #endregion

        #region TAX

        public async Task<RequestResponseModel> QueryTax(DeclarationQueryData model)
        {
            TaxGateway tax = null;
            STKResponse response = null;
            GenericModel result = await db.TAXRepository.QueryTax(model);
            db.Reset();

            if (result.RespStat == 0)
            {
                tax = new TaxGateway(result.Data1, result.Data2, CrptoUtil.Base64Encode(result.Data3));

                RequestResponseModel request = await tax.QueryTaxDeclaration(result.Data4);

                if (request.Status == 0)
                {
                   // KRAQueryResponse data = JsonConvert.DeserializeObject<KRAQueryResponse>();

                    //result = await db.TAXRepository.LogTaxDetails(request.Content);
                    //db.Reset();


                    if (result.RespStat == 0)
                    {
                        return request;
                    }

                    return new RequestResponseModel
                    {
                        Status = result.RespStat,
                        Message = result.RespMsg
                    };
                }
                return new RequestResponseModel
                {
                    Status = request.Status,
                    Message = request.Message
                };
            }

            return new RequestResponseModel
            {
                Status = result.RespStat,
                Message = result.RespMsg
            };
        }

        #endregion
    }


}
