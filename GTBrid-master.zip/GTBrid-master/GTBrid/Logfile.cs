﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GTBrid
{
    public class Logfile
    {

        public static void Errors(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void CreditTransfer(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "CreditTransfer.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void PayFor(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "PaymentInitiation.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void VerifyConnection(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "VerifyConnection.txt";
            string fullPath = folder+"\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
           
        }

        public static void VerifyRequest(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "VerifyRequest.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void VerifyResponse(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "VerifyResponse.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void MessageReject(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "MessageRejection.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }
        public static void PaymentResponse(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "PaymentResponse.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

        public static void BulkPaymentResponse(string content)
        {
            string folder = @"E:\PesaLink\PesaLink" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "BulkPaymentResponse.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                    sw.Flush();
                    sw.Close();
                }
            }
        }

    }
}
