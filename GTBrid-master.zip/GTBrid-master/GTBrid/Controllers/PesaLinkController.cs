﻿using DBL;
using DBL.Models;
using GTBrid.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace GTBrid.Controllers
{
    [Route("/v1/")]
    [ApiController]
    public class PesaLinkCOntroller : ControllerBase
    {
        private Bl bl;

        public PesaLinkCOntroller(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.DBConnection, "");
        }

        [HttpPost("system-event-notification")]
        [Consumes("application/xml")]
        public async Task<IActionResult> VerifyConnection(XElement xml)
        {
            Logfile.VerifyConnection(xml.ToString());
            string result = "";
            try
            {
                string Xml = xml.ToString();
                result = await bl.VerifyConnection(Xml);
               

            }
            catch (Exception ex)
            {
                result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = "", ContentType = "application/xml", StatusCode = 202 };

        }

        [HttpPost("verification-request")]
        [Consumes("application/xml")]
        public async Task<IActionResult> ValidateIncoming(XElement xml)
        {
            Logfile.VerifyRequest(DateTime.Now.ToString() + ":" + xml.ToString());
            string result;
            try
            {
                string Xml = xml.ToString();
                result = await bl.GetAuthData(Xml);
                Logfile.VerifyResponse(result);

            }
            catch (Exception ex)
            {
                result=ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = result, ContentType = "application/xml", StatusCode = 202 };

        }

        [HttpPost("validout")]
        [Consumes("application/json")]
        public async Task<ApiResponseModel> ValidateOutGoing([FromBody] AuthData model)
        {
            ApiResponseModel result = new ApiResponseModel();
            try
            {
                 result = await bl.ValidateCustomer(model);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due to Technical Issue"
                };
            }
            return result;
        }

        [HttpPost("valid-bulk-out")]
        [Consumes("application/json")]
        public async Task<ApiResponseModel> ValidateBulkOutGoing([FromBody] BulkData model)
        {
            ApiResponseModel result = new ApiResponseModel();
            try
            {
                result = await bl.ValidateBulkCustomer(model.Data);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due to Technical Issue"
                };
            }
            return result;
        }

        [HttpPost("credit-transfer")]
        [Consumes("application/xml")]
        public async Task<IActionResult> PayIncoming([FromBody] XElement xml)
        {
            Logfile.CreditTransfer(DateTime.Now.ToString() + ":" + xml.ToString());
            string result = "";
            try
            {
                 result = await bl.PayIN(xml.ToString());
            }
            catch (Exception ex)
            {
                result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = result, ContentType = "application/xml", StatusCode = 202 };

        }

        [HttpPost("payment-initiation")]
        [Consumes("application/xml")]
        public async Task<IActionResult> PaymentInitiation([FromBody] XElement xml)
        {
            Logfile.PayFor(DateTime.Now.ToString() + ":" + xml.ToString());
            string result = "";
            try
            {
                result = await bl.PayFor(xml.ToString());
            }
            catch (Exception ex)
            {
                result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = result, ContentType = "application/xml", StatusCode = 202 };

        }


        [HttpPost("payout")]
        [Consumes("application/json")]
        public async Task<PaymentRespose> PayOutgoing([FromBody] PaymentRequest model)
        {
            PaymentRespose result = new PaymentRespose();
            try
            {
                 result = await bl.PayOut(model);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new PaymentRespose
                {
                    Status = 2,
                    Message = "Failed Due to Technical Issue"
                };
            }
            return result;
        }

        [HttpPost("unavailable")]
        [Consumes("application/json")]
        public async Task<string> Unaivalable([FromBody] Unavailable model)
        {
            string result = "";
            try
            {
                result = await bl.Unavailable(model);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = ex.Message;
            }
            return result;
        }

        [HttpPost("message-reject")]
        [Consumes("application/xml")]
        public async Task<IActionResult> Rejection(XElement xml)
        {
            Logfile.MessageReject(DateTime.Now.ToString() + ":" + xml.ToString());
            string result;
            try
            {
                string Xml = xml.ToString().Replace("Original message:", "");
                result = await bl.MessageRejection(Xml);

            }
            catch (Exception ex)
            {
                // result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = "", ContentType = "application/xml", StatusCode = 202 };

        }

        [HttpPost("payment-status-report")]
        [Consumes("application/xml")]
        public async Task<IActionResult> PaymentResponse(XElement xml)
        {
            Logfile.PaymentResponse(DateTime.Now.ToString() + ":" + xml.ToString());
            string result;
            try
            {
                string Xml = xml.ToString();
                result = await bl.UpdatePayment(Xml);

            }
            catch (Exception ex)
            {
                // result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = "", ContentType = "application/xml", StatusCode = 202 };

        }

        [HttpPost("payment-status-report-bulk")]
        [Consumes("application/xml")]
        public async Task<IActionResult> BulkPaymentResponse(XElement xml)
        {
            Logfile.BulkPaymentResponse(DateTime.Now.ToString() + ":" + xml.ToString());
            string result;
            try
            {
                string Xml = xml.ToString();
                result = await bl.UpdatePayment(Xml);

            }
            catch (Exception ex)
            {
                // result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = "", ContentType = "application/xml", StatusCode = 202 };

        }



        [HttpPost("lookup")]
        [Consumes("application/json")]
        public async Task<IActionResult> TransactionQuery()
        {
             string result;
            try
            {
                result = await bl.TransactionLookUp();
            }
            catch (Exception ex)
            {
                // result = ex.Message;
                Logfile.Errors(ex.ToString());
            }
            return new ContentResult { Content = "", ContentType = "application/xml", StatusCode = 202 };
        }

        [HttpPost("register")]
        [Consumes("application/json")]
        public async Task<RegisterResponse> CustRegister([FromBody] Register model)
        {
            RegisterResponse result = new RegisterResponse();
            try
            {
                result = await bl.RegisterCustomer(model);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new RegisterResponse
                {
                    Status = 2,
                    Message = "Failed Due to Technical Issue"
                };
            }
            return result;
        }

        [HttpPost("customer-lookup")]
        [Consumes("application/json")]
        public async Task<PaymentRespose> CustLookUp([FromBody] Register model)
        {
            PaymentRespose result = new PaymentRespose();
            try
            {
                var data = await bl.LookUpCustomer(model);
                result = new PaymentRespose
                {
                    Status = 0,
                    Message = "",
                    Data = data
                };
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                result = new PaymentRespose
                {
                    Status = 1
                };
            }
            return result;
        }
    }
}
