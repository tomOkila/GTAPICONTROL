﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTBrid.Models
{
    public class ConnectionStrings
    {
        public string DBConnection { get; set; }
    }
}
