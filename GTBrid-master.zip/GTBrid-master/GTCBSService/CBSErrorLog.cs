﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GTCBSService
{
    public class CBSErrorLog
    {
        public static void Errors(string logfile,string content)
        {
            string folder = logfile+"\\CBS" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }
    }
}
