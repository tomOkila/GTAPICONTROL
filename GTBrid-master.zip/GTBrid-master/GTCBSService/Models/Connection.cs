﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTCBSService.Models
{
    public class ConnectionStrings
    {
        public string DBConnection { get; set; }
        public string LogFile { get; set; }
    }
}
