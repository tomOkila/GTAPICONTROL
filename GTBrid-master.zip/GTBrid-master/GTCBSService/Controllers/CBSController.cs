﻿using DBL;
using DBL.Models;
using GTCBSService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTCBSService.Controllers
{
    [Route("cbs/api/")]
    [ApiController]
    public class CBSController : ControllerBase
    {
        private Bl bl;
        private string logfile;
        public CBSController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.DBConnection, appSettings.Value.LogFile);
            logfile = appSettings.Value.LogFile;
        }

        [HttpPost("cbs")]
        public async Task<ApiResponseModel> CBS([FromBody] ApiRequestModel model)
        {
            var response = new ApiResponseModel();
            try
            {
                response = await bl.ProcessCBSRequest(model);
            }
            catch (Exception ex)
            {
                CBSErrorLog.Errors(logfile,ex.ToString());
                response = new ApiResponseModel
                {
                    Status = 1,
                    Message = "Failed Due to a Technical Issue!"
                };
            }
            return response;
        }
    }
}
