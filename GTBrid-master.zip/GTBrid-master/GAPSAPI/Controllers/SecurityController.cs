﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DBL;
using DBL.Entities;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace GAPSAPI.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class SecurityController : BaseController
    {
        private Bl bl;
        private string logFile;
        public SecurityController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
        }

        [HttpGet]
        public async Task<IActionResult> Users()
        {
            var users = await bl.GetUsersAsync();
            return View(users);
        }

        [HttpGet]
        public IActionResult AddUser()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddUser(User model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var result = await bl.CreateUserAsync(model, SessionUserData.UserCode);
                    if (result.RespStat == 0)
                    {
                        Success("User created successfully pending approval.");
                        return RedirectToAction("users");
                    }
                    else
                    {
                        if (result.RespStat == 1)
                        {
                            Danger(result.RespMsg);
                        }
                        else
                        {
                            AppUtil.Log.Error(logFile, "Security.AddUser", new Exception(result.RespMsg));
                            Danger("Request failed due to a database error!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    AppUtil.Log.Error(logFile, "Security.AddUser", ex);
                    Danger("Request failed due to an error!");
                }
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> ManageUser(int code)
        {
            var user = await bl.GetUserAsync(code);
            return View(user);
        }

        [HttpGet]
        public async Task<IActionResult> ChangeUserStat(int code, int stat)
        {
            try
            {
                var result = await bl.ChangeUserStatusAsync(code, stat, SessionUserData.UserCode);
                if (result.RespStat == 0)
                {
                    Success("User status successfully changed pending approval.");
                }
                else
                {
                    if (result.RespStat == 1)
                    {
                        Danger(result.RespMsg);
                    }
                    else
                    {
                        AppUtil.Log.Error(logFile, "Security.ChangeUserStat", new Exception(result.RespMsg));
                        Danger("Request failed due to a database error!");
                    }
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "Security.ChangeUserStat", ex);
                Danger("Request failed due to an error!");
            }
            return Json("ok");
        }

        [HttpGet]
        public async Task<IActionResult> ResetUserPass(int code)
        {
            try
            {
                var result = await bl.ResetUserPasswordAsync(code, SessionUserData.UserCode);
                if (result.RespStat == 0)
                {
                    Success("User password reset successfully pending approval.");
                }
                else
                {
                    if (result.RespStat == 1)
                    {
                        Danger(result.RespMsg);
                    }
                    else
                    {
                        AppUtil.Log.Error(logFile, "Security.ResetUserPass", new Exception(result.RespMsg));
                        Danger("Request failed due to a database error!");
                    }
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "Security.ResetUserPass", ex);
                Danger("Request failed due to an error!");
            }
            return Json("ok");
        }
    }
}
