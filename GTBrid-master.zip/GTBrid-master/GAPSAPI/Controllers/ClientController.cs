﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DBL;
using DBL.Entities;
using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace GAPSAPI.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class ClientController : BaseController
    {
        private Bl bl;
        private string logFile;
        public ClientController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
        }

        public async Task<IActionResult> Main(string name = "")
        {
            var clients = await bl.GetClientsAsync(name);
            return View(clients);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Client model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    model.CreatedBy = SessionUserData.UserCode;
                    var result = await bl.CreateClientAsync(model);
                    if (result.RespStat == 0)
                    {
                        Success(result.RespMsg);
                        return RedirectToAction("main");
                    }
                    else
                    {
                        if (result.RespStat == 1)
                        {
                            Danger(result.RespMsg);
                        }
                        else
                        {
                            AppUtil.Log.Error(logFile, "Client.Create", new Exception(result.RespMsg));
                            Danger("Request failed due to a database error!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    AppUtil.Log.Error(logFile, "Client.Create", ex);
                    Danger("Request failed due to an error!");
                }
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Manage(int code)
        {
            var client = await bl.GetClientAsync(code);
            return View(client);
        }

        [HttpGet]
        public async Task<IActionResult> ChangeStat(int code, int stat)
        {
            try
            {
                var result = await bl.ChangeClientStatAsync(code, stat);
                if (result.RespStat == 0)
                {
                    Success("Client status changed successfully.");
                }
                else
                {
                    if (result.RespStat == 1)
                    {
                        Danger(result.RespMsg);
                    }
                    else
                    {
                        AppUtil.Log.Error(logFile, "Client.ChangeStat", new Exception(result.RespMsg));
                        Danger("Request failed due to a database error!");
                    }
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "Client.ChangeStat", ex);
                Danger("Request failed due to an error!");
            }
            
            return Json("ok");
        }

        [HttpGet]
        public async Task<IActionResult> Apps(int code)
        {
            var apps = await bl.GetClientAppsAsync(code);
            return PartialView("_Apps", apps);
        }

        [HttpGet]
        public async Task<IActionResult> ManageApp(int code)
        {
            var app = await bl.GetClientAppAsync(code);
            return View(app);
        }

        [HttpGet]
        public async Task<IActionResult> ChangeAppStat(int code, int stat)
        {
            try
            {
                var result = await bl.ChangeAppStatAsync(code, stat);
                if (result.RespStat == 0)
                {
                    Success("App status changed successfully.");
                }
                else
                {
                    if (result.RespStat == 1)
                    {
                        Danger(result.RespMsg);
                    }
                    else
                    {
                        AppUtil.Log.Error(logFile, "Client.ChangeAppStat", new Exception(result.RespMsg));
                        Danger("Request failed due to a database error!");
                    }
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "Client.ChangeAppStat", ex);
                Danger("Request failed due to an error!");
            }

            return Json("ok");
        }

        [HttpGet]
        public async Task<IActionResult> ResetApp(int code)
        {
            var reqResult = new ReqResult { Success = false, Message = "Request failed!" };
            try
            {
                //var result = await bl.ResetClientAppAsync(code);
                //if (result.RespStat == 0)
                //{
                //    reqResult.Success = true;
                //    reqResult.Message = "App key has been reset.";
                //    reqResult.Data = result.Data1;
                //}
                //else
                //{
                //    if (result.RespStat == 1)
                //    {
                //        reqResult.Message = result.RespMsg;
                //    }
                //    else
                //    {
                //        AppUtil.Log.Error(logFile, "Client.ResetApp", new Exception(result.RespMsg));
                //        reqResult.Message = "Request failed due to a database error!";
                //    }
                //}
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "Client.ResetApp", ex);
                reqResult.Message = "Request failed due to an error!";
            }

            return PartialView("_KeyResult", reqResult);
        }
    }
}
