﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DBL;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace GAPSAPI.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class ServiceController : BaseController
    {
        private Bl bl;
        private string logFile;
        public ServiceController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
        }

        [HttpGet]
        public async Task<IActionResult> Main(string name = "")
        {
            var services = await bl.GetServicesAsync(name);
            return View(services);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Create(UtilService model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            model.Extra2 = SessionUserData.UserCode.ToString();
        //            var result = await bl.CreateServiceAsync(model);
        //            if (result.RespStat == 0)
        //            {
        //                Success(result.RespMessage);
        //                return RedirectToAction("main");
        //            }
        //            else
        //            {
        //                if (result.RespStat == 1)
        //                {
        //                    Danger(result.RespMessage);
        //                }
        //                else
        //                {
        //                    AppUtil.Log.Error(logFile, "Client.Create", new Exception(result.RespMessage));
        //                    Danger("Request failed due to a database error!");
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            AppUtil.Log.Error(logFile, "Client.Create", ex);
        //            Danger("Request failed due to an error!");
        //        }
        //    }

        //    return View(model);
        //}

        [HttpGet]
        public async Task<IActionResult> Manage(int code)
        {
            var service = await bl.GetServiceAsync(code);
            return View(service);
        }

        
    }
}
