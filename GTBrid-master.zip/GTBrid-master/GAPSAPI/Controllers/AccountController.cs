﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using DBL;
using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace GAPSAPI.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class AccountController : BaseController
    {
        private Bl bl;
        private string logFile;
        public AccountController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> Login(string returnUrl = null)
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(UserLoginModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                try
                {
                    var userModel = await bl.UserLoginAsync(model.Username, model.Password);
                    if (userModel.RespStat == 0)
                    {
                        //---- Check if change password
                        if (userModel.UserStatus == DBL.Enums.UserLoginStatus.ChangePassword)
                        {
                            return RedirectToAction("ChangePass", new { userCode = userModel.UserCode, returnUrl = returnUrl });
                        }
                        else
                        {
                            SetUserLoggedIn(userModel, false);
                            return RedirectToLocal(returnUrl);
                        }
                    }
                    else
                    {
                        if (userModel.RespStat == 1)
                        {
                            Danger(userModel.RespMsg);
                        }
                        else
                        {
                            AppUtil.Log.Error(logFile, "Account.Login", new Exception(userModel.RespMsg));
                            Danger("Login failed due to a database error!");
                        }
                    }
                }
                catch (Exception ex)
                {
                    AppUtil.Log.Error(logFile, "Account.Login", ex);
                    Danger("Login failed due to an error!");
                }
            }
            return View(model);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ChangePass(int userCode, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ChangeUserPassModel passModel = new ChangeUserPassModel { UserCode = userCode };
            return View(passModel);
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePass(ChangeUserPassModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                var userModel = await bl.ChangeUserPasswordAsync(model, 1);
                if (userModel.RespStat == 0)
                {
                    Success("Password changed successfully.");
                }
                else
                    Danger(userModel.RespMsg);
            }
            else
                Danger("Data model is NOT valid!");
            return RedirectToAction("Login", new { returnUrl = returnUrl });
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ForgotPass(string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ForgotPass(ResetPassModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            if (ModelState.IsValid)
            {
                try
                {
                    //var result = await bl.ResetUserPasswordAsync(model.Username);
                    //if (result.RespStat == 0)
                    //{
                    //    Success(result.RespMsg);
                    //    return RedirectToAction("login", new { returnUrl = returnUrl });
                    //}
                    //else
                    //{
                    //    if (result.RespStat == 1)
                    //    {
                    //        Danger(result.RespMsg);
                    //    }
                    //    else
                    //    {
                    //        AppUtil.Log.Error(logFile, "Account.ForgotPass", new Exception(result.RespMsg));
                    //        Danger("Request failed due to a database error!");
                    //    }
                    //}
                }
                catch (Exception ex)
                {
                    AppUtil.Log.Error(logFile, "Account.ForgotPass", ex);
                    Danger("Request failed due to an error!");
                }
            }
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(AccountController.Login), "Account");
        }

        private async void SetUserLoggedIn(UserModel user, bool rememberMe)
        {
            UserModel serializeModel = new UserModel
            {
                FullNames = user.FullNames,
                UserCode = user.UserCode
            };

            string userData = JsonConvert.SerializeObject(serializeModel);

            List<Claim> claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserCode.ToString(),"NameIdentifier"),
                new Claim(ClaimTypes.Name, user.FullNames,"Name"),
                new Claim(ClaimTypes.Role, "0"),
                new Claim("userData", userData),
            };

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, "ApplicationCookie");

            ClaimsPrincipal principal = new ClaimsPrincipal(new ClaimsIdentity[] { claimsIdentity });
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
            new AuthenticationProperties
            {
                IsPersistent = rememberMe,
                ExpiresUtc = new DateTimeOffset?(DateTime.UtcNow.AddMinutes(30))
            });
        }

        #region Helpers
        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }

        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (string.IsNullOrEmpty(returnUrl) || returnUrl == "/")
                return RedirectToAction(nameof(HomeController.Index), "Home", new { area = "" });

            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(HomeController.Index), "Home", new { area = "" });
            }
        }

        #endregion
    }
}
