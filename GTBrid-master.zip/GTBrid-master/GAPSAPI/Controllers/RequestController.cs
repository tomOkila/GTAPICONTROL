﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DBL;
using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace GAPSAPI.Controllers
{
    [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
    public class RequestController : BaseController
    {
        private Bl bl;
        private string logFile;
        public RequestController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
        }

        [HttpGet]
        public IActionResult Tools()
        {
            return View();
        }

        //[HttpGet]
        //public async Task<IActionResult> Calls()
        //{
        //    var trans = await bl.GetTransactions();
        //    return View(trans);
        //}

        [HttpPost]
        public IActionResult CreateAuthheader(string appId, string appKey)
        {
            var result = new ReqResult();

            var header = AppUtil.GenerateAuthHeader(appId, appKey);
            var head= CryptoUtil.GenerateSignHeader(CryptoUtil.MD5Hash(appId + appKey));
            result.Data = header;
            result.Success = true;

            return Json(result);
        }

        //[HttpPost]
        //public async Task<IActionResult> PushTran(string code)
        //{
        //    try
        //    {
        //        var result = await bl.PushTransactionAsync(code,  SessionUserData.UserCode);
        //        if (result.RespStat == 0)
        //        {
        //            Success("Transaction pushed successfully.");
        //        }
        //        else
        //        {
        //            if (result.RespStat == 1)
        //            {
        //                Danger(result.RespMessage);
        //            }
        //            else
        //            {
        //                AppUtil.Log.Error(logFile, "Request.PushTran", new Exception(result.RespMessage));
        //                Danger("Request failed due to a database error!");
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        AppUtil.Log.Error(logFile, "Request.PushTran", ex);
        //        Danger("Request failed due to an error!");
        //    }
        //    return Json("ok");
        //}
    }
}
