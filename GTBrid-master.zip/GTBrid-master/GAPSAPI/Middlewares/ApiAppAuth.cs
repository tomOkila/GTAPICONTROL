﻿using DBL;
using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GAPSAPI.Middlewares
{
    public class ApiAppAuth
    {
        private readonly RequestDelegate _next;
        private Bl bl;
        private string logFile;
        private string callLogFile;
        string errorCode = "20";


        public ApiAppAuth(RequestDelegate next, IOptions<ConnectionStrings> appConfig)
        {
            _next = next;
            bl = new Bl(appConfig.Value.DBConnection, appConfig.Value.LogFile);
            logFile = appConfig.Value.LogFile;
            callLogFile = appConfig.Value.LogFile;
        }
        
        public async Task Invoke(HttpContext httpContext)
        {
            string authMessage = "Authorization failed!";
            var authData = "";

            try
            {
                //if (!httpContext.Request.IsHttps)
                //{
                //    httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                //    await httpContext.Response.WriteAsync("HTTPS required!");
                //    errorCode = "11";
                //    authMessage = "HTTPS required!";
                //    authData = JsonConvert.SerializeObject(new { err_msg = authMessage, err_code = errorCode });
                //    return;
                //}

                Encoding encoding = Encoding.GetEncoding("iso-8859-1");

                //---- Get auth header
                string authHeader = httpContext.Request.Headers["Authorization"];
                if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Basic", StringComparison.OrdinalIgnoreCase))
                {
                    //---- Get header details
                    string authHeaderText = authHeader.Substring("Basic ".Length).Trim();

                    //---- Read request data
                    httpContext.Request.EnableBuffering();
                    string jsonData = await new StreamReader(httpContext.Request.Body).ReadToEndAsync();
                    if (string.IsNullOrEmpty(jsonData))
                    {
                        var respData = JsonConvert.SerializeObject(new { err_msg = "Request stream empty!", err_code = "22" });
                        httpContext.Response.StatusCode = StatusCodes.Status400BadRequest; //Bad request
                        await httpContext.Response.WriteAsync(respData);

                        return;
                    }

                    var reqData = JsonConvert.DeserializeObject<GAPSApiRequestModel>(jsonData);
                    if (reqData == null)
                    {
                        var respData = JsonConvert.SerializeObject(new { err_msg = "Invalid request data!", err_code = "23" });
                        httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;//Bad request
                        await httpContext.Response.WriteAsync(respData);

                        return;
                    }

                    var url = httpContext.Request.Path.Value;
                    string serviceId = url.Substring(url.LastIndexOf("/") + 1);

                    //----Authorize app header
                    var authResult = await bl.AuthorizeApiAsync(authHeaderText, serviceId);
                    if (authResult.Successful)
                    {
                        if (authResult.CallLog)
                            AppUtil.Log.Infor(callLogFile, serviceId, jsonData);

                        //---- Add extra data
                        ApiRequestInternalData reservedData = new ApiRequestInternalData
                        {
                            AppCode = authResult.AppCode,
                            ServiceCode = authResult.ServiceCode,
                            TokenCode = authResult.TokenCode
                        };

                        reqData.ReservedData = reservedData;
                        jsonData = JsonConvert.SerializeObject(reqData);

                        //--- Write data
                        var myData = encoding.GetBytes(jsonData);
                        var stream = new MemoryStream(myData);
                        httpContext.Request.Body = stream;

                        await _next(httpContext);
                        return;
                    }
                    else
                    {
                        errorCode = authResult.ErrorCode;
                        authMessage = authResult.Message;
                        AppUtil.Log.Error(logFile, "ApiAppAuth", new Exception(authMessage));
                    }
                }
                else
                {
                    authMessage = "Authorization details not found!";
                    errorCode = "21";
                    AppUtil.Log.Error(logFile, "ApiAppAuth", new Exception(authMessage));
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "ApiAppAuth", ex);
                authMessage = "Failed to authorize request due to an error!";
            }

            authData = JsonConvert.SerializeObject(new { err_msg = authMessage, err_code = errorCode });
            httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized; //Unauthorized
            await httpContext.Response.WriteAsync(authData);
        }
    }

    public static class ApiAppAuthExtensions
    {
        public static IApplicationBuilder UseApiAppAuth(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ApiAppAuth>();
        }
    }
}
