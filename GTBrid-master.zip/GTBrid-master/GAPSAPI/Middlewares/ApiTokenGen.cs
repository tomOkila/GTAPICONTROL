﻿using DBL;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GAPSAPI.Middlewares
{
    public class ApiTokenGen
    {
        private readonly RequestDelegate _next;
        private Bl bl;
        private string logFile;

        public ApiTokenGen(RequestDelegate next, IOptions<ConnectionStrings> appConfig)
        {
            _next = next;
            bl = new Bl(appConfig.Value.DBConnection, appConfig.Value.LogFile);
            logFile = appConfig.Value.LogFile;
        }


        public async Task Invoke(HttpContext httpContext)
        {
            string authMessage = "Authorization failed!";
            int statusCode = StatusCodes.Status200OK;
            var authData = "";
            string errorCode = "10";

            try
            {
                //if (!httpContext.Request.IsHttps)
                //{
                //    httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
                //    await httpContext.Response.WriteAsync("HTTPS required!");
                //    errorCode = "11";
                //    authMessage = "HTTPS required!";
                //    authData = JsonConvert.SerializeObject(new { err_msg = authMessage, err_code = errorCode });

                //    return;
                //}

                //---- Get auth header
                string authHeader = httpContext.Request.Headers["Authorization"];
                if (!string.IsNullOrEmpty(authHeader) && authHeader.StartsWith("Basic", StringComparison.OrdinalIgnoreCase))
                {
                    Encoding encoding = Encoding.GetEncoding("iso-8859-1");
                    //---- Get header details
                    string authHeaderText = authHeader.Substring("Basic ".Length).Trim();
                    AppUtil.Log.Error(logFile, "ApiTokenGen", authHeaderText);
                    //---- Authorize app header
                    var authResult = await bl.GenerateApiTokenRequestAsync(authHeaderText, httpContext.Request.Host.Value);
                    if (authResult.Successful)
                    {
                        //---- Successful
                        authData = JsonConvert.SerializeObject(new { auth_token = authResult.AuthToken, expiry = authResult.Expiry, err_code = "0", err_msg = "Successful" });
                    }
                    else
                    {
                        //---- Failed
                        statusCode = StatusCodes.Status401Unauthorized;
                        errorCode = authResult.ErrorCode;
                        authMessage = authResult.Message;
                    }
                }
                else
                {
                    statusCode = StatusCodes.Status400BadRequest;
                    errorCode = "11";
                    authMessage = "Request header missing!";
                }
            }
            catch (Exception ex)
            {
                AppUtil.Log.Error(logFile, "ApiTokenGen", ex);
                authMessage = "Failed to authorize request due to an error!";
                statusCode = StatusCodes.Status500InternalServerError;
            }

            //---- Fail
            if (statusCode != 200)
                authData = JsonConvert.SerializeObject(new { err_msg = authMessage, err_code = errorCode });

            httpContext.Response.StatusCode = statusCode;
            await httpContext.Response.WriteAsync(authData);
        }
    }

    public static class ApiTokenGenExtensions
    {
        public static IApplicationBuilder UseApiTokenGen(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ApiTokenGen>();
        }
    }
}
