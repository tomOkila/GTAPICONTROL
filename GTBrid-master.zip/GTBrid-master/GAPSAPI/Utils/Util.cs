﻿using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace GAPSAPI.Utils
{
    public class Util
    {
        public static AppConfig GetAppConfig(IConfiguration config, IWebHostEnvironment env)
        {
            var appConfig = new AppConfig();
            var connConfig = config.GetSection("DbConnData");
            var connData = connConfig.Get<ConnectionStrings>();

            appConfig.ConnectionString = connData.DBConnection;
            appConfig.LogFile = GetLogFile(env);
            return appConfig;
        }

        public static void CreateApiErrorResponse(string logFile, string functioName, Exception ex, bool isError = true)
        {
            Task.Run(async () =>
            {
                try
                {
                    //--- Delete log if it more than 500Kb
                    if (File.Exists(logFile))
                    {
                        FileInfo fi = new FileInfo(logFile);
                        if ((fi.Length / 1000) > 100)
                            fi.Delete();
                    }
                    //--- Create stream writter
                    StreamWriter stream = new StreamWriter(logFile, true);
                    await stream.WriteLineAsync(string.Format("{0}|{1:dd-MMM-yyyy HH:mm:ss}|{2}|{3}",
                        isError ? "ERROR" : "INFOR",
                        DateTime.Now,
                        functioName,
                        isError ? ex.ToString() : ex.Message));
                    stream.Close();
                }
                catch (Exception) { }
            });
        }

        public static string GetCallLogFile(IWebHostEnvironment env)
        {
            try
            {
                string logDir = Path.Combine(env.ContentRootPath, "logs");

                //---- Create Directory if it does not exist              
                if (!Directory.Exists(logDir))
                {
                    Directory.CreateDirectory(logDir);
                }
                return Path.Combine(logDir, "CallLog.log");
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static string GetLogFile(IWebHostEnvironment env)
        {
            try
            {
                string logDir = Path.Combine(env.ContentRootPath, "logs");

                //---- Create Directory if it does not exist              
                if (!Directory.Exists(logDir))
                {
                    Directory.CreateDirectory(logDir);
                }
                return Path.Combine(logDir, "ErrorLog.log");
            }
            catch (Exception)
            {
                return "";
            }
        }

        public static UserModel GetCurrentUserData(IEnumerable<ClaimsIdentity> claims)
        {
            string userData = claims.First(u => u.IsAuthenticated && u.HasClaim(c => c.Type == "userData")).FindFirst("userData").Value;
            if (string.IsNullOrEmpty(userData))
                return null;
            var userObject = JsonConvert.DeserializeObject<UserModel>(userData);
            return userObject ?? new UserModel(); ;
        }
    }
    //public class Alert
    //{
    //    public const string TempDataKey = "TempDataAlerts";
    //    public string AlertStyle { get; set; }
    //    public string Message { get; set; }
    //    public bool Dismissable { get; set; }
    //    public string IconClass { get; set; }
    //}

    //public static class AlertStyles
    //{
    //    public const string Success = "success";
    //    public const string Information = "info";
    //    public const string Warning = "warning";
    //    public const string Danger = "danger";
    //}
}
