﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using DBL;
using DBL.Models;
using GAPSAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace FinBridge.Areas.Api.Controllers
{
    [Route("cbk/api/v1/[action]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        private Bl bl;
        private string logFile;
        public HomeController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
            logFile = appSett.Value.LogFile;
        }


        [HttpPost]
        [ActionName("govtsecurities")]
        public async Task<ApiResponseModel> STKRequest([FromBody] CBKTransactionQuery model)
        {
            AppUtil.Log.Infor(logFile, "Api.Service.CBKRequest:", JsonSerializer.Serialize(model));
            var stkRes = await bl.GetGovtSecurities(model);
            return stkRes;
        }


    }
}
