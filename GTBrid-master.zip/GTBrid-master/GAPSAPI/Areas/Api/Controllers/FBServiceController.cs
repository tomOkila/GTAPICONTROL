﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using DBL;
using DBL.Models;
using GAPSAPI.Models;
using GAPSAPI.Utils;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace FinBridge.Areas.Api.Controllers
{
    [Route("mpesa/api/v1/[action]")]
    [ApiController]
    public class FBServiceController : ControllerBase
    {
        private Bl bl;
        private string logFile;
        public FBServiceController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
            logFile = appSett.Value.LogFile;
        }


        [HttpPost]
        [ActionName("stk")]
        public async Task<ApiResponseModel> STKRequest([FromBody] GTCollectStk model)
        {
            AppUtil.Log.Infor(logFile, "Api.Service.STKRequest:", JsonSerializer.Serialize(model));
            var stkRes = await bl.STKPush(model);
            return stkRes;
        }

        [HttpPost]
        [ActionName("callback")]
        public async Task MpesaRequest([FromBody] MpesaCallBack model)
        {
            AppUtil.Log.Infor(logFile, "Api.Service.Callback:", JsonSerializer.Serialize(model));
            var stkRes = await bl.StkCallbackAsync(model);
        }

    }


}
