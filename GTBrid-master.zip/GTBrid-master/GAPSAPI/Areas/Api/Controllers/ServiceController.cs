﻿using System;
using System.Text.Json;
using System.Threading.Tasks;
using DBL;
using DBL.Models;
using GAPSAPI.Models;
using GAPSAPI.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace FinBridge.Areas.Api.Controllers
{
    [Route("api/v1/service/[action]/{id}")]
    [ApiController]
    public class ServiceController : ControllerBase
    {

        private Bl bl;
        private string logFile;
        public ServiceController(IOptions<ConnectionStrings> appSett)
        {
            bl = new Bl(appSett.Value.DBConnection, appSett.Value.LogFile);
            logFile = appSett.Value.LogFile;
        }

        [HttpPost]
        [ActionName("call")]
        public async Task<GAPSApiResponseModel> Operation([FromBody] GAPSApiRequestModel requestData, string id)
        {
            try
            {
                requestData.ServiceId = id;
                return await bl.ApiServiceRequestAsync(requestData);
            }
            catch (Exception ex)
            {
                Util.CreateApiErrorResponse(logFile, "Api.Service.Operation:" + id, ex);
               return  new GAPSApiResponseModel
                {
                    RespStat = 1,
                    Message = "Request Failed due a technical error!"
                };
            }
        }


       
    }
}
