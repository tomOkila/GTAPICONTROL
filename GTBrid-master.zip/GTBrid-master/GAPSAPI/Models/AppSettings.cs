﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GAPSAPI.Models
{
    public class ConnectionStrings
    {
        public string DBConnection { get; set; }
        public string LogFile { get; set; }
    }
}
