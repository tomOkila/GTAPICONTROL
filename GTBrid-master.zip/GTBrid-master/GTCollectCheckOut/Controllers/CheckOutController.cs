﻿using DBL;
using DBL.Models;
using GTCollectCheckOut.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTCollectCheckOut.Controllers
{
    public class CheckOutController : BaseController
    {
        private Bl bl;
        private string logFile;

        public CheckOutController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.DBConnection, "");
            logFile = "";
        }

        [HttpGet]
        public async Task<IActionResult> CheckOut([FromRoute] string request)
        {
            await LoadSelections();
            return View();
        }

        private async Task LoadSelections(int role = 0)
        {

            var list = (await bl.GetItemListAsync(role)).Select(x => new SelectListItem
            {
                Text = x.Text,
                Value = x.Value
            }).ToList();

            var list2 = (await bl.GetItemListAsync(1)).Select(x => new SelectListItem
            {
                Text = x.Text,
                Value = x.Value
            }).ToList();

            ViewData["Docs"] = list;
            ViewData["Methods"] = list2;

        }

        [HttpGet]
        public async Task<IActionResult> GetStudentName(GTCollect model)
        {
            //try
            //{
            //    string account = "";
            //    var accountData = await bl.GetStudentName(model);
            //    if (accountData != null)
            //        account = accountData.Name;

            //    return Json(account);
            //}
            //catch (Exception ex)
            //{
            //    //LogUtil.Error(logFile, "Maintainance.GetAccountName", ex);
            //    Danger("An error occurred while processing your request!");
            //}
           return Json("");
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckOut(GTCollect model, string returnUrl = null)
        {
            try
            {
                var dbRequest = await bl.CreatePayment(model);
                if (dbRequest.RespStat == 0)
                {
                    Success(dbRequest.RespMsg);
                    return RedirectToAction("CheckOut");
                }
                else
                {
                    if (dbRequest.RespStat == 1)
                    {
                        Danger(dbRequest.RespMsg);
                    }
                    else
                    {
                        Danger("Request failed due to a database error!");
                        //LogUtil.Error(logFile, "Legal.AddContract", dbRequest.RespMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                Danger("Request failed due to an error!");
               // LogUtil.Error(logFile, "Legal.AddContract", ex);
            }
            return View(model);
        }

        [HttpPost("stk")]
        public async Task<ApiResponseModel> MpesaRequest([FromBody] GTCollectStk model)
        {
            ApiResponseModel bal = new ApiResponseModel();
            try
            {
                //GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ": Request " + JsonSerializer.Serialize(model));
                bal = await bl.STKPush(model);
            }
            catch (Exception ex)
            {
                //GTPayLogfile.GTPAYErrors(DateTime.Now.ToString() + ":" + ex.ToString());
                bal = new ApiResponseModel
                {
                    Status = 2,
                    Message = "Failed Due To Technical Issue!"
                };
            }
            return bal;
        }

        [HttpPost("callback")]
        public async Task MpesaRequest([FromBody] MpesaCallBack model)
        {

            var stkRes = await bl.StkCallbackAsync(model);
        }

       
    }
}
