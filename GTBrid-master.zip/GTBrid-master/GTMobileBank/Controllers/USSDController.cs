﻿using DBL;
using DBL.Models;
using GTMobileBank.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTMobileBank.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class USSDController : ControllerBase
    {
        private Bl bl;

        public USSDController(IOptions<ConnectionStrings> appSettings)
        {
            bl = new Bl(appSettings.Value.DBConnection, "");
        }
       

        //[HttpGet("gtmobile/")]
        [HttpPost("gtmobile/"), HttpGet("gtmobile/")]

        public async Task<ContentResult> USSD([FromRoute] string request)
        {
            string Step = "";
           USSDResponse response = new USSDResponse();
            try
            {
                string data = Request.Query["USSD_BODY"];
                string[] req = data.Split('*');
                USSDRequest model = new USSDRequest
                {
                    MnoCode = Convert.ToInt32(Request.Query["SERVICE_CODE"]),
                    SessionId = Request.Query["SESSION_ID"],
                    DataText = req[req.Length - 1],
                    PhoneNo = Request.Query["MOBILE_NUMBER"]
                };

                response = await bl.ProcessUSSDRequestAsync(model);

                model.DataText = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(model.DataText));
                model.PhoneNo = model.PhoneNo.Substring(0, Math.Min(model.PhoneNo.Length, 4)) + "****" + model.PhoneNo.Substring(model.PhoneNo.Length - 4, 4);
                Logfile.Infor(DateTime.Now.ToString() +" Request "+ JsonConvert.SerializeObject(model) + " Response " + response.DataText);
            }
            catch (Exception ex)
            {
                Logfile.Errors(ex.ToString());
                response = new USSDResponse
                {
                    StatusCode = 1,
                    DataText = "Service Unavailable please try again later"
                };
            }
            switch (response.StatusCode)
            {
                case 0:
                    Step = "CON " + response.DataText.Replace("\\n","\n");
                     break;
                default:
                    Step = "END " + response.DataText;
                        break;
            }

            return base.Content(Step,"text/html");
        }
    }
}
