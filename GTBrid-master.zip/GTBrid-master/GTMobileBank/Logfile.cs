﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GTMobileBank
{
    public class Logfile
    {

        public static void Errors(string content)
        {
            string folder = @"C:\USSD\USSD" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Errors.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }

        public static void Infor(string content)
        {
            string folder = @"C:\USSD\USSD" + DateTime.Now.ToString("yyMMdd") + "";
            // If directory does not exist, create it
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }
            string fileName = "Info.txt";
            string fullPath = folder + "\\" + fileName;

            // This text is added only once to the file.
            if (!File.Exists(fullPath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(fullPath))
                {
                    sw.WriteLine(content);
                }
            }
        }
    }
}
